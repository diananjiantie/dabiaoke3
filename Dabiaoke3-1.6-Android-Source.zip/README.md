# 大镖客3 1.6 安卓3D版

离线横屏APK，Android 8.0及以上。包名com.arthur.frontier，versionCode 116，versionName 1.6-3d。默认WebGL第三人称，继承旧安卓大世界规则与存档，移植电脑版1.6的方块造型、树山列车比例、天气与飞机改进。无需另外打开浏览器或联网；APK内部通过系统WebView运行本地资源。不支持WebGL的设备会进入旧版兼容视图。

操作：左摇杆移动，右摇杆转镜头；独立开火、换弹、死眼、切枪、上下马、冲刺、互动。移动、转镜头和动作按键支持多指同时使用。死眼期间使用标记和开火按钮。更多菜单包含视角复位、锁定切换、钓鱼、抢劫、存读档等。安卓返回键暂停/继续，地图和更多面板优先关闭。

内容：前三关与20波/无尽列车战、大世界、普通居民与帮派、三城铁路、银行与马车抢劫、监狱/押送/劫狱/被捕挖墙、骑马过河、岛屿航班、钓鱼出售、房屋建造、赏金与地区警察。角色、马匹、树木、房屋、列车和莱特式飞机用几何模型绘制；支持昼夜、太阳月亮云星、煤油灯和阵雨。手机操作和画面布局单独适配，并非运行Windows EXE。

设置：默认均衡画质1280上限，可选流畅960或高清1920，且不超过设备物理像素。灵敏度0.5～2.0倍，自动保存。9种WAV音效以离线数据内嵌，暂停和后台停止发声，恢复后可继续使用。

安装与存档：APK签名与旧安卓3.1版一致，可覆盖更新。不要先卸载旧应用，卸载会清除本机存档。旧安卓存档沿用；电脑XML存档不与安卓JSON存档互通。若已有更高版本号或不同签名安装，系统可能拒绝覆盖。

验证：通过关卡规则、大世界规则、触控与生命周期测试；在桌面Edge的手机尺寸环境中验证真实多指事件、3D渲染、暂停继续、9种音效解码、存档、昼夜/雨天/飞机/列车/银行截图。APK v2/v3签名和资源哈希校验通过。尚未在实体安卓手机测试，不承诺具体手机帧率。

源码：assets/mobile-3d.js为WebGL渲染和相机；core.js、world.js、world-events.js为规则；app.js为触控与界面；MainActivity.java为安卓离线容器。
构建：PowerShell运行build.ps1，指定-Jdk（JDK17目录）、-BuildTools（Android构建工具目录）、-Platform（包含android.jar的目录）、-SigningDirectory（自己的签名目录）。产物build/ArthurMorgan.apk。不包含原发布者私钥、JDK或SDK。
规则测试：node tests/core.test.cjs；node tests/world.test.cjs；node tests/touch.test.cjs；node tests/mobile-update.test.cjs。
浏览器测试：安装playwright依赖及Edge，先运行node tests/serve.cjs（本地4196端口），再运行node tests/browser-3d.cjs。也可通过PLAYWRIGHT_MODULE指定已有Playwright安装位置。

制作人员：不死战狼、点按。
