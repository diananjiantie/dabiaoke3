﻿using System;
using System.Drawing;
namespace ArthurFrontier {
    struct V3 {
        public float X,Y,Z;
        public V3(float x,float y,float z){X=x;Y=y;Z=z;}
    }
    // Reused interleaved vertex buffer: no per-face objects or per-vertex GL calls.
    sealed class ThreeDMesh {
        public readonly float[] Data=new float[2100000];
        public int Count;
        public float Pitch;public float XScale=1,YScale=1,ZScale=1;public float Light=1,OriginX,OriginY,OriginZ,Angle;float cosine=1,sine;
        public void Reset(float light){Count=0;Pitch=0;XScale=YScale=ZScale=1;Light=light;At(0,0,0,0);}
        public void At(float x,float y,float z,float angle){OriginX=x;OriginY=y;OriginZ=z;Angle=angle;cosine=(float)Math.Cos(angle);sine=(float)Math.Sin(angle);}
        V3 P(float x,float y,float z){if(Pitch!=0){float px=x;x=px*(float)Math.Cos(Pitch)-z*(float)Math.Sin(Pitch);z=px*(float)Math.Sin(Pitch)+z*(float)Math.Cos(Pitch);}return new V3(OriginX+x*XScale*cosine-y*YScale*sine,OriginY+x*XScale*sine+y*YScale*cosine,OriginZ+z*ZScale);}
        void Vertex(V3 p,Color c,float shade){if(Count+7>Data.Length)throw new InvalidOperationException("3D geometry limit exceeded");Data[Count++]=c.R/255f*shade;Data[Count++]=c.G/255f*shade;Data[Count++]=c.B/255f*shade;Data[Count++]=c.A/255f;Data[Count++]=p.X;Data[Count++]=p.Y;Data[Count++]=p.Z;}
        public void Surface(V3 a,V3 b,V3 c,Color color){float ux=b.X-a.X,uy=b.Y-a.Y,uz=b.Z-a.Z,vx=c.X-a.X,vy=c.Y-a.Y,vz=c.Z-a.Z;float nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx,n=(float)Math.Sqrt(nx*nx+ny*ny+nz*nz);float diffuse=n>.001f?Math.Max(0,(-.45f*nx-.55f*ny+.704f*nz)/n):1;Tri(a,b,c,color,.36f+.64f*diffuse);}
        public void Tri(V3 a,V3 b,V3 c,Color color,float shade){shade=(float)Math.Sqrt(Math.Max(0,shade*Light));Vertex(a,color,shade);Vertex(b,color,shade);Vertex(c,color,shade);}
        void Quad(V3 a,V3 b,V3 c,V3 d,Color color,float shade){Surface(a,b,c,color);Surface(a,c,d,color);}
        public void Torso(float x,float y,float z,float height,Color color){V3 a=P(x-9,y-9,z),b=P(x+9,y-9,z),c=P(x+9,y+9,z),d=P(x-9,y+9,z),aa=P(x-10,y-13,z+height),bb=P(x+10,y-13,z+height),cc=P(x+10,y+13,z+height),dd=P(x-10,y+13,z+height);Quad(a,b,bb,aa,color,1);Quad(b,c,cc,bb,color,1);Quad(c,d,dd,cc,color,1);Quad(d,a,aa,dd,color,1);Quad(aa,bb,cc,dd,color,1);}
        public void Box(float x,float y,float z,float w,float h,float tall,Color color){V3 a=P(x,y,z),b=P(x+w,y,z),c=P(x+w,y+h,z),d=P(x,y+h,z),aa=P(x,y,z+tall),bb=P(x+w,y,z+tall),cc=P(x+w,y+h,z+tall),dd=P(x,y+h,z+tall);Quad(aa,bb,cc,dd,color,1);Quad(a,b,bb,aa,color,.68f);Quad(b,c,cc,bb,color,.76f);Quad(c,d,dd,cc,color,.88f);Quad(d,a,aa,dd,color,.72f);}
        public void PropellerBlade(float x,float y,float z,float endY,float endZ,Color color){float dy=endY-y,dz=endZ-z,len=(float)Math.Sqrt(dy*dy+dz*dz),ny=-dz/len*4,nz=dy/len*4;Quad(P(x,y+ny,z+nz),P(x,y-ny,z-nz),P(x,endY-ny,endZ-nz),P(x,endY+ny,endZ+nz),color,1);}
        public void Limb(float x,float y,float z,float endX,float endZ,float width,float depth,Color color){
            float dx=endX-x,dz=endZ-z,len=(float)Math.Sqrt(dx*dx+dz*dz);if(len<.01f)return;float nx=dz/len*width/2,nz=-dx/len*width/2;
            V3 a=P(x-nx,y-depth/2,z-nz),b=P(x+nx,y-depth/2,z+nz),c=P(x+nx,y+depth/2,z+nz),d=P(x-nx,y+depth/2,z-nz),aa=P(endX-nx,y-depth/2,endZ-nz),bb=P(endX+nx,y-depth/2,endZ+nz),cc=P(endX+nx,y+depth/2,endZ+nz),dd=P(endX-nx,y+depth/2,endZ-nz);
            Quad(a,b,bb,aa,color,1);Quad(b,c,cc,bb,color,1);Quad(c,d,dd,cc,color,1);Quad(d,a,aa,dd,color,1);Quad(aa,bb,cc,dd,color,1);
        }
        public void Roof(float x,float y,float z,float w,float h,float rise,Color color){V3 a=P(x,y,z),b=P(x+w,y,z),c=P(x+w,y+h,z),d=P(x,y+h,z),l=P(x,y+h/2,z+rise),r=P(x+w,y+h/2,z+rise);Quad(a,b,r,l,color,.96f);Quad(l,r,c,d,color,.7f);Tri(a,l,d,color,.62f);Tri(b,c,r,color,.82f);}
        public void Cone(float x,float y,float z,float radius,float tall,Color color){for(int i=0;i<8;i++){float a=i*(float)Math.PI/4,b=(i+1)*(float)Math.PI/4;Tri(P(x+(float)Math.Cos(a)*radius,y+(float)Math.Sin(a)*radius,z),P(x+(float)Math.Cos(b)*radius,y+(float)Math.Sin(b)*radius,z),P(x,y,z+tall),color,.7f+.3f*(i%3)/2);}}
        public void BuildingShadow(float x,float y,float w,float h,float height){float dx=height*.64f,dy=height*.78f;V3[] hull={new V3(x,y,.15f),new V3(x+w,y,.15f),new V3(x+w+dx,y+dy,.15f),new V3(x+w+dx,y+h+dy,.15f),new V3(x+dx,y+h+dy,.15f),new V3(x,y+h,.15f)};for(int i=1;i<5;i++)Tri(hull[0],hull[i],hull[i+1],Color.FromArgb(78,22,27,34),1);}
        public void Shadow(float x,float y,float z,float rx,float ry,int alpha){Color color=Color.FromArgb(alpha,16,21,18);for(int i=0;i<16;i++){float a=i*(float)Math.PI/8,b=(i+1)*(float)Math.PI/8;Tri(P(x,y,z),P(x+(float)Math.Cos(a)*rx,y+(float)Math.Sin(a)*ry,z),P(x+(float)Math.Cos(b)*rx,y+(float)Math.Sin(b)*ry,z),color,1);}}
        static readonly float[] RingCos=new float[12],RingSin=new float[12];
        static ThreeDMesh(){for(int i=0;i<12;i++){RingCos[i]=(float)Math.Cos(i*Math.PI/6);RingSin[i]=(float)Math.Sin(i*Math.PI/6);}}
        public void Cylinder(float x,float y,float z,float rx,float ry,float height,Color color){for(int i=0;i<12;i++){int j=(i+1)%12;V3 a=P(x+rx*RingCos[i],y+ry*RingSin[i],z),b=P(x+rx*RingCos[j],y+ry*RingSin[j],z),c=P(x+rx*RingCos[j],y+ry*RingSin[j],z+height),d=P(x+rx*RingCos[i],y+ry*RingSin[i],z+height);Quad(a,b,c,d,color,.72f+.18f*RingSin[i]);Tri(P(x,y,z+height),d,c,color,1);}}
        public void Oval(float x,float y,float z,float rx,float ry,float rz,Color color){for(int ring=0;ring<4;ring++){float a=-1.5707963f+ring*.7853982f,b=a+.7853982f,ca=(float)Math.Cos(a),cb=(float)Math.Cos(b),sa=(float)Math.Sin(a),sb=(float)Math.Sin(b);for(int i=0;i<12;i++){int j=(i+1)%12;V3 p=P(x+rx*ca*RingCos[i],y+ry*ca*RingSin[i],z+rz*sa),q=P(x+rx*ca*RingCos[j],y+ry*ca*RingSin[j],z+rz*sa),r=P(x+rx*cb*RingCos[j],y+ry*cb*RingSin[j],z+rz*sb),t=P(x+rx*cb*RingCos[i],y+ry*cb*RingSin[i],z+rz*sb);Quad(p,q,r,t,color,.68f+.08f*ring+.07f*RingSin[i]);}}}
        public void Wheel(float x,float y,float z,float radius,float width,Color color){for(int i=0;i<12;i++){int j=(i+1)%12;V3 a=P(x+radius*RingCos[i],y,z+radius*RingSin[i]),b=P(x+radius*RingCos[j],y,z+radius*RingSin[j]),c=P(x+radius*RingCos[j],y+width,z+radius*RingSin[j]),d=P(x+radius*RingCos[i],y+width,z+radius*RingSin[i]);Quad(a,b,c,d,color,.8f);Tri(P(x,y,z),b,a,color,.7f);Tri(P(x,y+width,z),d,c,color,.95f);}}
        public void Strip(PointF a,PointF b,float width,float z,Color color){float dx=b.X-a.X,dy=b.Y-a.Y,n=(float)Math.Sqrt(dx*dx+dy*dy);if(n<.01)return;float nx=-dy/n*width/2,ny=dx/n*width/2;Quad(new V3(a.X+nx,a.Y+ny,z),new V3(b.X+nx,b.Y+ny,z),new V3(b.X-nx,b.Y-ny,z),new V3(a.X-nx,a.Y-ny,z),color,1);}
    }
}






