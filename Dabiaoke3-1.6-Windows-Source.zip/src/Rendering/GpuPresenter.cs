using System;
using System.Runtime.InteropServices;
namespace ArthurFrontier {
    /// <summary>Uploads one bounded frame to OpenGL; the GPU scales it to the window.</summary>
    sealed partial class GpuPresenter : IDisposable {
        IntPtr window,dc,context;
        uint texture;
        public string Device {
            get;
            private set;
        }
        public bool Hardware {
            get;
            private set;
        }
        [StructLayout(LayoutKind.Sequential)] struct PixelFormat {
            public ushort Size,Version;
            public uint Flags;
            public byte PixelType,ColorBits,RedBits,RedShift,GreenBits,GreenShift,BlueBits,BlueShift,AlphaBits,AlphaShift,AccumBits,AccumRedBits,AccumGreenBits,AccumBlueBits,AccumAlphaBits,DepthBits,StencilBits,AuxBuffers,LayerType,Reserved;
            public uint LayerMask,VisibleMask,DamageMask;
        }
        [UnmanagedFunctionPointer(CallingConvention.Winapi)] delegate bool SwapInterval(int interval);
        [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr hwnd);
        [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr hwnd,IntPtr dc);
        [DllImport("gdi32.dll")] static extern int ChoosePixelFormat(IntPtr dc,ref PixelFormat format);
        [DllImport("gdi32.dll")] static extern int DescribePixelFormat(IntPtr dc,int index,uint size,ref PixelFormat format);
        [DllImport("gdi32.dll")] static extern bool SetPixelFormat(IntPtr dc,int index,ref PixelFormat format);
        [DllImport("gdi32.dll")] static extern bool SwapBuffers(IntPtr dc);
        [DllImport("opengl32.dll")] static extern IntPtr wglCreateContext(IntPtr dc);
        [DllImport("opengl32.dll")] static extern bool wglMakeCurrent(IntPtr dc,IntPtr context);
        [DllImport("opengl32.dll")] static extern bool wglDeleteContext(IntPtr context);
        [DllImport("opengl32.dll",CharSet=CharSet.Ansi)] static extern IntPtr wglGetProcAddress(string name);
        [DllImport("opengl32.dll")] static extern IntPtr glGetString(uint name);
        [DllImport("opengl32.dll")] static extern void glGenTextures(int count,out uint name);
        [DllImport("opengl32.dll")] static extern void glDeleteTextures(int count,ref uint name);
        [DllImport("opengl32.dll")] static extern void glBindTexture(uint target,uint name);
        [DllImport("opengl32.dll")] static extern void glTexParameteri(uint target,uint name,int value);
        [DllImport("opengl32.dll")] static extern void glPixelStorei(uint name,int value);
        [DllImport("opengl32.dll")] static extern void glTexImage2D(uint target,int level,int internalFormat,int width,int height,int border,uint format,uint type,IntPtr data);
        [DllImport("opengl32.dll")] static extern void glTexSubImage2D(uint target,int level,int x,int y,int width,int height,uint format,uint type,IntPtr data);
        [DllImport("opengl32.dll")] static extern void glEnable(uint state);
        [DllImport("opengl32.dll")] static extern void glDisable(uint state);
        [DllImport("opengl32.dll")] static extern void glViewport(int x,int y,int width,int height);
        [DllImport("opengl32.dll")] static extern void glMatrixMode(uint mode);
        [DllImport("opengl32.dll")] static extern void glLoadIdentity();
        [DllImport("opengl32.dll")] static extern void glOrtho(double left,double right,double bottom,double top,double near,double far);
        [DllImport("opengl32.dll")] static extern void glClearColor(float r,float g,float b,float a);
        [DllImport("opengl32.dll")] static extern void glClear(uint mask);
        [DllImport("opengl32.dll")] static extern void glBegin(uint mode);
        [DllImport("opengl32.dll")] static extern void glEnd();
        [DllImport("opengl32.dll")] static extern void glTexCoord2f(float x,float y);
        [DllImport("opengl32.dll")] static extern void glVertex2f(float x,float y);
        [DllImport("opengl32.dll")] static extern void glColor4f(float r,float g,float b,float a);
        [DllImport("opengl32.dll")] static extern void glBlendFunc(uint source,uint destination);
        [DllImport("opengl32.dll")] static extern void glFinish();
        [DllImport("opengl32.dll")] static extern uint glGetError();
        public GpuPresenter(IntPtr handle) {
            window=handle;
            dc=GetDC(window);
            try {
                PixelFormat format=new PixelFormat {
                    Size=(ushort)Marshal.SizeOf(typeof(PixelFormat)),Version=1,Flags=0x25,PixelType=0,ColorBits=32,AlphaBits=8,DepthBits=24,LayerType=0
                };
                int index=ChoosePixelFormat(dc,ref format);
                PixelFormat actual=new PixelFormat();
                DescribePixelFormat(dc,index,(uint)Marshal.SizeOf(typeof(PixelFormat)),ref actual);
                if((actual.Flags&0x40)!=0&&(actual.Flags&0x1000)==0)throw new InvalidOperationException("Only software OpenGL is available; using direct GDI");
                if(index==0||!SetPixelFormat(dc,index,ref format))throw new InvalidOperationException("OpenGL pixel format unavailable");
                context=wglCreateContext(dc);
                if(context==IntPtr.Zero||!wglMakeCurrent(dc,context))throw new InvalidOperationException("OpenGL context unavailable");
                Device=Marshal.PtrToStringAnsi(glGetString(0x1F01))??"Unknown";
                Hardware=Device.IndexOf("GDI Generic",StringComparison.OrdinalIgnoreCase)<0&&Device.IndexOf("llvmpipe",StringComparison.OrdinalIgnoreCase)<0&&Device.IndexOf("software",StringComparison.OrdinalIgnoreCase)<0;
                IntPtr swap=wglGetProcAddress("wglSwapIntervalEXT");
                if(swap!=IntPtr.Zero&&swap!=new IntPtr(1)&&swap!=new IntPtr(2)&&swap!=new IntPtr(3)&&swap!=new IntPtr(-1))((SwapInterval)Marshal.GetDelegateForFunctionPointer(swap,typeof(SwapInterval)))(0);
                glGenTextures(1,out texture);
                glBindTexture(0x0DE1,texture);
                glTexParameteri(0x0DE1,0x2801,0x2600);
                glTexParameteri(0x0DE1,0x2800,0x2600);
                glTexParameteri(0x0DE1,0x2802,0x2900);
                glTexParameteri(0x0DE1,0x2803,0x2900);
                glTexImage2D(0x0DE1,0,0x1908,2048,1024,0,0x80E1,0x1401,IntPtr.Zero);
                glDisable(0x0B71);
                glDisable(0x0BE2);
                glEnable(0x0DE1);
                glClearColor(0,0,0,1);
                if(glGetError()!=0)throw new InvalidOperationException("OpenGL texture allocation unavailable");
            }
            catch {
                Dispose();
                throw;
            }
        }
        public void Present(IntPtr pixels,int width,int height,bool synchronizeForTest=false,bool deadEye=false) {
            if(!wglMakeCurrent(dc,context))throw new InvalidOperationException("Cannot activate OpenGL context");
            glDisable(0x0B71);glEnable(0x0DE1);
            glViewport(0,0,width,height);
            glMatrixMode(0x1701);
            glLoadIdentity();
            glOrtho(0,width,height,0,-1,1);
            glMatrixMode(0x1700);
            glLoadIdentity();
            glClear(0x4000);
            glBindTexture(0x0DE1,texture);
            glPixelStorei(0x0CF5,4);
            glTexSubImage2D(0x0DE1,0,0,0,1280,800,0x80E1,0x1401,pixels);
            float scale=Math.Min(width/1280f,height/800f),w=1280*scale,h=800*scale,x=(width-w)/2,y=(height-h)/2;
            glColor4f(1,1,1,1);
            glBegin(7);
            glTexCoord2f(0,0);
            glVertex2f(x,y);
            glTexCoord2f(1280f/2048,0);
            glVertex2f(x+w,y);
            glTexCoord2f(1280f/2048,800f/1024);
            glVertex2f(x+w,y+h);
            glTexCoord2f(0,800f/1024);
            glVertex2f(x,y+h);
            glEnd();
            if(deadEye) {
                glDisable(0x0DE1);
                glEnable(0x0BE2);
                glBlendFunc(0x0302,0x0303);
                glColor4f(.55f,.145f,.05f,.19f);
                glBegin(7);
                glVertex2f(x,y);
                glVertex2f(x+w,y);
                glVertex2f(x+w,y+h);
                glVertex2f(x,y+h);
                glEnd();
                glDisable(0x0BE2);
                glEnable(0x0DE1);
            }
            if(!SwapBuffers(dc))throw new InvalidOperationException("OpenGL frame swap failed");
            if(synchronizeForTest)glFinish();
        }
        public void Dispose() {
            overlay3.Dispose();
            if(context!=IntPtr.Zero) {
                wglMakeCurrent(dc,context);
                if(texture!=0) {
                    glDeleteTextures(1,ref texture);
                    texture=0;
                }
                wglMakeCurrent(IntPtr.Zero,IntPtr.Zero);
                wglDeleteContext(context);
                context=IntPtr.Zero;
            }
            if(dc!=IntPtr.Zero) {
                ReleaseDC(window,dc);
                dc=IntPtr.Zero;
            }
        }
    }
}

