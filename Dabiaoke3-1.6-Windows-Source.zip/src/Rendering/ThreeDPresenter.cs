﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
namespace ArthurFrontier {
    sealed partial class GpuPresenter {
        readonly ThreeDMesh mesh3=new ThreeDMesh();
        readonly Bitmap overlay3=new Bitmap(1280,800,System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
        [DllImport("opengl32.dll")] static extern void glFrustum(double l,double r,double b,double t,double n,double f);
        [DllImport("opengl32.dll")] static extern void glLoadMatrixd(double[] matrix);
        [DllImport("opengl32.dll")] static extern void glInterleavedArrays(uint format,int stride,IntPtr data);
        [DllImport("opengl32.dll")] static extern void glDrawArrays(uint mode,int first,int count);
        [DllImport("opengl32.dll")] static extern void glDisableClientState(uint state);
        [DllImport("opengl32.dll")] static extern void glDepthFunc(uint mode);
        [DllImport("opengl32.dll")] static extern void glReadPixels(int x,int y,int w,int h,uint format,uint type,IntPtr data);
        [DllImport("opengl32.dll")] static extern void glVertexPointer(int size,uint type,int stride,IntPtr pointer);
        [DllImport("opengl32.dll")] static extern void glColorPointer(int size,uint type,int stride,IntPtr pointer);
        [DllImport("opengl32.dll")] static extern void glEnableClientState(uint state);
        [DllImport("opengl32.dll")] static extern void glFogf(uint name,float value);
        [DllImport("opengl32.dll")] static extern void glFogfv(uint name,float[] values);
        public int LastTriangles;
        void DrawMesh3(){GCHandle pin=GCHandle.Alloc(mesh3.Data,GCHandleType.Pinned);try{glEnableClientState(0x8074);glEnableClientState(0x8076);glColorPointer(4,0x1406,28,pin.AddrOfPinnedObject());glVertexPointer(3,0x1406,28,IntPtr.Add(pin.AddrOfPinnedObject(),16));glDrawArrays(4,0,mesh3.Count/7);}finally{pin.Free();}glDisableClientState(0x8074);glDisableClientState(0x8076);}
        public void Present3D(FrontierGame game,int width,int height,string screenshot=null){
            if(!wglMakeCurrent(dc,context))throw new InvalidOperationException("Cannot activate 3D context");
            float s=Math.Min(width/1280f,height/800f);int w=(int)(1280*s),h=(int)(800*s),ox=(width-w)/2,oy=(height-h)/2;glViewport(ox,oy,w,h);
            float night=game.IsFrontier?game.NightStrength:0,rain=game.RainStrength3;float skyR=(.42f+rain*.02f)*(1-night*.9f),skyG=(.65f-rain*.14f)*(1-night*.9f),skyB=(.82f-rain*.24f)*(1-night*.8f);glClearColor(skyR,skyG,skyB,1);glClear(0x4000|0x0100);glDisable(0x0DE1);glEnable(0x0BE2);glBlendFunc(0x0302,0x0303);glEnable(0x0B71);glDepthFunc(0x0203);
            glMatrixMode(0x1701);glLoadIdentity();glFrustum(-640d/FrontierGame.CameraFocal*10,640d/FrontierGame.CameraFocal*10,-400d/FrontierGame.CameraFocal*10,400d/FrontierGame.CameraFocal*10,10,6500);
            double c=Math.Cos(game.CameraYaw),sn=Math.Sin(game.CameraYaw),sp=game.CameraSin,cp=game.CameraCos,x=game.CameraX,y=game.CameraY,ground=game.Ground3(game.CameraX,game.CameraY)+game.CameraFocusHeight;
            glMatrixMode(0x1700);glLoadMatrixd(new[]{c,sn*sp,-sn*cp,0d,sn,-c*sp,c*cp,0d,0d,cp,sp,0d,-c*x-sn*y,-sn*sp*x+c*sp*y-cp*ground,sn*cp*x-c*cp*y-sp*ground-game.CameraRange3,1d});
            glDisable(0x0B71);glDisable(0x0B60);game.BuildSky3(mesh3);DrawMesh3();glEnable(0x0B71);
            glEnable(0x0B60);glFogf(0x0B65,0x2601);glFogf(0x0B63,1400);glFogf(0x0B64,3000);glFogfv(0x0B66,new[]{skyR,skyG,skyB,1f});game.Build3D(mesh3);DrawMesh3();LastTriangles=mesh3.Count/21;glDisableClientState(0x8074);glDisableClientState(0x8076);glDisable(0x0B71);
            glDisable(0x0B60);using(Graphics q=Graphics.FromImage(overlay3))game.Render3DOverlay(q);
            glMatrixMode(0x1701);glLoadIdentity();glOrtho(0,1280,800,0,-1,1);glMatrixMode(0x1700);glLoadIdentity();glEnable(0x0DE1);glBindTexture(0x0DE1,texture);BitmapData pixels=overlay3.LockBits(new Rectangle(0,0,1280,800),ImageLockMode.ReadOnly,System.Drawing.Imaging.PixelFormat.Format32bppPArgb);try{glTexSubImage2D(0x0DE1,0,0,0,1280,800,0x80E1,0x1401,pixels.Scan0);}finally{overlay3.UnlockBits(pixels);}glEnable(0x0BE2);glBlendFunc(1,0x0303);glColor4f(1,1,1,1);glBegin(7);glTexCoord2f(0,0);glVertex2f(0,0);glTexCoord2f(1280f/2048,0);glVertex2f(1280,0);glTexCoord2f(1280f/2048,800f/1024);glVertex2f(1280,800);glTexCoord2f(0,800f/1024);glVertex2f(0,800);glEnd();glDisable(0x0BE2);
            if(screenshot!=null){using(Bitmap capture=new Bitmap(w,h,System.Drawing.Imaging.PixelFormat.Format32bppArgb)){BitmapData b=capture.LockBits(new Rectangle(0,0,w,h),ImageLockMode.WriteOnly,System.Drawing.Imaging.PixelFormat.Format32bppArgb);try{glReadPixels(ox,oy,w,h,0x80E1,0x1401,b.Scan0);}finally{capture.UnlockBits(b);}capture.RotateFlip(RotateFlipType.RotateNoneFlipY);capture.Save(screenshot);}}
            uint error=glGetError();if(error!=0)throw new InvalidOperationException("3D GL error "+error);if(!SwapBuffers(dc))throw new InvalidOperationException("3D swap failed");
        }
    }
}







