﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Media;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
namespace ArthurFrontier {
    sealed class FrontierWindow : Form {
        public readonly FrontierGame Game=new FrontierGame();
        readonly HashSet<Keys> physicalKeys=new HashSet<Keys>();
        readonly GameRenderer renderer=new GameRenderer();
        GpuPresenter gpu;
        bool gpuDisabled;
        public string GraphicsDevice="Direct GDI";
        internal bool ProbeMode;
        public int PresentedFrames;
        public double LastPaintMs;
        readonly FrameClock timer;
        readonly Stopwatch watch=Stopwatch.StartNew();
        double last,fpsStart;
        int frameQueued,fpsFrames;
        long nextFrameTick;
        volatile bool active;
        bool timerResolution;
        [DllImport("winmm.dll")] static extern uint timeBeginPeriod(uint period);
        [DllImport("winmm.dll")] static extern uint timeEndPeriod(uint period);
        bool fullscreen,cursorHidden;
        Rectangle oldBounds;
        FormWindowState oldState;
        public FrontierWindow() {
            Text="大镖客3 — 方块世界 1.6";
            ClientSize=new Size(1280,800);
            MinimumSize=new Size(976,639);
            StartPosition=FormStartPosition.CenterScreen;
            BackColor=Color.Black;
            KeyPreview=true;
            DoubleBuffered=false;
            SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.UserPaint|ControlStyles.Opaque,true);
            SetStyle(ControlStyles.OptimizedDoubleBuffer,false);
            try {
                Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            }
            catch {
            }
            timerResolution=timeBeginPeriod(1)==0;
            timer=new FrameClock(delegate {
                QueueFrame(null);
            });
        }
        protected override CreateParams CreateParams {
            get {
                CreateParams p=base.CreateParams;
                p.ClassStyle|=0x20;
                p.Style|=0x06000000;
                return p;
            }
        }
        protected override void OnHandleCreated(EventArgs e) {
            base.OnHandleCreated(e);
            if(gpuDisabled)return;
            try {
                gpu=new GpuPresenter(Handle);
                GraphicsDevice=gpu.Device;
                Game.RenderBackend="GPU 3D";Game.Use3D=true;
            }
            catch(Exception ex) {
                GraphicsDevice=ex.Message;
                gpuDisabled=true;
                Game.RenderBackend="GDI 兼容";Game.Use3D=false;
            }
        }
        protected override void OnHandleDestroyed(EventArgs e) {
            if(gpu!=null) {
                gpu.Dispose();
                gpu=null;
            }
            base.OnHandleDestroyed(e);
        }
        void QueueFrame(object unused) {
            if(!active||Stopwatch.GetTimestamp()<Interlocked.Read(ref nextFrameTick)||IsDisposed||Disposing||!IsHandleCreated||Interlocked.CompareExchange(ref frameQueued,1,0)!=0)return;
            try {
                BeginInvoke(new MethodInvoker(delegate {
                    try {
                        if(IsDisposed||Disposing||!active)return;
                        double now=watch.Elapsed.TotalSeconds;
                        if((Game.Paused||Game.State!="playing")&&now-last<1.0/15)return;
                        long frameStart=Stopwatch.GetTimestamp();
                        float dt=(float)Math.Min(.1,now-last);
                        last=now;
                        // Bounded substeps preserve collision accuracy during occasional scheduling delays.
                        while(dt>0) {
                            float step=Math.Min(dt,1f/60);
                            Game.Update(step);
                            dt-=step;
                        }
                        UpdateCursor();
                        if(ProbeMode) {
                            using(Graphics q=Graphics.FromHwnd(Handle))OnPaint(new PaintEventArgs(q,ClientRectangle));
                        }
                        else {
                            Invalidate();
                            Update();
                        }
                        Interlocked.Exchange(ref nextFrameTick,frameStart+(long)(Stopwatch.Frequency*(Game.Paused||Game.State!="playing"?1.0/15:1.0/60)));
                        if(now-fpsStart>=.75) {
                            Game.DisplayFps=(int)Math.Round(fpsFrames/(now-fpsStart));
                            fpsFrames=0;
                            fpsStart=now;
                        }
                    }
                    finally {
                        Interlocked.Exchange(ref frameQueued,0);
                    }
                }));
            }
            catch(InvalidOperationException) {
                Interlocked.Exchange(ref frameQueued,0);
            }
        }
        PointF Logical(Point p) {
            float s=Math.Min(ClientSize.Width/1280f,ClientSize.Height/800f);
            return new PointF((p.X-(ClientSize.Width-1280*s)/2)/s,(p.Y-(ClientSize.Height-800*s)/2)/s);
        }
        protected override void OnPaintBackground(PaintEventArgs e) {
        }
        protected override void OnPaint(PaintEventArgs e) {
            Stopwatch clock=Stopwatch.StartNew();
            bool presented=false;
            if(gpu!=null) {
                try {
                    if(Game.Use3D&&Game.State!="intro")gpu.Present3D(Game,ClientSize.Width,ClientSize.Height);else {
                    renderer.RenderFrame(Game);
                    gpu.Present(renderer.Pixels,ClientSize.Width,ClientSize.Height,ProbeMode,Game.DeadEye);
                    }presented=true;
                }
                catch(Exception ex) {
                    GraphicsDevice=ex.Message;
                    gpu.Dispose();
                    gpu=null;
                    gpuDisabled=true;
                    Game.RenderBackend="GDI 兼容";Game.Use3D=false;
                }
            }
            if(!presented)renderer.Draw(Game,e.Graphics,ClientSize.Width,ClientSize.Height);
            PresentedFrames++;
            fpsFrames++;
            LastPaintMs=clock.Elapsed.TotalMilliseconds;
        }
        internal void BeginProbe() {
            ProbeMode=true;
            IntPtr handle=Handle;
            OnActivated(EventArgs.Empty);
        }
        protected override void OnMouseWheel(MouseEventArgs e){base.OnMouseWheel(e);Game.CameraDistance=Math.Max(Game.Flying?500:220,Math.Min(Game.Flying?1100:520,Game.CameraDistance-e.Delta*.25f));}
        internal void Capture3D(string path){if(gpu==null)throw new InvalidOperationException(GraphicsDevice);gpu.Present3D(Game,ClientSize.Width,ClientSize.Height,path);}
        bool GameplayPointer {get{return Game.State=="playing"&&!Game.Paused&&!Game.WorldMap&&!Game.ShowCredits;}}
        protected override void OnMouseMove(MouseEventArgs e) {
            base.OnMouseMove(e);
            if(cursorHidden&&active&&GameplayPointer) {
                Point center=new Point(ClientSize.Width/2,ClientSize.Height/2);
                float scale=Math.Min(ClientSize.Width/1280f,ClientSize.Height/800f);
                Game.MoveAim((e.X-center.X)/scale,(e.Y-center.Y)/scale);
                if(e.Location!=center)Cursor.Position=PointToScreen(center);
            }
            else Game.Mouse=Game.Use3D&&GameplayPointer?new PointF(640,400):Logical(e.Location);
            Game.MouseInside=true;
        }
        protected override void OnMouseDown(MouseEventArgs e) {
            base.OnMouseDown(e);
            Focus();
            if(!cursorHidden||!GameplayPointer)Game.Mouse=Game.Use3D&&GameplayPointer?new PointF(640,400):Logical(e.Location);
            if(e.Button==MouseButtons.Left)Game.Click(Game.Mouse.X,Game.Mouse.Y);
            if(e.Button==MouseButtons.Right&&GameplayPointer)Game.MarkDeadEye();
            UpdateCursor();
        }
        protected override void OnMouseUp(MouseEventArgs e) {
            base.OnMouseUp(e);
            if(e.Button==MouseButtons.Left)Game.MouseHeld=false;
        }
        protected override void OnMouseLeave(EventArgs e) {
            base.OnMouseLeave(e);
            Game.MouseHeld=false;
            Game.MouseInside=false;
            UpdateCursor();
        }
        protected override void OnKeyDown(KeyEventArgs e) {
            base.OnKeyDown(e);
            bool fresh=physicalKeys.Add(e.KeyCode);if(Game.Use3D&&e.KeyCode==Keys.ControlKey){if(fresh&&Game.State=="playing"&&!Game.Paused)Game.ToggleCameraLock3();e.Handled=true;e.SuppressKeyPress=true;return;}
            if(fresh||!(e.KeyCode==Keys.F11||e.KeyCode==Keys.F3||e.KeyCode==Keys.Escape||e.KeyCode==Keys.E||e.KeyCode==Keys.F||e.KeyCode==Keys.Enter)) {
                if(Game.Use3D&&e.KeyCode==Keys.Z)Game.CameraYaw-=.15f;
                else if(Game.Use3D&&e.KeyCode==Keys.C)Game.CameraYaw+=.15f;
                else if(Game.Use3D&&e.KeyCode==Keys.V){Game.ResetFollowCamera3();}
                else if(e.KeyCode==Keys.F11)ToggleFullscreen();
                else if(e.KeyCode==Keys.F3)Game.ShowFps=!Game.ShowFps;
                else Game.KeyPressed(e.KeyCode);
            }
            UpdateCursor();
            e.Handled=true;
            e.SuppressKeyPress=true;
        }
        protected override void OnKeyUp(KeyEventArgs e) {
            base.OnKeyUp(e);
            physicalKeys.Remove(e.KeyCode);
            Game.KeysDown.Remove(e.KeyCode);
        }
        protected override void OnActivated(EventArgs e) {
            base.OnActivated(e);
            last=watch.Elapsed.TotalSeconds;
            fpsStart=last;
            fpsFrames=0;
            active=true;
        }
        protected override void OnDeactivate(EventArgs e) {
            active=false;
            base.OnDeactivate(e);
            physicalKeys.Clear();
            Game.LoseFocus();
            UpdateCursor();
        }
        protected override void OnFormClosing(FormClosingEventArgs e) {
            if(Game.IsFrontier&&Game.State=="playing")Game.SaveFrontier();
            base.OnFormClosing(e);
        }
        void UpdateCursor() {
            bool hide=active&&GameplayPointer&&Game.MouseInside;
            if(hide==cursorHidden)return;
            cursorHidden=hide;
            if(hide) { Cursor.Hide(); if(!ProbeMode)Cursor.Position=PointToScreen(new Point(ClientSize.Width/2,ClientSize.Height/2)); }
            else Cursor.Show();
        }
        void ToggleFullscreen() {
            if(!fullscreen) {
                oldBounds=Bounds;
                oldState=WindowState;
                WindowState=FormWindowState.Normal;
                FormBorderStyle=FormBorderStyle.None;
                Bounds=Screen.FromControl(this).Bounds;
                fullscreen=true;
            }
            else {
                FormBorderStyle=FormBorderStyle.Sizable;
                Bounds=oldBounds;
                WindowState=oldState;
                fullscreen=false;
            }
        }
        protected override void Dispose(bool disposing) {
            if(disposing) {
                active=false;
                timer.Dispose();
                if(timerResolution) {
                    timeEndPeriod(1);
                    timerResolution=false;
                }
                if(cursorHidden)Cursor.Show();
                renderer.Dispose();
                Game.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}








