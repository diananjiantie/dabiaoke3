using System;
using System.Drawing;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        void HouseDetail3(ThreeDMesh m,Building b){float x=b.X,y=b.Y,w=b.W,h=b.H;if(!Near3(x+w/2,y+h/2,1250))return;
            Color trim=Color.FromArgb(206,186,145),seam=Color.FromArgb(112,80,52);
            if(Near3(x+w/2,y+h/2,850))for(int row=0;row<6;row++)for(int grain=0;grain<5;grain++){float gx=x+12+((row*53+grain*47)%Math.Max(20,(int)w-40)),gz=12+row*13+grain%3;Color worn=grain%2==0?Color.FromArgb(149,108,69):Color.FromArgb(185,141,93);m.Box(gx,y+h+1.4f,gz,17+grain*3,.25f,.55f,worn);m.Box(x+w+1.4f,y+10+(grain*23+row*9)%Math.Max(20,(int)h-25),gz,.25f,13,.55f,worn);}
            for(int z=16;z<95;z+=13){m.Box(x-1,y,z,1,h,1.2f,seam);m.Box(x+w,y,z,1,h,1.2f,seam);m.Box(x,y-1,z,w,1,1.2f,seam);}
            foreach(float xx in new[]{x,x+w-5})foreach(float yy in new[]{y,y+h-5})m.Box(xx,yy,6,5,5,89,trim);
            m.Box(x-12,y-12,92,w+24,5,5,trim);m.Box(x-12,y+h+7,92,w+24,5,5,trim);
            for(float xx=x;xx<x+w;xx+=17)m.Box(xx,y+h+1,8,1,31,1,seam);
            m.Box(x+w/2-15,y+h+5,12,30,2,50,Color.FromArgb(116,66,35));m.Box(x+w/2+9,y+h+8,38,3,3,3,Color.Goldenrod);
            for(int side=0;side<2;side++){float wx=x+(side==0?20:w-56);m.Box(wx,y+h+8,57,34,2,2,trim);m.Box(wx-10,y+h+3,44,7,4,30,seam);m.Box(wx+37,y+h+3,44,7,4,30,seam);}
            for(float yy=y+30;yy<y+h-20;yy+=65){m.Box(x+w+1,yy,42,2,30,28,trim);m.Box(x+w+4,yy+3,45,2,24,22,Color.FromArgb(66,112,134));m.Box(x+w+7,yy+14,45,1,2,22,trim);}
            for(int z=100;z<140;z+=9)m.Box(x+24,y+24,z,26,26,1,Color.FromArgb(140,116,95));
            if(b.Kind=="saloon"||b.Kind=="store"){m.Box(x+8,y+h+23,8,6,6,76,trim);m.Box(x+w-14,y+h+23,8,6,6,76,trim);m.Box(x+3,y+h,82,w-6,35,5,Color.FromArgb(94,67,43));m.Box(x+w/2-39,y+h+2,74,78,5,16,Color.FromArgb(83,50,30));}
        }
        void GroundDetail3(ThreeDMesh m,int x,int y,bool water){if(!Near3(x+80,y+80,1050))return;m.At(0,0,0,0);int seed=Math.Abs((x*73+y*137)%97);
            if(water){for(int i=0;i<3;i++){float xx=x+20+(seed+i*29)%85,yy=y+25+i*39;m.Strip(new PointF(xx,yy),new PointF(xx+20+i*8,yy+3),1.6f,.4f,Color.FromArgb(96,166,186));}return;}
            for(int grain=0;grain<4;grain++){float px=x+14+(seed*13+grain*37)%130,py=y+11+(seed*7+grain*41)%130,pz=Ground3(px,py)-.55f;Color patch=SafeTown(px,py)?Color.FromArgb(154,124,85):Color.FromArgb(107,133,74);m.Tri(new V3(px,py,pz),new V3(px+7,py+1,Ground3(px+7,py+1)-.55f),new V3(px+3,py+6,Ground3(px+3,py+6)-.55f),patch,1);}
            if(SafeTown(x+80,y+80)||RoadDistance(x+80,y+80)<150||NearRail(x+80,y+80))return;
            for(int i=0;i<4;i++){float xx=x+19+(seed*11+i*37)%120,yy=y+15+(seed*7+i*53)%120,zz=Ground3(xx,yy);Color grass=i%2==0?Color.FromArgb(144,163,75):Color.FromArgb(82,119,45);for(int blade=0;blade<3;blade++){float dx=blade*4;m.Tri(new V3(xx+dx,yy,zz),new V3(xx+dx+3,yy+1,zz),new V3(xx+dx-2,yy+3,zz+9+blade*3),grass,1);}}
        }
    }
}

