﻿using System.Reflection;
[assembly: AssemblyTitle("大镖客3")]
[assembly: AssemblyDescription("银行与运钞马车抢劫、劫狱护送、帮派劫案、曲流河道与死眼瞄准修复")]
[assembly: AssemblyProduct("大镖客3")]
[assembly: AssemblyVersion("11.6.0.0")]
[assembly: AssemblyFileVersion("11.6.0.0")]









