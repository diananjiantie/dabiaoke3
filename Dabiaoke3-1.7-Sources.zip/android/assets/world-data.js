/* World coordinates and balance ported from desktop 9.5. All distances are world units. */
(function(root){'use strict';
const points=a=>a.map(([x,y])=>({x,y}));
const D={
road:points([[1500,2800],[2450,2800],[2800,1800],[3900,1200],[4800,2000],[4950,3700],[5600,4300],[6400,4300],[7150,3000],[8200,2600],[9000,3200],[9300,4200],[10500,4200]]),
spurs:[points([[4950,3700],[4400,4200],[3200,4100]]),points([[8200,2600],[8900,2100],[9100,1700]]),points([[1500,2800],[1500,4200],[2800,5200]]),points([[10500,4200],[11400,2600],[10900,1300]])],
rail:points([[1500,3300],[2600,3300],[3900,3700],[5200,3800],[6400,3500],[8000,3700],[9400,4700],[10500,4700],[10000,5500],[6500,5500],[5500,5000],[4500,5600],[2800,5650],[1400,5500],[700,4300],[1500,3300]]),
stations:points([[1500,3300],[10500,4700],[2800,5650]]),platforms:points([[1500,3460],[10500,4860],[2800,5810]]),stationNames:['日落镇','冷杉镇','石桥镇'],districtNames:['日落地区','冷杉地区','石桥地区','风蚀地区','白鹭岛'],
camps:points([[4100,1550],[8050,2950]]),plots:points([[3200,4100],[9100,1700]]),airports:points([[10900,1300],[22000,3000]]),
wagon:points([[2780,5160],[4300,5300],[4400,4200],[4950,3700],[5600,4300],[6400,4300],[7150,3000],[8200,2600],[9000,3200],[9300,4200],[10500,4200]]),
gallows:points([[3510,4840],[3550,5100],[3980,5100],[4160,4820],[4160,4740]]),intake:points([[3550,5050],[3510,4840],[3510,4640]]),
bankDoor:{x:2600,y:4970},vault:{x:2730,y:4500},cellDoor:{x:3510,y:4800},exit:{x:4060,y:5340},
walls:[[2250,4400,700,20],[2250,4400,20,500],[2930,4400,20,500],[2250,4880,280,20],[2670,4880,280,20],[2290,4660,160,65],[2720,4660,170,65],[2300,4440,180,75],[2780,4440,120,75],[3200,4500,720,20],[3200,4500,20,500],[3900,4500,20,500],[3200,4980,270,20],[3620,4980,300,20],[3240,4720,220,14],[3560,4720,320,14],[3310,4550,15,170],[3720,4550,15,170],[3260,4840,130,65]].map(([x,y,w,h])=>({x,y,w,h})),
buildings:[],services:[]};
for(let town=0;town<2;town++)for(let [x,y] of [[740,1950],[1040,1950],[1800,1950],[2110,1950],[2070,2380],[2070,2900]])D.buildings.push({x:x+town*9000,y:y+town*1400,w:180,h:125,label:'',kind:'home'});
for(let [x,y] of [[1720,4370],[2020,4370],[3100,4250],[3440,4250],[3780,4250],[4080,5200],[9660,1050],[9960,1400],[10260,1400],[11150,550],[21500,2950],[21500,3250],[21900,3250],[22300,3250],[22600,2750],[22600,3100]])D.buildings.push({x,y,w:180,h:125,label:'',kind:'home'});
const building=(x,y,w,h,label)=>D.buildings.push({x,y,w,h,label}),service=(name,kind,x,y,index=0)=>D.services.push({name,kind,x,y,index});
for(let i=0;i<2;i++){let x=i?10500:1500,y=i?1400:0,t=D.stationNames[i];building(x-460,2380+y,260,150,'SALOON');building(x+230,2380+y,240,150,'GUNSMITH');building(x-120,2070+y,240,140,'BOUNTIES');building(x-160,3060+y,320,130,'RAIL STATION');building(x-680,2870+y,190,160,'STABLE');service(t+'酒馆','saloon',x-330,2610+y,i);service(t+'枪械铺','gun',x+350,2610+y,i);service('赏金告示板','bounty',x,2280+y,i);service(t+'车站','station',x,3460+y,i);}
for(let b of [[9850,550,260,160,'WIND RIDGE'],[10400,550,240,150,'GUNSMITH'],[10780,900,300,160,'AIRFIELD'],[21700,2500,240,150,'EGRET ISLAND'],[22200,2550,220,150,'FISH MARKET'],[1720,4680,270,150,'STONEBRIDGE'],[1860,5250,230,140,'GUNSMITH'],[2650,5390,300,130,'STONEBRIDGE STATION']])building(...b);
for(let s of [['风蚀镇酒馆','saloon',9980,800,2],['风蚀镇枪械铺','gun',10520,800,2],['风蚀镇机场','airport',10900,1300,0],['白鹭岛机场','airport',22000,3000,1],['白鹭岛酒馆','saloon',21820,2750,3],['白鹭岛鱼市','fish',22310,2800,3],['石桥镇酒馆','saloon',1850,4940,4],['石桥镇枪械铺','gun',1980,5480,4],['银行入口','bankdoor',2600,4970],['银行金库','vault',2730,4500],['监狱牢门','prison',3510,4800],['劫狱接应点','escape',4060,5340],['石桥镇车站','station',2800,5810,2]])service(...s);
for(let i=0;i<2;i++){let c=D.camps[i];building(c.x-250,c.y+(i?300:-210),150,100,i?'IRON WOLVES':'RED SNAKES');building(c.x+180,c.y-180,90,70,'');service(i?'松林宅地':'河畔宅地','house',D.plots[i].x,D.plots[i].y+60,i);}
D.riverCenter=y=>6000+(1-Math.exp(-((y-4300)**2)/200000))*(380*Math.sin(y/710)+170*Math.sin(y/270));
D.riverWidth=y=>165+25*Math.sin(y/450)+15*Math.cos(y/190);
service('碧水河鱼贩','fish',D.riverCenter(3900)-D.riverWidth(3900)-140,3900);
D.length=path=>path.slice(1).reduce((n,p,i)=>n+Math.hypot(p.x-path[i].x,p.y-path[i].y),0);
D.along=(path,d)=>{for(let i=1;i<path.length;i++){let a=path[i-1],b=path[i],n=Math.hypot(b.x-a.x,b.y-a.y);if(d<=n){let f=Math.max(0,d)/n;return{x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f,angle:Math.atan2(b.y-a.y,b.x-a.x)};}d-=n;}let b=path[path.length-1],a=path[path.length-2];return{...b,angle:Math.atan2(b.y-a.y,b.x-a.x)};};
D.stationDistances=D.stations.map(s=>{let n=0;for(let i=0;i<D.rail.length;i++){if(i)n+=Math.hypot(D.rail[i].x-D.rail[i-1].x,D.rail[i].y-D.rail[i-1].y);if(D.rail[i].x===s.x&&D.rail[i].y===s.y)return n;}return n;});
D.cycle=D.length(D.rail)/950+24;
if(typeof module!=='undefined'&&module.exports)module.exports=D;else root.WorldData=D;
})(typeof window==='undefined'?globalThis:window);
