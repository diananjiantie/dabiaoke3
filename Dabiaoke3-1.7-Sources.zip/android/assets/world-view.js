/* Viewport-culling renderer: world size does not determine canvas size or sprite memory. */
(function(root){'use strict';const D=root.WorldData;
root.drawOpenWorld=function(g,a){const {ctx,project:P,vw,vh,poly,ellipse,line,box,label,cowboy,drawHorse,trees,grass}=a;
const text=(t,x,y,color='#f0dfb7',size=12)=>label(t,P(x,y,90),color,size),visible=(x,y,margin=180)=>{let p=P(x,y);return p.x>-margin&&p.x<vw+margin&&p.y>-margin&&p.y<vh+margin;};
const path=(pts,color,width)=>{ctx.strokeStyle=color;ctx.lineWidth=width*.68;ctx.beginPath();pts.forEach((p,i)=>{let q=P(p.x,p.y);i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y);});ctx.stroke();};
if(g.worldMap){drawMap(g,a);return;}
ctx.fillStyle='#718768';ctx.fillRect(0,0,vw,vh);
if(g.player.x>11500){ctx.fillStyle='#477f87';ctx.fillRect(0,0,vw,vh);let island=[];for(let i=0;i<=64;i++){let t=i/64*Math.PI*2;island.push(P(22000+Math.cos(t)*2600,3000+Math.sin(t)*2300));}poly(ctx,island,'#a4a277');let mainland=[P(55,55),P(12000,55),P(12000,5945),P(55,5945)];poly(ctx,mainland,'#718768');}
const groundRect=(x,y,w,h,color)=>poly(ctx,[P(x,y),P(x+w,y),P(x+w,y+h),P(x,y+h)],color);
for(let [x,y,w,h] of [[670,2200,1660,940],[9670,3600,1660,940],[1650,4350,2700,1230],[9600,450,1900,1100],[21400,2450,1500,1100]])if(visible(x+w/2,y+h/2,1400))groundRect(x,y,w,h,'#ad976e');
for(let [x,y] of [[1410,2060],[10410,3460]])groundRect(x,y,180,1450,'#c0aa80');
let river=[];for(let y=0;y<=6100;y+=75)river.push(P(D.riverCenter(y)-D.riverWidth(y),y));for(let y=6100;y>=0;y-=75)river.push(P(D.riverCenter(y)+D.riverWidth(y),y));poly(ctx,river,'#477f87');
for(let r of [D.road,...D.spurs])path(r,'#b5a27b',140);path([{x:5600,y:4300},{x:6400,y:4300}],'#947351',160);
// Modest decoration density, deterministic positions, and no world-sized offscreen bitmap.
let items=[],cx=Math.floor(g.camera.x/180),cy=Math.floor(g.camera.y/180);
for(let iy=cy-7;iy<=cy+7;iy++)for(let ix=cx-7;ix<=cx+7;ix++){let seed=Math.abs((ix*73856093^iy*19349663)>>>0),x=ix*180+seed%110,y=iy*180+(seed>>>8)%110;if(!visible(x,y)||g.ocean(x,y)||g.nearRiver(x,y)||g.roadDistance(x,y)<100)continue;let p=P(x,y);if(g.mountain(x,y)&&seed%3===0){let tall=95+seed%110;items.push({y,draw:()=>{poly(ctx,[P(x-85,y),P(x+85,y+10),P(x+20,y,tall)],'#676e60');poly(ctx,[P(x+20,y,tall),P(x+85,y+10),P(x+120,y)],'#555f54');}});}else if(seed%5===0&&!g.blocked(x,y,75))items.push({y,draw:()=>ctx.drawImage(trees,p.x-37,p.y-93,74,95)});else if(seed%2)ctx.drawImage(grass,p.x-12,p.y-12,24,16);}
path(D.rail,'#625b47',34);path(D.rail,'#323e37',7);for(let d=0,len=D.length(D.rail);d<len;d+=110){let p=D.along(D.rail,d);if(!visible(p.x,p.y,50))continue;let nx=-Math.sin(p.angle)*26,ny=Math.cos(p.angle)*26,aa=P(p.x+nx,p.y+ny),bb=P(p.x-nx,p.y-ny);line(ctx,aa.x,aa.y,bb.x,bb.y,'#a68c60',3);}
for(let b of g.buildings){if(!visible(b.x+b.w/2,b.y+b.h/2,350))continue;items.push({y:b.y+b.h,draw:()=>{if(root.DesktopView&&root.DesktopView.building(b,g,a))return;box(ctx,b.x,b.y,b.w,b.h,b.label?95:32,['#ad8a55','#665638','#8c7149']);if(b.label){let p=P(b.x+b.w/2,b.y+b.h),top=P(b.x+b.w/2,b.y+b.h,65);ctx.fillStyle='#332f27';ctx.fillRect(p.x-14,p.y-40,28,40);label(b.label,top,'#f0dab1',11);}}});}
for(let s of g.services){if(!visible(s.x,s.y,60))continue;let p=P(s.x,s.y);ellipse(ctx,p.x,p.y,12,6,'#cfb77766');if(Math.hypot(s.x-g.player.x,s.y-g.player.y)<300)text(s.name,s.x,s.y,'#f0dfb7',11);}
for(let i=0;i<2;i++){let p=D.plots[i],stage=g.houseStage[i];if(stage&&visible(p.x,p.y)){items.push({y:p.y,draw:()=>{if(stage===3&&root.DesktopView&&root.DesktopView.home(p,a))return;box(ctx,p.x-100,p.y-140,200,140,stage===1?8:85,['#b59864','#6e6144','#957d50']);if(stage===3){poly(ctx,[P(p.x-115,p.y-150,85),P(p.x,p.y-150,145),P(p.x+115,p.y-150,85),P(p.x+115,p.y+10,85),P(p.x,p.y+10,145),P(p.x-115,p.y+10,85)],'#68584b');}text('房屋 '+stage+'/3',p.x,p.y);}});}}
if(visible(2700,4700,650)||visible(3550,4750,650)){
poly(ctx,[P(2250,4400),P(2950,4400),P(2950,4900),P(2250,4900)],'#b8ae8b');poly(ctx,[P(3200,4500),P(3920,4500),P(3920,5000),P(3200,5000)],'#9eaa91');
for(let w of D.walls){if(!visible(w.x,w.y,400))continue;let bars=w.h===14||w.w===15,height=bars?78:w.h>100||w.w>250?85:35;let drawWall=(x,y,ww,hh)=>{if(bars){for(let n=0;n<ww;n+=25){let b=P(x+n,y),t=P(x+n,y,height);line(ctx,b.x,b.y,t.x,t.y,'#485950',2);}let s=P(x,y,height),t=P(x+ww,y,height);line(ctx,s.x,s.y,t.x,t.y,'#485950',3);}else box(ctx,x,y,ww,hh,height,['#aaa990','#6c7667','#8b947e']);};items.push({y:w.y+w.h,draw:()=>{if(g.escapeHole&&w.x===3200&&w.w===20){drawWall(w.x,w.y,20,140);drawWall(w.x,4710,20,290);}else drawWall(w.x,w.y,w.w,w.h);}});}
if(!(g.prisonFree||g.executionPhase===1||g.executionPhase===4))items.push({y:4734,draw:()=>{for(let x=3460;x<=3560;x+=20){let b=P(x,4720),t=P(x,4720,78);line(ctx,b.x,b.y,t.x,t.y,'#35493e',3);}}});
items.push({y:4550,draw:()=>{box(ctx,2685,4450,85,65,70,['#68736c','#313e39','#58655c']);text(g.bankLooted?'金库已空':'金库',2730,4500);}});
for(let p of [{x:3255,y:4580},{x:3400,y:4580},{x:3780,y:4580}])items.push({y:p.y+65,draw:()=>box(ctx,p.x,p.y,65,100,18,['#c1b69a','#6a705a','#929a7c'])});
for(let p of [{x:2330,y:4670},{x:2780,y:4670},{x:3300,y:4850}])items.push({y:p.y+15,draw:()=>{box(ctx,p.x,p.y,40,30,43,['#e0d3a6','#8d7957','#c5ad79']);let l=P(p.x+20,p.y,57);ellipse(ctx,l.x,l.y,4,6,'#edc363');}});
text('石桥银行',2590,4400);text('石桥监狱',3550,4500);
}
if(visible(4160,4740,300)){items.push({y:4795,draw:()=>{box(ctx,4050,4660,220,140,30,['#a1804c','#665132','#927343']);for(let x of [4070,4250]){let b=P(x,4700,30),t=P(x,4700,174);line(ctx,b.x,b.y,t.x,t.y,'#655033',8);}let aa=P(4070,4700,174),bb=P(4250,4700,174),rope=P(4160,4700,105),top=P(4160,4700,174);line(ctx,aa.x,aa.y,bb.x,bb.y,'#655033',8);line(ctx,top.x,top.y,rope.x,rope.y,'#d4c297',2);ctx.strokeStyle='#d4c297';ctx.beginPath();ctx.ellipse(rope.x,rope.y+6,5,7,0,0,Math.PI*2);ctx.stroke();if(g.executionPhase===3){let p=P(4160,4700,70);ctx.fillStyle='#797e60';ctx.fillRect(p.x-6,p.y-22,12,21);line(ctx,p.x-3,p.y-1,p.x-4,p.y+14,'#555e4c',3);line(ctx,p.x+3,p.y-1,p.x+4,p.y+14,'#555e4c',3);ellipse(ctx,p.x,p.y-29,5,6,'#bda179');}}});}
if(!g.prisonPaid&&g.executionPhase!==3&&visible(g.prisoner.x,g.prisoner.y))items.push({y:g.prisoner.y,draw:()=>cowboy({...g.prisoner,angle:1.5,step:g.time*5},'resident')});
for(let n of [...g.residents,...g.crowd])if(n.hp>0&&visible(n.x,n.y,90))items.push({y:n.y,draw:()=>cowboy(n,'resident')});
for(let e of g.enemies)if(e.hp>0&&visible(e.x,e.y,90))items.push({y:e.y,draw:()=>cowboy(e,e.police?'police':'enemy')});
let vehicle=(p,kind)=>{let c=Math.cos(p.angle),s=Math.sin(p.angle),pr=(x,y,z=0)=>P(p.x+x*c-y*s,p.y+x*s+y*c,z),b=(x,y,w,h,z,colors)=>box(ctx,x,y,w,h,z,colors,pr);b(-80,-34,160,68,35,['#9f8051','#354a40','#75613f']);if(kind==='engine'){b(-40,-28,90,56,70,['#4c6055','#263c35','#4d5c48']);b(25,-10,20,20,105,['#384b43','#273b32','#485b4d']);}else if(kind==='train')b(-65,-28,125,56,65,['#b19162','#534d37','#8b754d']);for(let x of [-55,55])for(let y of [-38,38]){let q=pr(x,y,10);ellipse(ctx,q.x,q.y,9,12,'#293b31');}if(kind==='wagon'){drawHorse(p.x+c*135,p.y+s*135,p.angle,g.time*8);}};
for(let i=0;i<3;i++){let p=g.railPoint(i*175);if(visible(p.x,p.y,220))items.push({y:p.y+40,draw:()=>vehicle(p,i?'train':'engine')});}
if(g.wagonActive){let p=g.wagonPosition;if(visible(p.x,p.y,250))items.push({y:p.y+45,draw:()=>{vehicle(p,'wagon');text(g.wagonLooted?'空马车':'运钞马车',p.x,p.y);}});}
for(let i=0;i<2;i++){let p=D.airports[i];if(visible(p.x,p.y,300)&&!g.flying)items.push({y:p.y+40,draw:()=>plane({...p,angle:i?Math.atan2(-1700,-11100):Math.atan2(1700,11100)},0,a)});}
if(!g.mounted&&g.horse.hp>0&&!g.flying&&!g.aboard&&visible(g.horse.x,g.horse.y))items.push({y:g.horse.y,draw:()=>drawHorse(g.horse.x,g.horse.y,0,0)});
if(!g.flying&&!g.aboard)items.push({y:g.player.y,draw:()=>cowboy(g.player,'arthur')});items.sort((aa,bb)=>aa.y-bb.y);for(let i of items)i.draw();
if(g.flying)plane(g.player,100*Math.sin(Math.PI*Math.min(1,g.flightTime/24)),a);
if(g.eventKind&&visible(g.eventPosition.x,g.eventPosition.y)){let p=P(g.eventPosition.x,g.eventPosition.y,35);poly(ctx,[{x:p.x,y:p.y-10},{x:p.x+9,y:p.y},{x:p.x,y:p.y+10},{x:p.x-9,y:p.y}],'#f0c56a');text('偶遇 · 互动',g.eventPosition.x,g.eventPosition.y);}
for(let b of g.bullets){if(!visible(b.x,b.y,20))continue;let p=P(b.x,b.y,22),from=b.visual?P(b.fromX,b.fromY,22):P(b.x-b.vx*.012,b.y-b.vy*.012,22);line(ctx,from.x,from.y,p.x,p.y,b.friendly?'#ffe4a0':'#e98654',2);}
for(let id of g.marks){let e=g.enemies.find(e=>e.id===id);if(e){let p=P(e.x,e.y,48);line(ctx,p.x-7,p.y-7,p.x+7,p.y+7,'#f5ac57',3);line(ctx,p.x+7,p.y-7,p.x-7,p.y+7,'#f5ac57',3);}}
if(!g.aboard&&!g.flying&&!g.captured){let p=P((g.aim||g.player).x,(g.aim||g.player).y,22);ctx.strokeStyle=g.eye?'#f3ca75':'#ede3c6';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(p.x,p.y,9,0,Math.PI*2);ctx.stroke();}
if(g.captured||g.escapeHole){let p=P(3210,4675,25);if(g.escapeHole)ellipse(ctx,p.x,p.y,12,20,'#27392f');else for(let i=0;i<g.digProgress/5;i++)line(ctx,p.x-10+i*3,p.y-13,p.x+5-i*2,p.y+12-i*3,'#514a36',2);}
if(root.DesktopView)root.DesktopView.lighting(g,a,a.lightMode);
};
function plane(p,z,a){let {ctx,project:P,poly,line,ellipse}=a,c=Math.cos(p.angle),s=Math.sin(p.angle),pr=(x,y,h=0)=>P(p.x+x*c-y*s,p.y+x*s+y*c,z+h),wing=(x1,x2,width,h)=>poly(ctx,[pr(x1,-width,h),pr(x2,-width,h),pr(x2,width,h),pr(x1,width,h)],h>45?'#e5d6a9':'#c8b889');
// 1903 Flyer: canard in front (+X), twin pusher propellers behind, stacked fabric wings.
let shadow=P(p.x,p.y);ellipse(ctx,shadow.x,shadow.y,85,22,'#233c3433');wing(-45,35,130,30);for(let y of [-115,-55,55,115]){let b=pr(-30,y,30),t=pr(-30,y,75);line(ctx,b.x,b.y,t.x,t.y,'#6f6447',2);b=pr(25,y,30);t=pr(25,y,75);line(ctx,b.x,b.y,t.x,t.y,'#6f6447',2);}wing(-45,35,130,75);wing(110,140,48,40);for(let y of [-20,20]){let b=pr(-80,y,20),t=pr(125,y,30);line(ctx,b.x,b.y,t.x,t.y,'#716242',3);}for(let y of [-57,57]){let b=pr(-65,y,22),t=pr(-65,y,65);line(ctx,b.x,b.y,t.x,t.y,'#685d45',4);}let b=pr(-90,-18,28),t=pr(-90,18,65);line(ctx,b.x,b.y,t.x,t.y,'#b7a77e',5);let nose=pr(120,0,50);ellipse(ctx,nose.x,nose.y,3,3,'#715a3d');}
function drawMap(g,a){let {ctx,vw,vh,poly,line,ellipse,label}=a;ctx.fillStyle='#182d2b';ctx.fillRect(0,0,vw,vh);let top=90,h=vh-160,w=vw*.73,x0=18;let map=p=>p.x>18000?{x:vw*.79+(p.x-19400)/5200*vw*.18,y:top+((p.y-700)/4600)*h}:{x:x0+p.x/12000*w,y:top+p.y/6000*h};
ctx.fillStyle='#879372';ctx.fillRect(x0,top,w,h);ellipse(ctx,vw*.88,top+h/2,vw*.09,h/2,'#9aa17b');let path=(pts,color,width)=>{ctx.strokeStyle=color;ctx.lineWidth=width;ctx.beginPath();pts.forEach((p,i)=>{let q=map(p);i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y);});ctx.stroke();};let river=[];for(let y=0;y<=6000;y+=100)river.push({x:D.riverCenter(y),y});path(river,'#517f88',8);path(D.road,'#e3cf9d',3);for(let p of D.spurs)path(p,'#bfaf85',2);path(D.rail,'#463d2d',2);path(D.airports,'#b8d5d2',1);
for(let s of g.services){let p=map(s);ctx.fillStyle=s.kind==='station'?'#eee1ac':s.kind==='airport'?'#dbece8':'#324d40';ctx.fillRect(p.x-2,p.y-2,5,5);}
for(let i=0;i<2;i++){let p=map(D.camps[i]);ellipse(ctx,p.x,p.y,5,5,g.campCleared[i]?'#586344':'#a54839');label(i?'铁狼帮':'红蛇帮',{x:p.x,y:p.y-9},'#572e26',10);p=map(D.plots[i]);label('宅地'+g.houseStage[i]+'/3',p,'#283d30',10);}
for(let t of [['日落镇',1500,2700],['冷杉镇',10500,4100],['石桥镇 · 银行 / 监狱',2900,5100],['风蚀镇 · 机场',10500,800],['白鹭岛',22000,2400]]){let p=map({x:t[1],y:t[2]});label(t[0],{x:p.x,y:p.y-12},'#22352b',11);}
for(let [p,color] of [[g.railPoint(),'#342f25'],[g.player,'#fff1b5'],...(g.wagonActive?[[g.wagonPosition,'#f6ca6b']]:[]),...(g.eventKind?[[g.eventPosition,'#ffff86']]:[])]){let q=map(p);ellipse(ctx,q.x,q.y,5,5,color);}
label('三城环线：日落 → 冷杉 → 石桥 → 日落 · 白鹭岛只能乘飞机往返',{x:vw/2,y:vh-45},'#ddcea5',12);label('地图暂停游戏 · 点击“地图”返回',{x:vw/2,y:vh-25},'#b5c0a4',11);
}
})(window);
