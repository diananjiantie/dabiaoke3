/* Exercise the real app's pointer handlers with a minimal DOM; no device claims. */
const vm=require('vm'),fs=require('fs'),path=require('path'),assert=require('assert/strict');
const drawing=new Proxy({},{get:()=>()=>{},set:()=>true}),elements=new Map(),windowEvents={};
function element(id){if(elements.has(id))return elements.get(id);let e={id,hidden:false,dataset:{},style:{},handlers:{},classList:{toggle(){},remove(){}},getContext:()=>drawing,addEventListener(k,fn){this.handlers[k]=fn},setPointerCapture(){},getBoundingClientRect(){return {left:id==='aim'?700:0,top:250,width:122,height:122}},querySelector(){return this.knob||(this.knob={style:{}})}};elements.set(id,e);return e;}
const cards=[1,2,3,4].map(n=>Object.assign(element('card'+n),{dataset:{level:String(n)}}));
const doc={getElementById:element,createElement:()=>element('image'+elements.size),querySelectorAll:()=>cards,body:element('body'),hidden:false,addEventListener(k,fn){windowEvents['document:'+k]=fn}};
const context={console,document:doc,innerWidth:844,innerHeight:390,devicePixelRatio:2,performance:{now:()=>0},requestAnimationFrame(){},location:{search:'?test=1'},addEventListener:(k,fn)=>windowEvents[k]=fn};context.window=context;
vm.createContext(context);for(let name of ['core.js','world-data.js','world.js','world-events.js','world-view.js','desktop-assets.js','desktop-view.js','mobile-audio.js','app.js'])vm.runInContext(fs.readFileSync(path.join(__dirname,'../assets',name),'utf8'),context);
const qa=context.__qa;qa.start(2);
function send(id,event,pointer,x,y){element(id).handlers[event]({pointerId:pointer,clientX:x,clientY:y,preventDefault(){}});}
send('move','pointerdown',11,95,311);send('aim','pointerdown',22,761,350);
assert(qa.input.mx>.5);assert(qa.input.ay>.5);assert(qa.input.fire);console.log('PASS independent simultaneous movement + aim pointers');
send('move','pointerup',22,95,311);assert(qa.input.mx>.5);console.log('PASS unrelated pointer cannot release movement');
send('aim','pointerup',22,761,350);assert(!qa.input.fire);assert(qa.input.mx>.5);console.log('PASS release aim stops firing and retains movement');
send('move','pointercancel',11,95,311);assert.equal(qa.input.mx,0);console.log('PASS pointer cancellation clears movement');
send('aim','pointerdown',23,761,350);context.pauseGame();assert(!qa.input.fire);assert(qa.game.paused);console.log('PASS Android pause hook clears held controls');
qa.start(3);assert(element('move').hidden);assert(element('reload').hidden);assert(!element('eye').hidden);console.log('PASS train-level touch controls');
send('aim','pointerdown',24,761,350);windowEvents.resize();assert(!qa.input.fire);console.log('PASS resizing releases controls');
console.log('All 7 touch-handler tests passed.');

const stored={};context.localStorage={getItem:k=>stored[k],setItem:(k,v)=>stored[k]=v};
element('sensitivity').value='1.7';element('sensitivity').oninput();
assert.equal(qa.input.sensitivity,1.7);assert.equal(stored['arthur.aimSensitivity'],'1.7');
qa.start(2);assert.equal(qa.input.sensitivity,1.7);
element('about').onclick();assert.equal(element('credits').hidden,false);
context.backGame();assert.equal(element('credits').hidden,true);
qa.game.finish(true);qa.hud();assert.equal(element('finishcredits').hidden,false);
qa.game.finish(false);qa.hud();assert.equal(element('finishcredits').hidden,true);
let nodes=0,resumes=0;
context.AudioContext=class{constructor(){this.state='suspended';this.currentTime=1;this.destination={};}resume(){this.state='running';resumes++;return Promise.resolve();}suspend(){this.state='suspended';return Promise.resolve();}createOscillator(){nodes++;return {frequency:{setValueAtTime(){},exponentialRampToValueAtTime(){}},connect(){},disconnect(){},start(){},stop(){}};}createGain(){return {gain:{setValueAtTime(){},exponentialRampToValueAtTime(){}},connect(){},disconnect(){}};}};
windowEvents['document:pointerdown']();qa.start(3);qa.game.onEvent('shot');assert(nodes>=2);assert(resumes>0);
context.pauseGame();windowEvents['document:pointerdown']();assert(resumes>=2);
element('sound').onclick();let before=nodes;qa.game.onEvent('eye');assert.equal(nodes,before);
element('sound').onclick();assert(nodes>before);
console.log('PASS sensitivity persistence, credits, audio unlock/resume and mute');

qa.start(4);qa.game.storage=context.localStorage;qa.game.enemies=[];
element('eye').onclick();assert(qa.game.eye);
send('aim','pointerdown',30,780,340);assert(!qa.input.fire);assert(qa.input.ax>0);
console.log('PASS deadeye aim joystick does not automatically fire');
send('aim','pointerup',30,780,340);
let target=qa.game.actor({x:qa.game.player.x+200,y:qa.game.player.y});qa.game.enemies=[target];qa.game.aim=target;
element('mark').onclick();assert.equal(qa.game.marks.length,1);
element('fire').onpointerdown({pointerId:35,preventDefault(){}});assert.equal(target.hp,0);
send('fire','pointerup',35,0,0);assert(!qa.input.fire);
console.log('PASS separate mark and fire buttons execute marked shots');
element('mapbutton').onclick();assert(qa.game.worldMap&&qa.game.paused);context.backGame();assert(!qa.game.worldMap&&!qa.game.paused);
element('more').onclick();assert(!element('extras').hidden);context.backGame();assert(element('extras').hidden);
console.log('PASS map freezes simulation; Android back closes map or service panel');
qa.game.capture();qa.hud();assert(!element('dig').hidden);assert.equal(typeof element('dig').onpointerdown,'undefined');
element('dig').onclick();assert.equal(qa.game.digProgress,1);
for(let i=1;i<30;i++)element('dig').onclick();assert(!qa.game.captured);assert(qa.game.escapeHole);
console.log('PASS capture reveals discrete 30-tap escape control');
qa.render();qa.game.action('map');qa.render();qa.game.action('map');
qa.game.money=777;context.pauseGame();qa.game.money=0;assert(qa.game.load(false));assert.equal(qa.game.money,777);
console.log('PASS world and map rendering and Android background save hook');

