const http=require('http'),fs=require('fs'),path=require('path');const root=path.resolve(__dirname,'../assets');
http.createServer((req,res)=>{let file=new URL(req.url,'http://localhost').pathname;if(file==='/')file='/index.html';if(!/^\/[\w.-]+$/.test(file)){res.writeHead(404).end();return;}let p=path.join(root,file);fs.readFile(p,(e,b)=>{if(e){res.writeHead(404).end();return;}res.setHeader('Content-Type',file.endsWith('.png')?'image/png':file.endsWith('.wav')?'audio/wav':file.endsWith('.js')?'application/javascript':file.endsWith('.css')?'text/css':'text/html');res.end(b);});}).listen(4196,'127.0.0.1',()=>console.log('Android assets preview at http://127.0.0.1:4196'));


