const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const assert=require('assert/strict'),fs=require('fs'),path=require('path');
(async()=>{const browser=await chromium.launch({channel:'msedge',headless:true,args:['--enable-webgl','--ignore-gpu-blocklist']});try{
 const page=await browser.newPage({viewport:{width:1280,height:800},deviceScaleFactor:1});let errors=[];page.on('pageerror',e=>errors.push(String(e)));
 await page.goto('http://127.0.0.1:4196/?test=1');await page.locator('[data-level="4"]').click();
 await page.addStyleTag({content:'#modal{display:none!important}'});
 const out=path.resolve(__dirname,'../../../qa-android-3d-17');fs.mkdirSync(out,{recursive:true});
 await page.evaluate(()=>{let q=__qa,g=q.game,r=q.gpu;g.enemies=[];g.eventClock=999;g.player.inv=999;g.mounted=false;g.player.x=1800;g.player.y=2100;g.player.angle=-Math.PI/2;g.time=0;g.noticeTime=0;r.reset(g);r.yaw=0;r.pitch=.15;r.range=360;g.paused=true;r.lightShafts=0;q.render();});
 // No wall-clock animations or gameplay updates: paired screenshots differ only in shafts.
 await page.screenshot({path:path.join(out,'shafts-off.png')});
 const metrics=await page.evaluate(()=>{let q=__qa,r=q.gpu,g=q.game;let before=r.terrainBuilds;for(let i=0;i<60;i++)q.render();if(r.terrainBuilds!==before)throw Error('Terrain rebuilt without moving');let start=performance.now();for(let i=0;i<120;i++)q.render();let ms=(performance.now()-start)/120;r.lightShafts=2;q.render();if(r.shaftCount===0)throw Error('No forest shafts');if(!r.gl.getParameter(r.gl.DEPTH_WRITEMASK))throw Error('Depth writes leaked off');if(r.error!==0)throw Error('GL error');g.player.x+=200;r.reset(g);q.render();if(r.terrainBuilds!==before+1)throw Error('Cache missed cell change');g.player.x-=200;r.reset(g);r.yaw=0;r.pitch=.15;r.range=360;q.render();return{cpuDrawMs:ms,terrainBuilds:r.terrainBuilds,shafts:r.shaftCount,triangles:r.triangles};});
 await page.screenshot({path:path.join(out,'shafts-on.png')});console.log(metrics);
 await page.evaluate(()=>{__qa.game.time=130;__qa.render();});await page.screenshot({path:path.join(out,'rain.png')});
 await page.evaluate(()=>{let q=__qa,g=q.game;g.time=350;g.player.x=1800;g.player.y=2900;g.player.angle=-1.3;q.gpu.reset(g);q.render();});await page.screenshot({path:path.join(out,'night.png')});
 await page.evaluate(()=>{let q=__qa,g=q.game;g.paused=false;let scale=q.getRenderScale();q.input.mx=.8;q.input.fire=true;for(let i=0;i<180;i++)q.adaptFrame(35);if(q.getRenderScale()>=scale)throw Error('Slow frames did not reduce render scale');if(q.input.mx!==.8||!q.input.fire)throw Error('Adaptive resize dropped held controls');q.clearInput();if(q.input.fire||q.input.mx||q.input.ax)throw Error('Clear retained input');for(let i=0;i<480;i++)q.adaptFrame(16);if(q.getRenderScale()<=.7)throw Error('Recovery missing');g.paused=true;});
 // Exercise restoration and cached GPU buffer reupload after context loss.
 await page.evaluate(()=>{let ext=__qa.gpu.gl.getExtension('WEBGL_lose_context');if(ext){window.qaRestore=ext;ext.loseContext();}});
 await page.waitForFunction(()=>__qa.gpu.lost===true);
 await page.evaluate(()=>window.qaRestore.restoreContext());await page.waitForFunction(()=>!__qa.gpu.lost);
 await page.evaluate(()=>{__qa.render();if(__qa.gpu.error!==0||__qa.gpu.terrainMesh.n===0)throw Error('Restore failed');});
 assert.deepEqual(errors,[]);console.log('PASS terrain reuse/invalidation, shafts, depth state, adaptive scaling without lost controls, release reset, WebGL context restore.');
 fs.writeFileSync(path.join(out,'metrics.json'),JSON.stringify(metrics,null,2));
 }finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
