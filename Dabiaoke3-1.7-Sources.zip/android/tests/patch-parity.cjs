const fs=require('fs'),path=require('path'),f=path.join(__dirname,'../assets/world.js');let s=fs.readFileSync(f,'utf8');
for(let[a,b]of [
 ["if(e.police&&credited)this.raiseWanted();if(e.hp)return;","if(e.police&&credited&&this.wanted===0)this.raiseWanted();if(e.hp)return;if(e.police&&credited)this.raiseWanted();"],
 ["speed*=this.mounted?.65:.42","speed*=this.mounted?.55:.35"],
 ["speed*=this.mounted?.50:.65","speed*=this.mounted?.3:.65"],
 ["this.eye?.4:.65","this.eye?.4:.7"],
 ["let angle=a+(i-3)*.06","let angle=a+(i-3)*.055"],
 ["},damage,1100);this.bullets[this.bullets.length-1].life=.255;","},damage,900);this.bullets[this.bullets.length-1].life=.36;"],
 ["else this.shootFrom(this.player,target,damage,this.weapon==='rifle'?1450:1020);this.onEvent('shot');","else {this.shootFrom(this.player,target,damage,this.weapon==='rifle'?1450:1020);this.bullets[this.bullets.length-1].life=this.weapon==='rifle'?1.1:.9;}this.onEvent('shot');"],
 ["this.camera.y+=(p.y-this.camera.y)*Math.min(1,dt*9);","this.camera.y+=(p.y-(this.flying?230:0)-this.camera.y)*Math.min(1,dt*9);"]
]){if(!s.includes(a))throw Error('Missing '+a);s=s.replace(a,()=>b);}fs.writeFileSync(f,s);
