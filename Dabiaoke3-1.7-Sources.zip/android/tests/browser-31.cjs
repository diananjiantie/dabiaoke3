const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const fs=require('fs'),path=require('path'),assert=require('assert/strict');
(async()=>{const browser=await chromium.launch({channel:'msedge',headless:true});try{
 const context=await browser.newContext({viewport:{width:960,height:540},deviceScaleFactor:2,isMobile:true,hasTouch:true});const page=await context.newPage(),errors=[];page.on('pageerror',e=>{errors.push(String(e));console.log('PAGE ERROR',String(e));});await page.goto('http://127.0.0.1:4191/?test=1');await page.locator('[data-level="4"]').tap();await page.evaluate(()=>{let g=__qa.game;g.enemies=[];g.eventClock=999;g.player.inv=999;g.player.x=1980;g.player.y=2600;g.camera={x:1980,y:2600};g.mounted=false;g.noticeTime=0;});
 await page.waitForTimeout(2000);await page.waitForFunction(()=>window.__qa&&Object.keys(__qa.soundEngine.buffers).length===9);await page.waitForFunction(()=>DesktopAssets.buildings.filter(b=>b.home&&b.x<2400).some(b=>DesktopView.bitmap(b.image)));
 assert.equal(await page.locator('canvas').evaluate(c=>c.width),1920);console.log('PASS 1920 rendering, actual desktop PNGs and nine decoded WAVs');
 let cdp=await context.newCDPSession(page),r=await page.locator('#move').boundingBox(),b=await page.locator('#reload').boundingBox();let move={x:r.x+r.width*.78,y:r.y+r.height*.5,id:1};
 await page.evaluate(()=>{__qa.game.ammunition[__qa.game.weapon]=2;window.testEvents=[];let handle=__qa.game.onEvent;__qa.game.onEvent=e=>{testEvents.push(e);handle(e);};});
 await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[move]});
 await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[move,{x:b.x+b.width/2,y:b.y+b.height/2,id:2}]});
 let state=await page.evaluate(()=>({move:__qa.input.mx,count:testEvents.filter(e=>e==='reload').length}));assert(state.move>.4&&state.count===1);console.log('PASS real secondary-finger reload while movement remains held');
 await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[move]});
 b=await page.locator('#eye').boundingBox();await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[move,{x:b.x+b.width/2,y:b.y+b.height/2,id:3}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[move]});
 assert(await page.evaluate(()=>__qa.game.eye&&__qa.input.mx>.4));console.log('PASS secondary-finger eye toggles exactly once and retains movement');
 b=await page.locator('#interact').boundingBox();await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[move,{x:b.x+b.width/2,y:b.y+b.height/2,id:4}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[move]});assert(await page.evaluate(()=>__qa.input.mx>.4));await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});assert.equal(await page.evaluate(()=>__qa.input.mx),0);console.log('PASS interaction preserves joystick and releasing it stops movement');
 await page.evaluate(async()=>{window.pauseGame();await __qa.soundEngine.suspend();});assert.equal(await page.evaluate(()=>__qa.soundEngine.voices.size),0);await page.locator('#continue').tap();await page.waitForFunction(()=>__qa.soundEngine.context.state==='running');console.log('PASS audio stops on background and resumes on user action');
 const out=path.resolve(__dirname,'../../../qa-mobile-31');fs.mkdirSync(out,{recursive:true});
 await page.evaluate(()=>{let g=__qa.game;g.eye=false;g.player.x=1980;g.player.y=2600;g.camera={x:1980,y:2600};g.time=0;g.noticeTime=0;});await page.waitForTimeout(300);await page.screenshot({path:path.join(out,'day.png')});
 await page.evaluate(()=>{__qa.game.time=350;});await page.waitForTimeout(300);await page.screenshot({path:path.join(out,'night.png')});
 await page.evaluate(()=>{__qa.game.save(false);__qa.game.time=0;__qa.game.load(false);});assert((await page.evaluate(()=>__qa.game.time))>=350);console.log('PASS saved night time restored');
 await page.locator('#home').tap();await page.locator('#quality').selectOption('balanced');assert.equal(await page.locator('canvas').evaluate(c=>c.width),1280);await page.locator('#quality').selectOption('low');assert.equal(await page.locator('canvas').evaluate(c=>c.width),960);await page.locator('#lightmode').selectOption('night');await page.reload();assert.equal(await page.locator('#lightmode').inputValue(),'night');assert.equal(await page.locator('#quality').inputValue(),'low');console.log('PASS quality and day/night preferences persist');
 assert.deepEqual(errors,[]);console.log('ALL MOBILE 3.1 BROWSER TESTS PASSED');
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});





