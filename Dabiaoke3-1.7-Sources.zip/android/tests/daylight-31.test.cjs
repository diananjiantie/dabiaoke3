const assert=require('assert/strict'),fs=require('fs'),vm=require('vm'),path=require('path');
const {Game,WorldData:D}=require('../assets/world-events.js');
const ctx={};vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(__dirname,'../assets/desktop-assets.js'),'utf8').replace('window.DesktopAssets','globalThis.DesktopAssets'),ctx);vm.runInContext(fs.readFileSync(path.join(__dirname,'../assets/desktop-view.js'),'utf8'),ctx);
const homes=D.buildings.filter(b=>b.kind==='home');assert.equal(homes.length,28);for(let b of homes){let d=ctx.DesktopAssets.buildings.find(d=>d.x===b.x&&d.y===b.y);assert(d&&d.home);assert(fs.existsSync(path.join(__dirname,'../assets',d.image+'.png')));}
let night=ctx.DesktopView.night;assert.equal(night(0).strength,0);assert.equal(night(275).strength,.5);assert.equal(night(350).strength,1);assert.equal(night(550).strength,.5);assert.equal(night(600).strength,0);
let g=new Game(),store={};g.storage={getItem:k=>store[k],setItem:(k,v)=>store[k]=v};g.resetWorld();g.time=350;g.pause();g.update(.05,{});assert.equal(g.time,350);assert(g.save(false));g.time=0;assert(g.load(false));assert.equal(g.time,350);
console.log('PASS desktop house positions/assets match; smooth day/night transitions; pause and save preserve clock');
let fills=0,ellipses=0;const a={ctx:{fillRect(){fills++;}},project:(x,y)=>({x:x-2000,y:y-2400}),vw:960,vh:540,ellipse(){ellipses++;}};g.houseStage=[0,0];ctx.WorldData=D;
ctx.DesktopView.lighting(g,a,'day');assert.equal(fills,0);ctx.DesktopView.lighting(g,a,'night');assert(fills>1&&ellipses>0&&ellipses<28*4);console.log('PASS forced daylight and night lamps with offscreen culling');
g.player.x=2120;g.player.y=2950;g.horse.x=2120;g.horse.y=2950;assert(g.save(false)&&g.load(false));assert(!g.blocked(g.player.x,g.player.y)&&!g.blocked(g.horse.x,g.horse.y));console.log('PASS old saves inside newly added houses relocate safely');
