using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
namespace ArthurFrontier {
    /// <summary>Exercises the real UI-thread scheduler and renderer on a hidden native window.</summary>
    static class FrameProbe {
        public static void Run(string directory,int width=1280,int height=800) {
            Directory.CreateDirectory(directory);
            StringBuilder report=new StringBuilder();
            try {
                using(FrontierWindow window=new FrontierWindow())using(Timer sampler=new Timer()) {
                    window.ClientSize=new Size(width,height);
                    window.Game.Muted=true;
                    window.Game.StartThirdLevel();
                    window.Game.Chapter="train";
                    window.Game.Wave=5;
                    window.Game.SpawnQueue=0;
                    window.Game.Player.X=945;
                    window.Game.Player.Y=750;
                    window.Game.CameraX=945;
                    window.Game.CameraY=850;
                    window.Game.Invulnerable=100000;
                    window.Game.Enemies.Clear();
                    for(int i=0;i<20;i++)window.Game.Enemies.Add(new Body {
                        X=600+i%5*140,Y=1000+i/5*85,HP=i==19?1600:160,MaxHP=i==19?1600:160,Elite=false,Speed=50,Shoot=1+i*.1f
                    });
                    window.Game.MouseHeld=true;
                    window.Game.Mouse=window.Game.Project(945,1100,22);
                    window.BeginProbe();
                    Stopwatch watch=Stopwatch.StartNew();
                    double sampleTime=0;
                    int previousFrames=0;
                    List<double> samples=new List<double>();
                    report.AppendLine("Hidden native-window frame-loop test, "+window.ClientSize.Width+"x"+window.ClientSize.Height+", 20 mounted pursuers, train turret firing.");
                    report.AppendLine("Renderer: "+window.GraphicsDevice);
                    sampler.Interval=1000;
                    sampler.Tick+=delegate {
                        double now=watch.Elapsed.TotalSeconds;
                        double fps=(window.PresentedFrames-previousFrames)/(now-sampleTime);
                        previousFrames=window.PresentedFrames;
                        sampleTime=now;
                        if(now>2.5) {
                            samples.Add(fps);
                            report.AppendLine("FPS="+fps.ToString("0.0")+" paintMs="+((double)window.LastPaintMs).ToString("0.00"));
                        }
                        window.Game.DeadEye=!window.Game.DeadEye;
                        window.Game.KeysDown.Clear();
                        window.Game.KeysDown.Add((int)now%2==0?Keys.D:Keys.A);
                        if(now>=12) {
                            sampler.Stop();
                            Application.ExitThread();
                        }
                    };
                    sampler.Start();
                    Application.Run(new ApplicationContext());
                    double sum=0,min=double.MaxValue;
                    foreach(double fps in samples) {
                        sum+=fps;
                        min=Math.Min(min,fps);
                    }
                    double avg=sum/Math.Max(1,samples.Count);
                    report.AppendLine("AverageFPS="+avg.ToString("0.0"));
                    report.AppendLine("MinimumOneSecondFPS="+min.ToString("0.0"));
                    report.AppendLine("Target40="+(min>=40?"PASS":"FAIL"));
                    if(min<40)Environment.ExitCode=2;
                    report.AppendLine("This measures a hidden native window, not a guarantee for visible fullscreen presentation or other hardware workloads.");
                }
            }
            catch(Exception e) {
                report.AppendLine("FAIL: "+e);
                Environment.ExitCode=1;
            }
            File.WriteAllText(Path.Combine(directory,"frame-loop.txt"),report.ToString(),Encoding.UTF8);
        }
    }
}
