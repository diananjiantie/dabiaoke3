using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Xml;
namespace ArthurFrontier {
    static class RegionalTest {
        static string log="";
        static void Check(bool value,string message) { if(!value)throw new Exception(message);log+="PASS "+message+"\r\n"; }
        static void Tick(FrontierGame game,float duration) { for(float t=0;t<duration;t+=.02f)game.Update(.02f); }
        static void At(FrontierGame g,float x,float y) { g.Player.X=x;g.Player.Y=y;g.CameraX=x;g.CameraY=y;g.Invulnerable=1000;g.EventClock=180;g.Mounted=false; }
        static void Frame(FrontierGame game,string path) { game.NoticeTime=0;using(Bitmap image=new Bitmap(1280,800))using(Graphics graphics=Graphics.FromImage(image))using(GameRenderer renderer=new GameRenderer()) { renderer.Draw(game,graphics,1280,800);image.Save(path); } }
        public static void Run(string dir) {
            Directory.CreateDirectory(dir);
            try { using(FrontierGame g=new FrontierGame()) {
                g.SavePath=Path.Combine(dir,"regional-"+Guid.NewGuid().ToString("N")+".xml");g.Muted=true;g.StartFrontier();g.Enemies.RemoveAll(e=>!e.Police);At(g,1500,1800);Tick(g,.04f);
                Check(g.Enemies.Count(e=>e.LawDistrict==0&&e.HP>0)==4,"Exactly four local officers, no infinite reinforcements");
                Body[] officers=g.Enemies.Where(e=>e.LawDistrict==0&&e.HP>0).ToArray();g.Wanted=5;
                for(int i=0;i<4;i++) {
                    Body e=officers[i];e.X=1700+i*60;e.Y=1800;g.Weapon=WeaponType.Rifle;g.DeadEye=true;g.ReloadTime=0;g.Ammo=8;
                    for(int hit=0;hit<2;hit++) { g.Cooldown=0;g.Mouse=g.Project(e.X,e.Y,35);g.Fire(); }
                    if(i<3)Check(g.Wanted>0&&g.PoliceRespawn[0]==0,"Partial defeat does not clear wanted, officer "+i);
                }
                Check(g.Wanted==0&&g.PoliceDeaths[0]==4&&g.PoliceRespawn[0]==180,"Final officer clears all five wanted stars and starts cooldown");
                g.HurtResident(new Body { HP=100 },100);Check(g.Wanted==0,"Crimes during police absence do not add wanted");Tick(g,20);
                Check(!g.Enemies.Any(e=>e.LawDistrict==0&&e.HP>0),"No police replacement during cooldown");
                g.SaveFrontier();Check(g.LoadFrontier()&&g.Wanted==0&&g.PoliceRespawn[0]>159&&g.PoliceDeaths[0]==4,"Defeated police and countdown survive reload");Frame(g,Path.Combine(dir,"01-police-defeated.png"));
                At(g,10500,4200);Tick(g,.04f);Check(g.Enemies.Count(e=>e.LawDistrict==1&&e.HP>0)==4&&g.PoliceRespawn[0]>0,"Other district retains its own police squad");g.HurtResident(new Body { HP=100 },100);Check(g.Wanted==1,"Other district records new crime");
                At(g,1500,1800);Tick(g,.04f);Check(g.Wanted==0,"Returning to defeated district clears pursuit");Tick(g,161);
                Check(g.PoliceRespawn[0]==0&&g.Enemies.Count(e=>e.LawDistrict==0&&e.HP>0)==4&&g.Wanted==0,"Police rebuild at three minutes with no old wanted restored");g.HurtResident(new Body { HP=100 },100);Check(g.Wanted==1,"Crime after rebuild starts at one star");
                g.Wanted=0;g.DeadEye=false;g.Bullets.Clear();g.Enemies.RemoveAll(e=>!e.Police);g.Aboard=false;
                for(int station=0;station<3;station++)for(int farther=0;farther<2;farther++) {
                    g.RailClock=g.StationClock(station);WorldService stop=g.Services.First(s=>s.Kind=="station"&&s.Index==station);At(g,stop.X,stop.Y);g.Money=200;
                    if(farther==0)g.InteractFrontier();else g.AlternateService();Check(g.Aboard&&g.Money==180,"Board route "+station+" option "+farther);
                    int destination=(station+farther+1)%3;float duration=FrontierGame.StationWait+g.LegSeconds(station)+.04f;
                    if(farther==1)duration+=FrontierGame.StationWait+g.LegSeconds((station+1)%3);
                    Tick(g,duration);
                    Check(!g.Aboard&&Math.Abs(g.Player.X-g.RailPlatforms[destination].X)<1&&Math.Abs(g.Player.Y-g.RailPlatforms[destination].Y)<1,"Arrive at selected town "+destination);
                }
                g.RailClock=0;At(g,1500,3460);g.Money=100;g.AlternateService();Tick(g,9);Check(g.Aboard&&g.SaveFrontier()&&g.LoadFrontier()&&g.Aboard,"Longer ticket survives moving-train save");Tick(g,g.LegSeconds(0)+FrontierGame.StationWait+g.LegSeconds(1));Check(!g.Aboard&&g.Player.X==2800&&g.Player.Y==5810,"Reloaded journey reaches Stonebridge");
                At(g,2800,5650);g.RailClock=g.StationClock(2);Frame(g,Path.Combine(dir,"02-stonebridge-station.png"));g.WorldMap=true;Frame(g,Path.Combine(dir,"03-three-town-railway.png"));g.WorldMap=false;
                // V4 return ticket was Cedar -> Sunset. Migration must keep that destination across Stonebridge.
                g.RailClock=0;At(g,1500,3460);g.SaveFrontier();XmlDocument old=new XmlDocument();old.Load(g.SavePath);old.DocumentElement.SetAttribute("version","4");old.DocumentElement.SetAttribute("rail",(16+g.TripSeconds+1).ToString(System.Globalization.CultureInfo.InvariantCulture));old.DocumentElement.SetAttribute("departure","1");old.DocumentElement.SetAttribute("aboard","True");old.Save(g.SavePath);
                Check(g.LoadFrontier()&&g.Aboard,"Load previous two-town train save");Tick(g,g.RailCycle);Check(!g.Aboard&&g.Player.X==1500&&g.Player.Y==3460,"Old return ticket still arrives at Sunset");
                log+="ALL REGIONAL TESTS PASSED\r\n";
            }File.WriteAllText(Path.Combine(dir,"regional-test.txt"),log); }
            catch(Exception e) { File.WriteAllText(Path.Combine(dir,"regional-test.txt"),log+e);Environment.ExitCode=1; }
        }
    }
}
