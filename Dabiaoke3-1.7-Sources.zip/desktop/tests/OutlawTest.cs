using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Xml;
namespace ArthurFrontier {
    static class OutlawTest {
        static string log="";
        static void Check(bool ok,string label) { if(!ok)throw new Exception(label);log+="PASS "+label+"\r\n"; }
        static void Tick(FrontierGame g,float time) { for(float t=0;t<time;t+=.02f)g.Update(.02f); }
        static void At(FrontierGame g,float x,float y) { g.Player.X=x;g.Player.Y=y;g.CameraX=x;g.CameraY=y;g.Mounted=false;g.Invulnerable=100;g.EventClock=180; }
        static void Shoot(FrontierGame g,Body target) { g.DeadEye=true;g.Weapon=WeaponType.Rifle;g.Ammo=8;g.Cooldown=g.ReloadTime=0;g.Mouse=g.Project(target.X,target.Y,35);g.Fire(); }
        static void Frame(FrontierGame game,string path) { game.NoticeTime=0;using(Bitmap image=new Bitmap(1280,800))using(Graphics graphics=Graphics.FromImage(image))using(GameRenderer renderer=new GameRenderer()) { renderer.Draw(game,graphics,1280,800);image.Save(path); } }
        public static void Run(string dir) {
            Directory.CreateDirectory(dir);
            try { using(FrontierGame g=new FrontierGame()) {
                g.Muted=true;g.SavePath=Path.Combine(dir,"outlaw-"+Guid.NewGuid().ToString("N")+".xml");g.StartFrontier();
                Check(g.Residents.Count==64&&g.Residents.Count(n=>n.Rider)==8,"Stonebridge residents and eight mounted travellers");
                Check(g.EventClock>=120,"Reduced event frequency starts at two minutes");
                Check(Math.Abs(g.RiverCenter(1000)-g.RiverCenter(2500))>150,"River has meanders");
                At(g,g.RiverCenter(2800)-g.RiverWidth(2800)-60,2800);g.Mounted=true;float end=g.RiverCenter(2800)+g.RiverWidth(2800)+60;for(int i=0;i<200;i++)g.Move(g.Player,8,0);Check(g.Player.X>end,"Horse crosses actual curved river");
                At(g,2600,5030);for(int i=0;i<20;i++)g.Move(g.Player,0,-10);Check(g.Player.Y<4900,"Bank front doorway is traversable");
                Check(g.Blocked(2255,4600,16)&&!g.Blocked(2600,4800,16),"Bank walls collide, lobby is open");
                At(g,g.Vault.X,g.Vault.Y);g.InteractFrontier();Check(g.BankOpening==0&&!g.BankGuardDown,"Cannot rob bank before defeating guard");
                Body guard=g.Enemies.First(e=>e.Guard==1);At(g,2600,4820);Shoot(g,guard);Shoot(g,guard);Check(guard.HP==0&&g.BankGuardDown,"Defeat bank guard using actual aimed shots");
                At(g,g.Vault.X,g.Vault.Y);g.InteractFrontier();Check(g.BankOpening==6,"Vault opens only after guard defeated");int cash=g.Money;Tick(g,6.1f);Check(g.BankLooted&&g.Money==cash+250,"Bank robbery pays after six seconds");g.InteractFrontier();Check(g.BankOpening==0,"Empty bank cannot pay twice");
                Frame(g,Path.Combine(dir,"01-bank-interior.png"));
                At(g,3510,4820);g.InteractFrontier();Check(!g.PrisonerFree,"Jail requires guards defeated");
                foreach(Body officer in g.Enemies.Where(e=>e.Guard==2||e.Guard==3).ToArray()) { At(g,officer.X,officer.Y+100);Shoot(g,officer);Shoot(g,officer); }
                Check(g.PrisonGuardOneDown&&g.PrisonGuardTwoDown,"Both prison officers defeated");At(g,3510,4800);g.InteractFrontier();Check(g.PrisonerFree&&!g.SecurityBlocked(3510,4725,10),"Unlock cell after obtaining guard keys");
                Frame(g,Path.Combine(dir,"02-prison-interior.png"));At(g,3550,5100);Tick(g,3.3f);At(g,g.PrisonExit.X,g.PrisonExit.Y);cash=g.Money;Tick(g,5);Check(g.PrisonPaid&&g.Money==cash+180,"Escort prisoner through doorway to collect reward");
                At(g,4100,4860);Frame(g,Path.Combine(dir,"03-gallows.png"));
                g.WagonClock=119.95f;g.WagonActive=false;Tick(g,.1f);Check(g.WagonActive&&g.WagonClock<1,"Bank dispatches carriage at 120 seconds");
                At(g,g.WagonPosition.X,g.WagonPosition.Y+100);g.RobWagon();Check(g.WagonOpening==0,"Wagon loot protected by escort");Body escort=g.Enemies.First(e=>e.Guard==4);Shoot(g,escort);Shoot(g,escort);Check(escort.HP==0,"Wagon escort can be defeated");g.RobWagon();cash=g.Money;Tick(g,4.1f);Check(g.WagonLooted&&g.Money==cash+120,"Rob carriage after escort defeated");g.RobWagon();Check(g.WagonOpening==0,"Wagon cannot pay twice");Frame(g,Path.Combine(dir,"04-carriage.png"));
                g.BankLooted=false;g.EventKind=0;At(g,2700,5250);Check(g.SpawnHeistEvent(4)&&g.Enemies.Count(e=>e.Raid==1)==5,"Five stronger raiders attack bank");Check(g.Enemies.Where(e=>e.Raid==1).All(e=>e.MaxHP==180),"Raiders have increased health");
                foreach(Body raider in g.Enemies.Where(e=>e.Raid==1))raider.HP=0;cash=g.Money;Tick(g,.04f);Check(g.EventKind==0&&g.Money==cash+80&&g.EventClock>=120,"Bank defence reward and longer cooldown");
                g.DispatchWagon();At(g,g.WagonPosition.X,g.WagonPosition.Y+200);Check(g.SpawnHeistEvent(5),"Gang can attack bank carriage");g.EventKind=0;g.Enemies.RemoveAll(e=>e.Raid>0);
                At(g,2000,1800);g.Enemies.RemoveAll(e=>e.Guard==0);Body moving=new Body { X=2400,Y=1800,HP=100,MaxHP=100,Speed=300,Camp=-2 };g.Enemies.Add(moving);g.Weapon=WeaponType.Rifle;g.Ammo=8;g.DeadEye=true;g.Cooldown=0;g.Mouse=g.Project(moving.X,moving.Y,35);g.MarkDeadEye();Check(g.EyeMarks.Contains(moving),"Manual mark selects visible torso");moving.Y+=100;g.Fire();Check(moving.HP==0&&g.Ammo==7,"Marked shot hits moved target immediately");
                Body next=new Body { X=2400,Y=1750,HP=100,Camp=-2 };g.Enemies.Add(next);g.Mouse=g.Project(next.X,next.Y,35);g.MarkDeadEye();Check(g.EyeMarks.Contains(next),"Can mark again after finishing previous volley");g.EyeMarks.Clear();
                Body hidden=new Body { X=2290,Y=4800,HP=100,Camp=-2 };g.Enemies.Add(hidden);At(g,2190,4800);g.Mouse=g.Project(hidden.X,hidden.Y,35);g.MarkDeadEye();Check(!g.EyeMarks.Contains(hidden),"Dead eye cannot mark through bank wall");
                g.SaveFrontier();Check(g.LoadFrontier()&&g.PrisonPaid&&g.WagonActive&&g.BankGuardDown,"New robbery and prison state persists");
                g.WorldMap=true;Frame(g,Path.Combine(dir,"05-map-river.png"));
                g.WorldMap=false;g.SaveFrontier();XmlDocument old=new XmlDocument();old.Load(g.SavePath);old.DocumentElement.SetAttribute("version","3");foreach(XmlElement n in old.SelectNodes("frontier/resident").Cast<XmlElement>().ToArray())if(int.Parse(n.GetAttribute("id"))>=48)n.ParentNode.RemoveChild(n);foreach(XmlElement n in old.SelectNodes("frontier/enemy").Cast<XmlElement>().ToArray())if(n.GetAttribute("guard")!="0")n.ParentNode.RemoveChild(n);old.Save(g.SavePath);
                Check(g.LoadFrontier()&&g.Residents.Count==64&&g.Enemies.Count(e=>e.Guard>0)==3,"Version three save gains town and guards without losing progress");
                g.Enemies.RemoveAll(e=>e.Guard!=1);g.Wanted=0;g.DeadEye=false;g.EventKind=0;g.BankLooted=false;At(g,2700,5250);g.SpawnHeistEvent(4);Tick(g,65);
                Check(g.BankGuardDown&&g.BankLooted,"Unopposed bank raid defeats guard and reaches vault to steal money");
                g.Enemies.Clear();g.EventKind=0;g.Wanted=0;g.WagonClock=0;g.DispatchWagon();At(g,g.WagonPosition.X,g.WagonPosition.Y+200);g.SpawnHeistEvent(5);Tick(g,60);
                Check(g.WagonLooted,"Gang can defeat escort and steal actual carriage money");
                Check(g.SaveFrontier()&&g.LoadFrontier()&&g.WagonLooted,"Completed gang robbery remains readable in save");
                log+="ALL OUTLAW TESTS PASSED\r\n";
            }File.WriteAllText(Path.Combine(dir,"outlaw-test.txt"),log); }
            catch(Exception e) { File.WriteAllText(Path.Combine(dir,"outlaw-test.txt"),log+e);Environment.ExitCode=1; }
        }
    }
}
