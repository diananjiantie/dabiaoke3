using System;
using System.Drawing;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Xml;
namespace ArthurFrontier {
    static class OpenWorldTest {
        static string log="";
        static void Check(bool ok,string name) { if(!ok)throw new Exception(name);log+=name+"\r\n"; }
        static void Frame(FrontierGame game,string path) { using(Bitmap image=new Bitmap(1280,800))using(Graphics g=Graphics.FromImage(image))using(GameRenderer renderer=new GameRenderer()) { renderer.Draw(game,g,1280,800);image.Save(path); } }
        static void At(FrontierGame g,WorldService s) { g.Player.X=s.X;g.Player.Y=s.Y;g.CameraX=s.X;g.CameraY=s.Y; }
        static void Tick(FrontierGame g,float seconds) { for(float t=0;t<seconds;t+=.02f)g.Update(.02f); }
        public static void Run(string directory) {
            Directory.CreateDirectory(directory);
            try {
                using(FrontierGame g=new FrontierGame()) {
                    g.Muted=true;g.SavePath=Path.Combine(directory,"save-"+Guid.NewGuid().ToString("N")+".xml");g.StartFrontier();
                    Check(g.Level==4&&g.Enemies.Count==21&&g.Residents.Count==64,"Two gangs, security officers and expanded residents");
                    Check(g.Enemies.All(e=>!g.Blocked(e.X,e.Y,e.R)),"Gang spawns clear of mountains and buildings");
                    Check(g.Services.First(s=>s.Kind=="station"&&s.Index==1).Y==4860,"Eastern station moved southeast");
                    Check(FrontierGame.PathLength(g.MountainRoad)>13000,"Winding road longer than direct ride");
                    foreach(PointF[] road in new[]{g.MountainRoad,g.WestSpur,g.EastSpur})for(float d=0;d<FrontierGame.PathLength(road);d+=25) { PointF p=FrontierGame.Along(road,d);if(g.Blocked(p.X,p.Y,21))throw new Exception("Road blocked at "+p); }
                    Check(g.Blocked(g.RiverCenter(2800),2800,21)&&!g.Blocked(6000,4300,21)&&g.MountainBlocked(3200,2800,21),"Curved river collision and southern bridge passable");
                    Check(FrontierGame.TrainSpeed>740&&g.TripSeconds<15,"Train faster than sprinting horse");
                    Frame(g,Path.Combine(directory,"01-town.png"));
                    WorldService saloon=g.Services.First(s=>s.Kind=="saloon"),gun=g.Services.First(s=>s.Kind=="gun");
                    At(g,saloon);g.Player.HP=20;int cash=g.Money;g.InteractFrontier();Check(g.MealTime==2&&g.Player.HP==20&&g.Money==cash-20,"Meal charged before eating");
                    Tick(g,1);Check(g.Player.HP==20,"No healing before meal complete");Tick(g,1.1f);Check(g.Player.HP==80,"Completed meal restores sixty HP");
                    At(g,gun);g.Money=0;g.InteractFrontier();Check(!g.ShotgunOwned,"Shotgun purchase requires funds");
                    g.Money=120;g.InteractFrontier();Check(g.ShotgunOwned&&g.Weapon==WeaponType.Shotgun&&g.Ammo==2&&g.Money==0,"Buy and equip two-round shotgun");
                    g.Player.X=1500;g.Player.Y=2800;g.Bullets.Clear();g.Cooldown=0;g.Mouse=g.Project(1900,2800,43);g.Fire();
                    Check(g.Bullets.Count==7&&g.Ammo==1&&g.Bullets.All(b=>b.Life<.4f),"Town shooting allowed; seven short-range pellets");
                    g.Cooldown=0;g.Fire();g.Cooldown=0;g.Fire();Check(g.Ammo==0&&g.Bullets.Count==14,"Empty shotgun cannot shoot");
                    g.Bullets.Clear();g.Reload();Tick(g,1.9f);Check(g.Ammo==2,"Shotgun reloads two rounds");
                    At(g,gun);g.Money=200;g.AlternateService();Check(g.GunUpgrade==1&&g.Money==0,"T purchases upgrade");
                    foreach(Body n in g.Residents) { n.X=800;n.Y=2800; }
                    Body victim=g.Residents[0];victim.X=1500;victim.Y=2800;g.Player.X=1300;g.Player.Y=2800;g.CameraX=1300;g.CameraY=2800;
                    g.SwitchWeapon(WeaponType.Rifle);g.Cooldown=0;g.Mouse=g.Project(victim.X,victim.Y,43);g.Invulnerable=100;cash=g.Money;g.Fire();Tick(g,.3f);
                    Check(victim.HP==0&&g.Wanted==1&&g.Money==cash,"Civilian kill through projectile creates wanted with no cash");
                    g.HurtResident(victim,100);Check(g.Wanted==1,"No repeat wanted from corpse");
                    Tick(g,4);Body officer=g.Enemies.FirstOrDefault(e=>e.Police&&e.Guard==0);Check(officer!=null,"Police dispatched");
                    officer.X=1500;officer.Y=3700;officer.NextNavigation=0;officer.Navigation.Clear();g.Player.X=1500;g.Player.Y=2800;g.Invulnerable=100;
                    Tick(g,6);Check(Distance(g.Player,officer)<200,"Police navigate around station and pursue");
                    Frame(g,Path.Combine(directory,"02-wanted.png"));
                    Check(g.SaveFrontier()&&g.LoadFrontier()&&g.Wanted==1&&g.Residents[0].HP==0&&g.ShotgunOwned,"Save retains wanted, civilian death, shotgun");
                    g.Player.X=500;g.Player.Y=200;g.PoliceClock=999;g.Invulnerable=100;Tick(g,26);Check(g.Wanted==0,"Escape police contact within the same district ends one star");
                    At(g,g.Services.First(s=>s.Kind=="bounty"));g.InteractFrontier();Check(g.Contract,"Bounty accepted");
                    Body target=g.Enemies.First(e=>!e.Elite);g.Player.X=target.X-160;g.Player.Y=target.Y;g.CameraX=g.Player.X;g.CameraY=g.Player.Y;
                    g.Weapon=WeaponType.Rifle;g.Ammo=8;g.Cooldown=0;g.Mouse=g.Project(target.X,target.Y,43);cash=g.Money;g.Fire();Tick(g,.22f);
                    Check(g.Kills==1&&g.Money==cash+10,"Gang kill pays exactly ten dollars");
                    Frame(g,Path.Combine(directory,"03-mountain-camp.png"));
                    foreach(Body e in g.Enemies)e.HP=0;g.Player.X=1500;g.Player.Y=2800;cash=g.Money;Tick(g,.04f);
                    Check(g.CampCleared[0]&&g.CampCleared[1]&&g.Money==cash,"Camp completion gives no additional cash");
                    At(g,g.Services.First(s=>s.Kind=="bounty"));g.InteractFrontier();Check(g.Enemies.Count==18&&!g.CampCleared[0],"Bounty repeat repopulates gangs");
                    At(g,g.Services.First(s=>s.Kind=="house"));g.Money=600;for(int stage=0;stage<3;stage++)g.InteractFrontier();Check(g.HouseStage[0]==3&&g.Money==0,"House stages retained");
                    At(g,g.Services.First(s=>s.Kind=="station"));g.Money=100;g.RailClock=0;g.InteractFrontier();Check(g.Aboard&&g.Money==80,"Board west train");
                    Tick(g,FrontierGame.StationWait+g.TripSeconds*.5f);Check(g.Aboard&&g.Player.X>4000&&g.Player.Y>3300,"Train follows faster curved route");Frame(g,Path.Combine(directory,"04-train.png"));
                    Check(g.SaveFrontier()&&g.LoadFrontier()&&g.Aboard,"Restore moving train");Tick(g,g.TripSeconds*.6f);Check(!g.Aboard&&g.Player.X==10500&&g.Player.Y==4860,"Arrive southeast station");
                    At(g,g.Services.First(s=>s.Kind=="station"&&s.Index==1));g.AlternateService();Tick(g,2*FrontierGame.StationWait+g.LegSeconds(1)+g.LegSeconds(2)+.2f);Check(!g.Aboard&&g.Player.X==1500&&g.Player.Y==3460,"Return ticket passes Stonebridge and arrives west");
                    g.SaveFrontier();XmlDocument old=new XmlDocument();old.Load(g.SavePath);XmlElement root=old.DocumentElement;root.SetAttribute("version","1");root.SetAttribute("weapon","1");root.SetAttribute("x","10500");root.SetAttribute("y","2800");root.SetAttribute("aboard","False");foreach(XmlElement n in root.SelectNodes("enemy[@police='True']").Cast<XmlElement>().ToArray())root.RemoveChild(n);old.Save(g.SavePath);
                    Check(g.LoadFrontier()&&g.Player.Y==4200&&g.HouseStage[0]==3,"Legacy eastern position migrates with house intact");
                    g.SaveFrontier();g.SaveFrontier();File.WriteAllText(g.SavePath,"broken");Check(g.LoadFrontier(),"Corrupt primary recovers backup");
                    g.WorldMap=true;g.Paused=true;Frame(g,Path.Combine(directory,"05-map.png"));g.WorldMap=false;g.Paused=false;
                    g.Player.X=3900;g.Player.Y=1200;g.CameraX=3900;g.CameraY=1200;Frame(g,Path.Combine(directory,"06-mountain-road.png"));
                    using(Bitmap bmp=new Bitmap(1280,800))using(Graphics graphics=Graphics.FromImage(bmp))using(GameRenderer renderer=new GameRenderer()) { Stopwatch clock=Stopwatch.StartNew();for(int i=0;i<120;i++)renderer.Draw(g,graphics,1280,800);clock.Stop();log+="120 mountain frames: "+clock.ElapsedMilliseconds+" ms, average "+(clock.Elapsed.TotalMilliseconds/120).ToString("0.00")+" ms (not device FPS)\r\n"; }
                }
                File.WriteAllText(Path.Combine(directory,"openworld-test.txt"),"PASS\r\n"+log);
            } catch(Exception e) { File.WriteAllText(Path.Combine(directory,"openworld-test.txt"),"FAIL\r\n"+log+e);Environment.ExitCode=1; }
        }
        static float Distance(Body a,Body b) { return (float)Math.Sqrt((a.X-b.X)*(a.X-b.X)+(a.Y-b.Y)*(a.Y-b.Y)); }
    }
}
