using System;
using System.Drawing;
using System.IO;
using System.Linq;
namespace ArthurFrontier {
    static class NeighborhoodTest {
        static string log="";
        static void Check(bool value,string message) { if(!value)throw new Exception(message);log+="PASS "+message+"\r\n"; }
        static void Frame(FrontierGame game,string path) { using(Bitmap image=new Bitmap(1280,800))using(Graphics graphics=Graphics.FromImage(image))using(GameRenderer renderer=new GameRenderer()) { renderer.Draw(game,graphics,1280,800);image.Save(path); } }
        public static void Run(string dir) {
            Directory.CreateDirectory(dir);
            try { using(FrontierGame g=new FrontierGame()) {
                g.SavePath=Path.Combine(dir,"daylight-"+Guid.NewGuid().ToString("N")+".xml");g.Muted=true;g.StartFrontier();
                Building[] homes=g.Buildings.Where(b=>b.Kind=="home").ToArray();
                Check(homes.Length==28,"28 residential houses across five settlements");
                foreach(Building h in homes) {
                    RectangleF area=new RectangleF(h.X-16,h.Y-16,h.W+32,h.H+32);
                    Check(!g.Buildings.Any(b=>b!=h&&area.IntersectsWith(new RectangleF(b.X,b.Y,b.W,b.H))),"House clear of other buildings at "+h.X+","+h.Y);
                    Check(!g.Services.Any(s=>area.Contains(s.X,s.Y))&&!g.Residents.Any(r=>area.Contains(r.X,r.Y)),"Services and resident spawns accessible at "+h.X+","+h.Y);
                    foreach(PointF p in new[]{new PointF(h.X,h.Y),new PointF(h.X+h.W,h.Y+h.H),new PointF(h.X+h.W/2,h.Y+h.H/2)})Check(!g.NearRail(p.X,p.Y),"House clear of railway");
                }
                Check(g.WorldHour==8&&g.NightStrength==0&&g.LitHouseCount==0,"New game begins at 08:00 with lamps off");
                g.Player.X=1980;g.Player.Y=2600;g.CameraX=1920;g.CameraY=2450;g.NoticeTime=0;Frame(g,Path.Combine(dir,"day.png"));
                g.Elapsed=275;Check(Math.Abs(g.WorldHour-19)<.001&&Math.Abs(g.NightStrength-.5f)<.001,"Dusk fades gradually at 19:00");Frame(g,Path.Combine(dir,"dusk.png"));
                g.Elapsed=350;Check(g.WorldHour==22&&g.NightStrength==1&&g.LitHouseCount==28,"All resident lamps automatically lit at 22:00");Frame(g,Path.Combine(dir,"night.png"));
                g.HouseStage[0]=3;Check(g.LitHouseCount==29,"Completed player house has automatic lamp");
                g.Paused=true;g.Update(1);Check(g.Elapsed==350,"Pause freezes day-night time");g.Paused=false;
                Check(g.SaveFrontier()&&g.LoadFrontier()&&g.Elapsed==350&&g.LitHouseCount==29,"Existing save format preserves time and player house lamps");
                g.Elapsed=550;Check(g.WorldHour==6&&g.NightStrength==.5f,"Sunrise gradually extinguishes lamps");
                g.Elapsed=600;Check(g.WorldHour==8&&g.NightStrength==0&&g.LitHouseCount==0,"Next morning turns all lamps off");
                log+="ALL NEIGHBORHOOD TESTS PASSED\r\n";
            }File.WriteAllText(Path.Combine(dir,"neighborhood-test.txt"),log); }
            catch(Exception e) { File.WriteAllText(Path.Combine(dir,"neighborhood-test.txt"),log+e);Environment.ExitCode=1; }
        }
    }
}
