using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
namespace ArthurFrontier {
    static class PrisonDramaTest {
        static string log="";
        static void Check(bool ok,string label) { if(!ok)throw new Exception(label);log+="PASS "+label+"\r\n"; }
        static void Tick(FrontierGame g,float time) { for(float t=0;t<time;t+=.02f)g.Update(.02f); }
        static void Frame(FrontierGame g,string path) { g.NoticeTime=0;using(Bitmap b=new Bitmap(1280,800))using(Graphics c=Graphics.FromImage(b))using(GameRenderer r=new GameRenderer()) { r.Draw(g,c,1280,800);b.Save(path); } }
        public static void Run(string dir) {
            Directory.CreateDirectory(dir);
            try { using(FrontierGame g=new FrontierGame()) {
                g.Muted=true;g.SavePath=Path.Combine(dir,"prison-"+Guid.NewGuid().ToString("N")+".xml");g.StartFrontier();g.Invulnerable=1000;
                Tick(g,119.8f);Check(g.ExecutionPhase==0,"No execution before two minutes");Tick(g,.3f);
                Check(g.ExecutionPhase==1&&g.ExecutionCrowd.Count>=5&&g.ExecutionCrowd.Count<=6&&g.Enemies.Count(e=>e.Guard>=5)==2,"Two minute deadline spawns two escorts and five or six spectators");
                g.ExecutionCrowd[0].HP=75;Check(g.SaveFrontier()&&g.LoadFrontier()&&g.ExecutionPhase==1&&g.ExecutionCrowd[0].HP==75,"Escort and crowd health survive save reload");g.Invulnerable=1000;
                Tick(g,18);Check(g.ExecutionPhase==2,"Prisoner actually follows route through doorway to gallows");
                float clock=g.ExecutionClock;g.Paused=true;Tick(g,3);Check(g.ExecutionClock==clock,"Pause freezes execution");g.Paused=false;
                g.Player.X=g.CameraX=4120;g.Player.Y=g.CameraY=4950;Frame(g,Path.Combine(dir,"01-gallows.png"));Tick(g,clock+.1f);Check(g.ExecutionPhase==3,"Execution occurs after final rescue window");Frame(g,Path.Combine(dir,"02-aftermath.png"));
                Tick(g,12);Check(g.ExecutionPhase==0&&g.PrisonerGeneration==2&&g.ExecutionCrowd.Count==0&&g.SentenceClock<10,"New prisoner enters cell and starts fresh deadline");
                g.SentenceClock=119.99f;Tick(g,.04f);foreach(Body e in g.Enemies.Where(e=>e.Guard>=5))e.HP=0;g.Player.X=g.PrisonerPosition.X;g.Player.Y=g.PrisonerPosition.Y+80;g.InteractFrontier();Check(g.PrisonerFree&&g.ExecutionPhase==0,"Q rescues escorted prisoner after escort defeated");Tick(g,1);Check(g.SentenceClock==0,"Rescued prisoner no longer executes");
                g.Player.X=1800;g.Player.Y=2800;g.Invulnerable=0;g.Player.HP=10;g.Wanted=1;g.Bullets.Clear();g.Bullets.Add(new Bullet { X=1800,Y=2800,Life=1,PoliceShot=true });Tick(g,.02f);Check(g.ArrestPending&&g.State=="playing","Lethal police bullet schedules arrest without game over");Tick(g,.02f);Check(g.Captured&&g.Player.HP==100&&g.Player.X==3250,"Arrest places Arthur inside locked cell");
                int ammo=g.Ammo;g.Fire();g.ToggleHorse();Check(g.Ammo==ammo&&!g.Mounted,"Prisoner cannot shoot or mount");for(int i=0;i<50;i++)g.Move(g.Player,-10,0);Check(g.Player.X>=3235,"Cell prevents walking through wall");
                g.KeyPressed(Keys.T);g.KeyPressed(Keys.T);Check(g.DigProgress==1,"Holding T does not count as repeated taps");g.KeysDown.Remove(Keys.T);
                for(int i=1;i<15;i++){g.KeyPressed(Keys.T);g.KeysDown.Remove(Keys.T);}Check(g.SaveFrontier()&&g.LoadFrontier()&&g.Captured&&g.DigProgress==15,"Arrest and partial digging survive reload");Frame(g,Path.Combine(dir,"03-digging.png"));
                for(int i=15;i<30;i++){g.KeyPressed(Keys.T);g.KeysDown.Remove(Keys.T);}Check(!g.Captured&&g.EscapeHole&&g.Player.X<3200&&g.Wanted==2,"Thirty independent T taps escape and trigger wanted level");Check(!g.SecurityBlocked(3205,4675,10),"Dug wall has traversable opening");Frame(g,Path.Combine(dir,"04-escape.png"));
                Check(g.SaveFrontier()&&g.LoadFrontier()&&g.EscapeHole&&!g.Captured,"Escape hole persists");g.Invulnerable=0;g.Player.HP=1;g.Damage(14,false);Check(g.State!="playing"&&!g.ArrestPending,"Non-police lethal attack retains defeat behavior");
                log+="ALL PRISON DRAMA TESTS PASSED\r\n";
            } }catch(Exception e){log+=e;Environment.ExitCode=1;}File.WriteAllText(Path.Combine(dir,"prison-test.txt"),log);
        }
    }
}
