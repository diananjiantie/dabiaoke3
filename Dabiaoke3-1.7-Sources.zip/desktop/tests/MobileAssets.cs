using System;
using System.IO;
using System.Text;
using System.Globalization;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        public void ExportMobileAssets(string dir) {
            Directory.CreateDirectory(dir);SavePath=Path.Combine(dir,"unused-save.xml");Muted=true;StartFrontier();
            StringBuilder manifest=new StringBuilder("window.DesktopAssets={buildings:[");int n=0;
            foreach(Building b in Buildings) {
                BuildingSprite s=buildingSprites[b];string name="desktop-building-"+n++;
                s.Normal.Save(Path.Combine(dir,name+".png"));s.Faded.Save(Path.Combine(dir,name+"-fade.png"));
                if(n>1)manifest.Append(",");
                manifest.AppendFormat(CultureInfo.InvariantCulture,"{{x:{0},y:{1},w:{2},h:{3},dx:{4},dy:{5},home:{6},image:'{7}'}}",b.X,b.Y,b.W,b.H,s.X-b.X-.24f*b.Y,s.Y-.62f*b.Y,b.Kind=="home"?"true":"false",name);
            }
            manifest.Append("]};");File.WriteAllText(Path.Combine(dir,"desktop-assets.js"),manifest.ToString(),Encoding.UTF8);
            actorSprites[9000].Save(Path.Combine(dir,"desktop-tree.png"));actorSprites[9001].Save(Path.Combine(dir,"desktop-grass.png"));
            foreach(var sound in sounds)File.WriteAllBytes(Path.Combine(dir,"desktop-"+sound.Key+".wav"),((MemoryStream)sound.Value.Stream).ToArray());
        }
    }
}
