using System;
using System.Drawing;
using System.Diagnostics;
using System.IO;
using System.Linq;
namespace ArthurFrontier {
    static class OpenWorldTest {
        static void Check(bool ok,string name) { if(!ok)throw new Exception(name);log+=name+"\r\n"; }
        static string log="";
        static void Frame(FrontierGame game,string path) { using(Bitmap image=new Bitmap(1280,800))using(Graphics g=Graphics.FromImage(image))using(GameRenderer renderer=new GameRenderer()) { renderer.Draw(game,g,1280,800);image.Save(path); } }
        static void At(FrontierGame g,WorldService s) { g.Player.X=s.X;g.Player.Y=s.Y;g.CameraX=s.X;g.CameraY=s.Y; }
        static void Tick(FrontierGame g,float seconds) { for(float t=0;t<seconds;t+=.02f)g.Update(.02f); }
        public static void Run(string directory) {
            Directory.CreateDirectory(directory);
            try {
                using(FrontierGame g=new FrontierGame()) {
                    g.Muted=true;g.SavePath=Path.Combine(directory,"save-"+Guid.NewGuid().ToString("N")+".xml");g.StartFrontier();
                    Check(g.Level==4&&g.WorldW==12000&&g.WorldH==6000,"Large world starts with isolated save");
                    Check(g.Enemies.Count==18&&g.Residents.Count==14,"Two gang camps and fourteen separate neutral residents");
                    Check(g.Enemies.All(e=>!g.Blocked(e.X,e.Y,e.R)),"All gang spawns are outside buildings and water");
                    Check(g.Services.Count(s=>s.Kind=="station")==2&&g.Services.Count(s=>s.Kind=="gun")==2,"Two stations and two gun shops");
                    Check(g.Blocked(6000,2400,16)&&!g.Blocked(6000,2850,16)&&!g.Blocked(6000,3300,16),"River blocks passage except road and rail bridges");
                    int ammo=g.Ammo;g.Fire();Check(g.Ammo==ammo,"Town gun safety leaves ammo intact");
                    g.Invulnerable=0;g.Damage(20);Check(g.Player.HP==100,"Town remains safe from incoming damage");
                    Frame(g,Path.Combine(directory,"01-town.png"));
                    WorldService saloon=g.Services.First(s=>s.Kind=="saloon"),gun=g.Services.First(s=>s.Kind=="gun"),board=g.Services.First(s=>s.Kind=="bounty");
                    At(g,saloon);g.Player.HP=50;int cash=g.Money;g.InteractFrontier();Check(g.Player.HP==100&&g.Money==cash-30,"Tavern heals and charges bounty money");
                    At(g,gun);g.Money=0;g.InteractFrontier();Check(g.GunUpgrade==0&&g.Money==0,"Shop rejects insufficient funds");
                    g.Money=200;g.InteractFrontier();Check(g.GunUpgrade==1&&g.Money==0,"Gun shop spends 200 for permanent damage upgrade");
                    At(g,board);g.InteractFrontier();Check(g.Contract,"Bounty contract accepted");
                    WorldService plot=g.Services.First(s=>s.Kind=="house");At(g,plot);g.Money=600;
                    for(int stage=1;stage<=3;stage++) { g.InteractFrontier();Check(g.HouseStage[0]==stage,"House construction stage "+stage); }
                    Check(g.Money==0&&g.Blocked(g.Plots[0].X,g.Plots[0].Y-60,16),"House cost totals 600 and finished walls collide");
                    g.Player.HP=25;g.InteractFrontier();Check(g.Player.HP==100,"Completed home provides free rest");
                    Frame(g,Path.Combine(directory,"02-house.png"));
                    WorldService station=g.Services.First(s=>s.Kind=="station");At(g,station);g.Money=100;g.RailClock=0;g.InteractFrontier();
                    Check(g.Aboard&&g.Money==80,"Train ticket charges 20 and boards");
                    Tick(g,25);Check(g.Aboard&&g.Player.X>5000&&g.Player.X<6500,"Train physically traverses prairie and river");
                    Frame(g,Path.Combine(directory,"03-train.png"));
                    Check(g.SaveFrontier(),"Save during train journey");float trainX=g.Player.X;
                    Check(g.LoadFrontier()&&g.Aboard&&Math.Abs(g.Player.X-trainX)<1,"Onboard position restores from save");
                    Tick(g,18);Check(!g.Aboard&&Math.Abs(g.Player.X-10500)<1,"Train arrives and disembarks in eastern town");
                    WorldService east=g.Services.First(s=>s.Kind=="station"&&s.Index==1);At(g,east);g.InteractFrontier();Tick(g,42);
                    Check(!g.Aboard&&Math.Abs(g.Player.X-1500)<1,"Return train reaches western town");
                    // Clear one camp through the real bullet/kill path.
                    Body target=g.Enemies.First(e=>e.Camp==0&&!e.Elite);g.Player.X=target.X-200;g.Player.Y=target.Y;g.CameraX=g.Player.X;g.CameraY=g.Player.Y;
                    g.Mouse=g.Project(target.X,target.Y,g.Mounted?43:22);g.Cooldown=0;g.Invulnerable=100;g.Fire();Tick(g,.25f);
                    Check(g.Kills==1,"Rifle and purchased upgrade kill a gang member and award bounty");
                    Frame(g,Path.Combine(directory,"04-camp.png"));
                    foreach(Body e in g.Enemies)e.HP=0;g.Player.X=1500;g.Player.Y=2800;cash=g.Money;Tick(g,.04f);
                    Check(g.CampCleared[0]&&g.CampCleared[1]&&g.Money==cash+600,"Cleared camps award contract bonuses once");
                    cash=g.Money;Tick(g,.1f);Check(g.Money==cash,"Camp bounty cannot be claimed twice");
                    At(g,g.Services.First(s=>s.Kind=="bounty"));g.InteractFrontier();Check(g.Enemies.Count==18&&!g.CampCleared[0],"Bounty board starts a repeatable gang contract");
                    Check(g.SaveFrontier(),"Full progress save succeeds");g.Money=1;g.HouseStage[0]=0;g.GunUpgrade=0;
                    Check(g.LoadFrontier()&&g.Money==cash&&g.HouseStage[0]==3&&g.GunUpgrade==1,"Money, house, upgrade and enemies survive round trip");
                    File.WriteAllText(g.SavePath,"broken");Check(g.LoadFrontier(),"Corrupt primary recovers atomic backup");
                    g.WorldMap=true;g.Paused=true;Frame(g,Path.Combine(directory,"05-map.png"));g.WorldMap=false;g.Paused=false;
                    g.Home();Frame(g,Path.Combine(directory,"06-menu.png"));g.LoadFrontier();
                    using(Bitmap bmp=new Bitmap(1280,800))using(Graphics graphics=Graphics.FromImage(bmp))using(GameRenderer renderer=new GameRenderer()) {
                        Stopwatch clock=Stopwatch.StartNew();for(int i=0;i<120;i++)renderer.Draw(g,graphics,1280,800);clock.Stop();
                        log+="120 offscreen frames: "+clock.ElapsedMilliseconds+" ms; average "+(clock.Elapsed.TotalMilliseconds/120).ToString("0.00")+" ms (not device FPS)\r\n";
                    }
                }
                File.WriteAllText(Path.Combine(directory,"openworld-test.txt"),"PASS\r\n"+log);
            } catch(Exception e) { File.WriteAllText(Path.Combine(directory,"openworld-test.txt"),"FAIL\r\n"+log+e);Environment.ExitCode=1; }
        }
    }
}
