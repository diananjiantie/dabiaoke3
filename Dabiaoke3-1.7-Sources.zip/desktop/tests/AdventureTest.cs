using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Xml;
namespace ArthurFrontier {
    static class AdventureTest {
        static string log="";
        static void Check(bool ok,string name) { if(!ok)throw new Exception(name);log+="PASS "+name+"\r\n"; }
        static void Tick(FrontierGame g,float seconds) { for(float t=0;t<seconds;t+=.02f)g.Update(.02f); }
        static void At(FrontierGame g,float x,float y) { g.Player.X=x;g.Player.Y=y;g.CameraX=x;g.CameraY=y;g.Horse=new PointF(x+60,y); }
        static void Frame(FrontierGame game,string file) { using(Bitmap image=new Bitmap(1280,800))using(Graphics graphics=Graphics.FromImage(image))using(GameRenderer renderer=new GameRenderer()) { renderer.Draw(game,graphics,1280,800);image.Save(file); } }
        public static void Run(string directory) {
            Directory.CreateDirectory(directory);
            try { using(FrontierGame g=new FrontierGame()) {
                g.Muted=true;g.SavePath=Path.Combine(directory,"adventure-save.xml");if(File.Exists(g.SavePath))File.Delete(g.SavePath);g.StartFrontier();
                Check(g.Residents.Count==64&&g.Services.Count(s=>s.Kind=="airport")==2,"New town, island residents and two airports");
                At(g,g.RiverCenter(2800)-230,2800);g.Mounted=true;for(int i=0;i<100;i++)g.Move(g.Player,10,0);Check(g.Player.X>g.RiverCenter(2800)+200,"Horse crosses river away from bridge");
                At(g,3200,2800);g.Mounted=false;g.Move(g.Player,100,0);Check(g.Player.X>3200,"Walking climbs mountain away from road");
                At(g,11970,1800);g.Move(g.Player,500,0);Check(g.Player.X==11970,"Ocean prevents land route to island");
                g.Enemies.Clear();g.Money=150;At(g,10900,1300);Frame(g,Path.Combine(directory,"01-airport.png"));g.InteractFrontier();
                Check(g.Flying&&g.Money==90&&g.ReturnTicket,"Airport charges fare including return");Tick(g,8);Frame(g,Path.Combine(directory,"02-flight.png"));g.Fish=3;g.SaveFrontier();
                Check(g.LoadFrontier()&&g.Flying&&g.FlightTime>7&&g.Fish==3,"Flight and fish survive save and load");Tick(g,17);
                Check(!g.Flying&&g.Player.X==22000&&!g.Ocean(g.Player.X,g.Player.Y,21),"Flight lands safely on remote island");Frame(g,Path.Combine(directory,"03-island.png"));
                g.Money=0;At(g,22000,3000);g.InteractFrontier();Tick(g,8);Frame(g,Path.Combine(directory,"06-return-flight.png"));Tick(g,16.2f);Check(!g.Flying&&g.Player.X==10900&&g.Money==0,"Free return prevents stranding without cash");
                foreach(bool returning in new[]{false,true}) {
                    g.Flying=true;g.FlightReturn=returning;g.FlightTime=8;g.Update(.02f);float oldX=g.Player.X,oldY=g.Player.Y;g.Update(.02f);
                    PointF nose=g.FlyerPoint(0,0,0,145,returning),wing=g.FlyerPoint(0,0,175,0,returning);
                    float vx=g.Player.X-oldX,vy=g.Player.Y-oldY;
                    Check(nose.X*vx+nose.Y*vy>0&&Math.Abs(nose.X*vy-nose.Y*vx)<1,"Nose follows actual flight displacement; return="+returning);
                    Check(Math.Abs(nose.X*wing.X+nose.Y*wing.Y)<.1f,"Wings perpendicular to fuselage; return="+returning);
                }g.Flying=false;g.FlightTime=0;
                g.Enemies.Clear();At(g,g.RiverCenter(3400)-g.RiverWidth(3400)-100,3400);g.Mounted=false;g.Fish=0;g.FishAction();Check(g.FishingTime>0&&!g.FishBiting,"Cast from river bank");
                for(int i=0;i<400&&!g.FishBiting;i++)g.Update(.02f);Check(g.FishBiting,"Timed fishing bite");g.FishAction();Check(g.Fish==1&&g.FishingTime==0,"Reel fish during bite window");
                WorldService fishMarket=g.Services.First(s=>s.Kind=="fish"&&s.Index==0);At(g,fishMarket.X,fishMarket.Y);g.InteractFrontier();Check(g.Fish==0&&g.Money==15,"Sell fish at market");
                g.Enemies.Clear();g.RailClock=0;At(g,1500,3300);g.StartRobbery();Check(g.Aboard&&g.Wanted==2&&g.RobberyTime==5,"Robbery boards train and raises wanted");Tick(g,5.2f);Check(g.Money==115&&g.RobberyCooldown>0,"Robbery pays once");g.StartRobbery();Check(g.RobberyTime==0,"Robbery cooldown prevents repeated payout");
                g.Aboard=false;g.Enemies.Clear();g.Wanted=0;At(g,2000,1800);g.SpawnAdventureEvent(1);At(g,g.EventPosition.X,g.EventPosition.Y);g.InteractFrontier();Check(g.EventKind==0&&g.EventsCompleted==1&&g.Money==140,"Traveller encounter resolves and pays");
                g.SpawnAdventureEvent(3);Check(g.Enemies.Count(e=>e.Camp==-2)==5,"Ambush spawns five tougher bandits");g.Enemies.Clear();At(g,g.EventPosition.X,g.EventPosition.Y);g.InteractFrontier();Check(g.EventsCompleted==2&&g.Money==190,"Rescued merchant reward");
                At(g,2000,1800);g.Enemies.Clear();g.Bullets.Clear();g.EventClock=60;g.DeadEye=true;g.Mounted=false;g.Weapon=WeaponType.Rifle;g.Ammo=8;g.Cooldown=0;
                Body a=new Body { X=2300,Y=1800,HP=100,Camp=-2 },b=new Body { X=2300,Y=1920,HP=100,Camp=-2 };
                g.Enemies.Add(a);g.Enemies.Add(b);g.Mouse=g.Project(a.X,a.Y,22);g.MarkDeadEye();g.Mouse=g.Project(b.X,b.Y,22);g.MarkDeadEye();Check(g.EyeMarks.Count==2,"Right-click marks multiple enemies");Frame(g,Path.Combine(directory,"04-deadeye.png"));g.Fire();Tick(g,1.1f);Check(a.HP==0&&b.HP==0&&g.Ammo==6,"One trigger executes both marks using two rounds");
                g.DeadEye=false;g.Enemies.Clear();g.Bullets.Clear();At(g,2000,1800);g.Money=200;Body cop=new Body { X=2350,Y=1800,HP=130,Police=true,Camp=-1,Speed=0 },gang=new Body { X=2550,Y=1800,HP=50,Camp=-2,Speed=0 };
                g.Enemies.Add(cop);g.Enemies.Add(gang);Tick(g,4);Check(gang.HP==0&&g.Money==200&&g.Wanted==0,"Police kill bandits without awarding Arthur bounty");
                g.Fish=5;g.SaveFrontier();Check(g.LoadFrontier()&&g.Fish==5&&g.RobberyCooldown>0&&g.EventsCompleted==2,"Expanded progress round trip");
                XmlDocument doc=new XmlDocument();doc.Load(g.SavePath);doc.DocumentElement.SetAttribute("version","2");foreach(XmlElement n in doc.SelectNodes("frontier/resident").Cast<XmlElement>().ToArray())if(int.Parse(n.GetAttribute("id"))>=36)n.ParentNode.RemoveChild(n);doc.Save(g.SavePath);
                Check(g.LoadFrontier()&&g.Residents.Count==64&&g.Fish==0,"Version two saves migrate with new residents");
                g.WorldMap=true;Frame(g,Path.Combine(directory,"05-map.png"));g.WorldMap=false;
                log+="ALL ADVENTURE TESTS PASSED\r\n";
            }File.WriteAllText(Path.Combine(directory,"adventure-test.txt"),log); }
            catch(Exception ex) { File.WriteAllText(Path.Combine(directory,"adventure-test.txt"),log+ex);Environment.ExitCode=1; }
        }
    }
}
