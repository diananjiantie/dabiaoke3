using System;
using System.Drawing;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        static readonly Color Soil3=Color.FromArgb(101,133,67),Wood3=Color.FromArgb(174,125,78),Dark3=Color.FromArgb(54,46,35),Iron3=Color.FromArgb(57,66,65),Skin3=Color.FromArgb(201,156,110);
        static readonly Color[] CivilianColors3={Color.FromArgb(129,86,53),Color.FromArgb(62,104,130),Color.FromArgb(95,107,74),Color.FromArgb(146,74,76),Color.FromArgb(204,191,157),Color.FromArgb(151,114,54),Color.FromArgb(62,65,79),Color.FromArgb(106,88,128)};
        public Color ResidentCoat3(int id){Color c=CivilianColors3[id%8];int tint=(id/8)*5;return Color.FromArgb(Math.Min(255,c.R+tint),Math.Min(255,c.G+tint),Math.Min(255,c.B+tint));}
        Color ResidentSkin3(int id){return id%4==0?Color.FromArgb(132,88,58):id%4==1?Color.FromArgb(224,177,132):id%4==2?Color.FromArgb(178,120,78):Skin3;}
        // Persisted game time drives weather, so save/load preserves the current shower.
        public float RainStrength3 { get {if(!IsFrontier)return 0;float t=Elapsed%300;return t<100||t>175?0:Math.Min(1,Math.Min((t-100)/12,(175-t)/12));} }
        void SkyDisc3(ThreeDMesh m,float x,float y,float z,float radius,Color color){float c=(float)Math.Cos(CameraYaw),s=(float)Math.Sin(CameraYaw);for(int layer=2;layer>=0;layer--){float r=radius*(1+layer*.18f);Color col=layer==0?color:Color.FromArgb(color.A/(layer==1?8:18),color.R,color.G,color.B);for(int i=0;i<32;i++){float a=i*(float)Math.PI/16,b=(i+1)*(float)Math.PI/16,ax=(float)Math.Cos(a)*r,az=(float)Math.Sin(a)*r,bx=(float)Math.Cos(b)*r,bz=(float)Math.Sin(b)*r;m.Tri(new V3(x,y,z),new V3(x+c*ax+s*CameraSin*az,y+s*ax-c*CameraSin*az,z+CameraCos*az),new V3(x+c*bx+s*CameraSin*bz,y+s*bx-c*CameraSin*bz,z+CameraCos*bz),col,1);}}}
        public void BuildSky3(ThreeDMesh m){
            m.Reset(1);float night=IsFrontier?NightStrength:0,rain=RainStrength3,z=Ground3(CameraX,CameraY)+CameraFocusHeight;
            float hour=IsFrontier?WorldHour:10,angle=(hour-6)*(float)Math.PI/12;
            for(int body=0;body<2;body++){float a=angle+body*(float)Math.PI,up=(float)Math.Sin(a);if(up<-.12f)continue;float x=CameraX+(float)Math.Cos(a)*3700,y=CameraY-1000,h=z+up*3400;Color col=body==0?Color.FromArgb((int)(255*(1-rain*.7f)),255,222,140):Color.FromArgb((int)(255*(1-rain*.7f)),216,228,246);SkyDisc3(m,x,y,h,body==0?95:70,col);}
            if(night>.1f)for(int i=0;i<110;i++){float a=i*2.399963f,up=.15f+(i*37%83)/100f,rad=(float)Math.Sqrt(1-up*up)*4200;int alpha=(int)(210*night*(1-rain));m.Box(CameraX+(float)Math.Cos(a)*rad,CameraY+(float)Math.Sin(a)*rad,z+up*4200,5+i%3,5+i%3,5+i%3,Color.FromArgb(alpha,225,235,255));}
            for(int i=0;i<22;i++){float a=i*2.399963f+Elapsed*.0008f,rad=1500+i%5*430,x=CameraX+(float)Math.Cos(a)*rad,y=CameraY+(float)Math.Sin(a)*rad;int shade=(int)(239-night*165-rain*65);Color cloud=Color.FromArgb(235,shade,Math.Min(255,shade+5),Math.Min(255,shade+12));for(int j=0;j<3;j++)m.Cloud(x+j*170,y+(j%2)*65,z+920+i%4*150,230,130,55+j%2*35,cloud);}
        }
        void Rain3(ThreeDMesh m){float strength=RainStrength3;if(strength<=0)return;float rightX=(float)Math.Cos(CameraYaw),rightY=(float)Math.Sin(CameraYaw);int count=(int)(160*strength);for(int i=0;i<count;i++){
            float x=Player.X-650+(i*173%1300),y=Player.Y-650+(i*337%1300),z=Ground3(x,y)+(650-((Elapsed*680+i*47)%650));bool roof=false;foreach(Building b in Buildings)if(x>b.X-12&&x<b.X+b.W+12&&y>b.Y-12&&y<b.Y+b.H+35&&z<230){roof=true;break;}if(roof)continue;
            m.Tri(new V3(x-rightX*.7f,y-rightY*.7f,z),new V3(x+rightX*.7f,y+rightY*.7f,z),new V3(x-7,y-3,z+32),Color.FromArgb(140,167,197,217),1);
        }}
        public const float TrainDeck3=230,TrainSpacing3=260;
        public void Tree3(ThreeDMesh m,float x,float y,int seed){float height=420+Math.Abs(seed%5)*45;if(recordTrees3)shaftTrees3.Add(new V3(x,y,Ground3(x,y)+height*.67f));m.At(x,y,Ground3(x,y),0);m.Box(-12,-12,0,24,24,height*.62f,Wood3);m.Box(-95,-85,height*.38f,190,170,height*.26f,Color.FromArgb(42,79,44));m.Box(-72,-65,height*.64f,144,130,height*.22f,Color.FromArgb(49,91,47));m.Box(-45,-40,height*.86f,90,80,height*.14f,Color.FromArgb(65,105,52));m.At(0,0,0,0);}
        bool Near3(float x,float y,float radius){return Math.Abs(x-CameraX)<radius&&Math.Abs(y-CameraY)<radius;}
        void Person3(ThreeDMesh m,Body b,Color coat,bool horse,bool armed,float lift=0){if(!Near3(b.X,b.Y,1700))return;if(horse)Horse3(m,b.X,b.Y,b.Angle,b.Step);m.At(b.X,b.Y,Ground3(b.X,b.Y),b.Angle);if(!horse)m.Shadow(4,3,.25f,20,16,75);m.At(b.X,b.Y,Ground3(b.X,b.Y)+lift+(horse?38:0),b.Angle);
            bool civilian=Residents.Contains(b)||ExecutionCrowd.Contains(b);int id=Math.Abs(b.ResidentId),style=id%8;Color skin=Skin3,hair=Color.FromArgb(79,51,31);if(civilian){coat=ResidentCoat3(id);skin=ResidentSkin3(id);hair=id%5==0?Color.FromArgb(155,151,139):id%3==0?Color.FromArgb(45,32,25):Color.FromArgb(95,58,30);m.ZScale=.93f+(id%5)*.035f;}
            float gait=b==Player?MotionBlend3:civilian?b.WalkBlend3:Math.Min(1,b.Speed/100),phase=(float)Math.Sin(b.Step),stride=horse?0:phase*7*gait;
            for(int side=-1;side<=1;side+=2){float legY=horse?side*25:side*7,legX=side*stride,footLift=horse?0:Math.Max(0,side*phase)*5*gait;m.Limb(0,legY,29,legX,footLift+5,10,10,Iron3);m.Box(-3+legX,legY-6,footLift,16,12,6,Dark3);}
            m.OriginZ+=Math.Abs(phase)*.65f*gait;m.Box(-11,-14,28,22,28,29,coat);m.Box(-12,-15,28,24,30,4,Dark3);m.Box(11,-3,29,2,6,3,Color.Goldenrod);
            m.Box(-10,-10,57,20,20,22,skin);m.Box(-11,-11,70,6,22,10,hair);m.Box(-6,-11,77,17,22,3,hair);
            m.Box(10,-6,68,1,2,2,Dark3);m.Box(10,4,68,1,2,2,Dark3);m.Box(10,-2,63,2,4,3,skin);
            if(!civilian||style==0||style==2||style==5){m.Box(-17,-18,80,34,36,3,Wood3);m.Box(-11,-12,83,22,24,9,Dark3);}
            if(civilian){
                if(style==1){m.Box(-12,-12,79,24,24,8,coat);m.Box(8,-12,78,12,24,2,Dark3);m.Box(12,-11,31,3,22,22,Color.FromArgb(217,200,164));}
                if(style==2){m.Box(11,-9,58,2,18,6,hair);m.Box(-17,22,0,3,3,40,Wood3);}
                if(style==3){m.Box(-13,-12,58,5,24,20,hair);m.Box(-13,-16,15,26,32,22,coat);m.Box(12,-10,32,2,20,20,Color.FromArgb(229,209,172));}
                if(style==4){m.Box(-12,-12,79,24,24,14,Color.FromArgb(212,205,178));m.Box(12,-7,32,2,14,22,Color.FromArgb(225,217,196));}
                if(style==5){m.Box(-19,-12,35,8,24,22,Wood3);m.Box(12,-13,49,2,26,4,Color.FromArgb(153,57,43));}
                if(style==6){m.Box(-14,-14,80,28,28,2,Dark3);m.Box(-10,-10,82,20,20,17,Dark3);m.Box(12,-2,37,2,4,18,Color.FromArgb(152,54,43));}
                if(style==7){m.Box(11,-10,34,2,4,22,Dark3);m.Box(11,6,34,2,4,22,Dark3);m.Box(10,-8,60,2,16,5,hair);}
                m.Box(12,-10,44,2,3,3,Color.FromArgb(170+id%70,130+id*3%80,70+id*7%100));
            }
            for(int side=-1;side<=1;side+=2){float armX=armed?3:-5-side*stride*.55f;m.Limb(0,side*19,53,armX,34,9,9,coat);m.Box(armX-4,side*19-4,29,8,8,6,skin);}
            if(armed){m.Box(10,-24,42,20,9,9,Skin3);m.Box(21,-22,48,32,5,5,Iron3);m.Box(17,-23,43,13,7,5,Wood3);}m.ZScale=1;m.At(0,0,0,0);
        }
        void Horse3(ThreeDMesh m,float x,float y,float angle,float step){if(!Near3(x,y,1700))return;m.At(x,y,Ground3(x,y),angle);m.Shadow(6,4,.25f,52,24,80);Color fur=Color.FromArgb(149,94,53);float phase=(float)Math.Sin(step);
            for(int i=0;i<4;i++){float swing=(i%2==0?phase:-phase)*7,up=Math.Max(0,swing)*.5f,xx=(i<2?-27:23)+swing,yy=i%2==0?-15:7;m.Box(xx,yy,up,9,9,35-up,fur);m.Box(xx-1,yy-1,up,11,11,6,Dark3);}
            m.Box(-36,-18,32,72,36,28,fur);m.Box(23,-12,52,18,24,25,fur);m.Box(27,-12,73,32,24,17,fur);m.Box(29,-11,90,5,6,10,fur);m.Box(29,5,90,5,6,10,fur);m.Box(24,-3,58,6,6,27,Dark3);m.Box(48,-13,81,4,2,4,Color.Black);m.Box(48,11,81,4,2,4,Color.Black);m.Box(54,-13,74,3,26,3,Dark3);m.Box(-14,-20,60,29,40,4,Color.FromArgb(151,48,36));m.Box(-12,-18,64,24,36,5,Dark3);m.Box(-44,-4,35,10,8,26,Dark3);m.At(0,0,0,0);
        }
        void House3(ThreeDMesh m,Building b){if(!Near3(b.X+b.W/2,b.Y+b.H/2,2000))return;float x=b.X,y=b.Y,w=b.W,h=b.H;bool small=b.Kind=="crate"||b.Kind=="barrel";m.At(0,0,0,0);if(small){m.Box(x,y,0,w,h,32,Wood3);return;}
            m.BuildingShadow(x,y,w,h,222);m.ZScale=1.6f;m.Box(x-4,y-4,-.2f,w+8,h+8,6,Color.FromArgb(95,73,49));m.Box(x,y,0,w,h,95,Wood3);
            m.Roof(x-12,y-12,95,w+24,h+24,44,Color.FromArgb(116,78,53));
            for(float seam=x;seam<x+w;seam+=24)m.Roof(seam,y-12,95.6f,1.5f,h+24,44,Color.FromArgb(148,107,72));
            m.Box(x-8,y+h,0,w+16,34,8,Wood3);m.Box(x+w/2-18,y+h+1,8,36,3,61,Dark3);for(int i=0;i<2;i++){float wx=x+(i==0?20:w-56);m.Box(wx-3,y+h+1,43,40,3,31,Color.FromArgb(203,171,116));m.Box(wx,y+h+5,46,34,2,25,Color.FromArgb(61,89,102));m.Box(wx+16,y+h+8,46,2,2,25,Wood3);}for(int z=16;z<90;z+=16)m.Box(x,y+h+1,z,w,1,1,Dark3);m.Box(x+25,y+25,80,24,24,60,Iron3);
            HouseDetail3(m,b);if(b.Kind=="home")Lamp3(m,x+w/2+34,y+h+7);m.ZScale=1;
        }
        void Lamp3(ThreeDMesh m,float x,float y){m.Box(x-8,y,70,4,9,20,Iron3);m.Box(x-8,y,89,17,4,3,Iron3);m.Box(x+5,y,75,2,4,16,Iron3);m.Box(x-1,y-3,61,12,12,3,Iron3);float old=m.Light;m.Light=1;m.Box(x+1,y-1,64,8,8,12,NightStrength>0?Color.FromArgb(255,218,118):Color.FromArgb(144,131,96));if(NightStrength>0){for(int ring=4;ring>=1;ring--){float r=ring*18;Color glow=Color.FromArgb(12,255,190,75);for(int i=0;i<16;i++){float a=i*(float)Math.PI/8,b=(i+1)*(float)Math.PI/8;m.Tri(new V3(x+4,y+27,.4f),new V3(x+4+(float)Math.Cos(a)*r,y+27+(float)Math.Sin(a)*r,.4f),new V3(x+4+(float)Math.Cos(b)*r,y+27+(float)Math.Sin(b)*r,.4f),glow,1);}}}m.Light=old;m.Box(x-1,y-3,76,12,12,3,Iron3);}
        void Vehicle3(ThreeDMesh m,float x,float y,float angle,bool engine,bool wagon){if(!Near3(x,y,2200))return;m.XScale=wagon?1:1.5f;m.YScale=wagon?1:1.7f;m.ZScale=wagon?1:1.9f;m.At(x,y,Ground3(x,y),VehicleModelHeading3(angle,engine));m.Box(-80,-35,20,160,70,27,Wood3);for(int i=0;i<4;i++)m.Wheel(i<2?-53:57,i%2==0?-42:34,23,18,8,Iron3);if(engine){m.Box(-60,-28,46,95,56,50,Iron3);m.Box(37,-31,46,37,62,68,Wood3);m.Cylinder(-25,-1,91,10,10,45,Iron3);m.Cylinder(-25,-1,128,14,14,8,Dark3);for(int band=0;band<3;band++)m.Box(-55+band*29,-29,49,3,58,47,Color.FromArgb(116,124,117));}else if(!wagon){m.Box(-66,-30,47,132,60,52,Wood3);m.Roof(-72,-35,100,144,70,20,Dark3);for(int i=0;i<5;i++)m.Box(-55+i*24,31,64,16,2,23,Color.FromArgb(67,92,102));}else{m.Box(-76,-35,45,150,6,25,Wood3);m.Box(-76,29,45,150,6,25,Wood3);m.Box(-45,-25,46,55,50,22,Iron3);}m.XScale=m.YScale=m.ZScale=1;m.At(0,0,0,0);if(wagon)Horse3(m,x+(float)Math.Cos(angle)*125,y+(float)Math.Sin(angle)*125,angle,Elapsed*10);}
        void Plane3(ThreeDMesh m,float x,float y,float angle,float altitude){if(!Near3(x,y,2200))return;
            m.At(x,y,Ground3(x,y),angle);m.Shadow(0,0,.3f,145,275,Flying?25:65);m.At(x,y,Ground3(x,y)+altitude,angle);m.Pitch=Flying?FlightPitch3:0;Color fabric=Color.FromArgb(233,220,182);
            // Local +X points toward the forward elevator. Twin pusher propellers sit behind the main wings.
            foreach(int side in new[]{-1,1}){m.Box(-115,side*22-3,0,320,6,6,Wood3);m.Limb(-65,side*22,5,60,43,5,5,Wood3);m.Limb(170,side*22,5,180,65,4,4,Wood3);}
            for(int layer=0;layer<2;layer++){float z=42+layer*76;m.Box(-65,-280,z,135,560,3,fabric);for(int rib=-270;rib<=270;rib+=30)m.Box(-65,rib,z+3,135,1.5f,1.5f,Wood3);m.Box(165,-90,65+layer*27,68,180,3,fabric);}
            for(int side=-1;side<=1;side+=2)for(int column=1;column<=3;column++){float y0=side*(column*82);m.Box(-52,y0,45,4,4,74,Wood3);m.Box(57,y0,45,4,4,74,Wood3);m.Limb(-52,y0,46,57,118,1.2f,1.2f,Iron3);m.Limb(57,y0,46,-52,118,1.2f,1.2f,Iron3);}
            foreach(int side in new[]{-1,1}){m.Box(-175,side*12,52,58,3,55,fabric);m.Limb(-155,side*12,52,-55,43,3,3,Wood3);m.Limb(63,side*55,45,177,65,3,3,Wood3);m.Box(-109,side*105-3,44,5,6,45,Wood3);
                float a=Flying?Elapsed*28*side:side*.7f,dy=(float)Math.Cos(a)*59,dz=(float)Math.Sin(a)*59;float yy=side*105,zz=77;
                for(int blade=-1;blade<=1;blade+=2){float y1=yy+blade*dy,z1=zz+blade*dz;m.PropellerBlade(-114,yy,zz,y1,z1,Wood3);}
            }
            m.Box(-24,25,46,42,30,24,Iron3);for(int i=0;i<4;i++)m.Box(-20+i*9,25,70,5,30,5,Dark3);
            if(Flying){m.Box(-34,-42,46,48,20,13,Color.FromArgb(64,112,124));m.Box(14,-41,46,16,18,14,Skin3);m.Box(-59,-42,47,25,8,8,Iron3);m.Box(-59,-30,47,25,8,8,Iron3);}
            m.Pitch=0;m.At(0,0,0,0);
        }
        void FillTerrain3(ThreeDMesh m){m.Reset(TerrainLight3);int step=160,cx=(int)Math.Floor(CameraX/step)*step,cy=(int)Math.Floor(CameraY/step)*step;
            for(int y=cy-2400;y<cy+2400;y+=step)for(int x=cx-2400;x<cx+2400;x+=step){bool ocean=IsFrontier&&Ocean(x+80,y+80,0),river=IsFrontier&&NearRiver(x+80,y+80,0);Color ground=ocean||river?Color.FromArgb(57,110,137):IsFrontier&&SafeTown(x+80,y+80)?Color.FromArgb(183,149,104):IsFrontier?Soil3:Color.FromArgb(167,137,88);V3 a=new V3(x,y,Ground3(x,y)-1),b=new V3(x+step,y,Ground3(x+step,y)-1),c=new V3(x+step,y+step,Ground3(x+step,y+step)-1),d=new V3(x,y+step,Ground3(x,y+step)-1);if(!ocean&&!river&&Math.Max(Math.Max(a.Z,b.Z),Math.Max(c.Z,d.Z))>180)ground=Color.FromArgb(153,139,108);m.Surface(a,b,c,ground);m.Surface(a,c,d,ground);if(IsFrontier)GroundDetail3(m,x,y,ocean||river);
                if(IsFrontier&&SceneryClear3(x+76,y+76)&&Distance(x+76,y+76,MainlandAirfield.X,MainlandAirfield.Y)>650&&Distance(x+76,y+76,IslandAirfield.X,IslandAirfield.Y)>650&&!ocean&&!river&&!SafeTown(x,y)&&RoadDistance(x,y)>210&&!NearRail(x,y)){m.At(0,0,Ground3(x+76,y+76),0);int seed=Math.Abs((x*73+y*137)%97);if(seed%7==0&&RailDistance3(x+76,y+76)>210&&RoadDistance(x+76,y+76)>220){Tree3(m,x+76,y+76,seed);m.At(0,0,Ground3(x+76,y+76),0);}else if(seed%13==0){m.Box(x+40,y+45,0,61,49,29,Color.FromArgb(125,122,102));m.Box(x+50,y+52,29,40,35,13,Color.FromArgb(143,139,119));}else if(seed%3==0){m.Cone(x+60,y+50,0,7,19,Color.FromArgb(156,173,98));}}
            }
            m.At(0,0,0,0);if(IsFrontier){foreach(PointF[] road in new[]{MountainRoad,WestSpur,EastSpur})for(int i=1;i<road.Length;i++)m.Strip(road[i-1],road[i],220,0,Color.FromArgb(182,159,112));m.Box(5570,4110,0,870,380,9,Wood3);for(int i=1;i<Railway.Length;i++){PointF a=Railway[i-1],b=Railway[i];float angle=(float)Math.Atan2(b.Y-a.Y,b.X-a.X),nx=-(float)Math.Sin(angle)*65,ny=(float)Math.Cos(angle)*65;m.Strip(a,b,162,1,Color.FromArgb(111,103,87));foreach(int side in new[]{-1,1})m.Strip(new PointF(a.X+nx*side,a.Y+ny*side),new PointF(b.X+nx*side,b.Y+ny*side),5,7,Color.FromArgb(147,161,165));}float railLength=PathLength(Railway);for(float d=0;d<railLength;d+=45){PointF p=Along(Railway,d),next=Along(Railway,d+1);if(!Near3(p.X,p.Y,2200))continue;m.At(p.X,p.Y,0,(float)Math.Atan2(next.Y-p.Y,next.X-p.X));m.Box(-5,-80,2,10,160,3,Wood3);}m.At(0,0,0,0);}
        }
        public void Build3D(ThreeDMesh m){m.Reset(IsFrontier?1-NightStrength*.18f-RainStrength3*.08f:1);
            if(Level==3){m.Strip(new PointF(885,CameraY-2300),new PointF(885,CameraY+2300),6,1,Iron3);m.Strip(new PointF(1015,CameraY-2300),new PointF(1015,CameraY+2300),6,1,Iron3);float scroll=(Elapsed*620)%320;for(int y=-1600;y<3200;y+=320){m.Box(870,y+scroll,0,160,12,2,Wood3);foreach(int side in new[]{-1,1}){float tx=950+side*(300+(y+1600)%400);Tree3(m,tx,y+scroll,y);}}}
            foreach(Building b in Buildings)House3(m,b);
            if(IsFrontier){foreach(RectangleF w in securityWalls){if(!Near3(w.X,w.Y,2200))continue;if(EscapeHole&&w.X==3200&&w.Width==20){m.Box(w.X,w.Y,0,20,140,80,Iron3);m.Box(w.X,4710,0,20,290,80,Iron3);continue;}bool bars=w.Height==14||w.Width==15;if(bars){for(float x=w.X;x<w.Right;x+=20)m.Box(x,w.Y,0,3,w.Height,85,Iron3);}else m.Box(w.X,w.Y,0,w.Width,w.Height,w.Width>200&&w.Height>30?40:85,Color.FromArgb(146,137,115));}
                if(!ExecutionGateOpen)for(int x=3460;x<=3560;x+=20)m.Box(x,4720,0,4,14,85,Iron3);
                m.Box(2250,4400,-.5f,700,500,1,Color.FromArgb(177,159,120));m.Box(3200,4500,-.5f,720,500,1,Color.FromArgb(146,143,119));m.Box(2685,4450,0,85,65,75,Iron3);for(int i=0;i<3;i++)m.Box(3240+i*200,4570,0,65,100,20,Wood3);
                m.Box(4050,4660,0,220,140,28,Wood3);m.Box(4060,4690,28,12,12,155,Wood3);m.Box(4240,4690,28,12,12,155,Wood3);m.Box(4060,4690,175,192,12,12,Wood3);m.Box(4160,4695,100,3,3,75,Color.Beige);
                if(!PrisonPaid&&ExecutionPhase!=3)Person3(m,new Body{X=PrisonerPosition.X,Y=PrisonerPosition.Y,Angle=1.5f},Color.FromArgb(143,140,106),false,false);if(ExecutionPhase==3)m.Box(4148,4690,60,24,18,45,Color.FromArgb(143,140,106));
                foreach(Body b in Residents)if(b.HP>0)Person3(m,b,Color.FromArgb(139,151,110),b.Rider,false);foreach(Body b in ExecutionCrowd)Person3(m,b,Color.FromArgb(139,151,110),false,false);
                for(int i=0;i<2;i++){PointF p=Plots[i];if(HouseStage[i]==3)House3(m,new Building(p.X-100,p.Y-140,200,140,"home",""));else if(HouseStage[i]>0){m.Box(p.X-100,p.Y-140,0,200,140,8,Wood3);if(HouseStage[i]==2){m.Box(p.X-100,p.Y-140,8,200,8,80,Wood3);m.Box(p.X-100,p.Y-140,8,8,140,80,Wood3);}}}
                for(int i=0;i<3;i++){PointF p=LoopRailPoint(i*TrainSpacing3);Vehicle3(m,p.X,p.Y,RailHeading3(i*TrainSpacing3),i==0,false);}
                if(WagonActive){PointF p=WagonPosition,next=Along(WagonRoute,WagonProgress+10);Vehicle3(m,p.X,p.Y,(float)Math.Atan2(next.Y-p.Y,next.X-p.X),false,true);}
                if(Flying)Plane3(m,Player.X,Player.Y,FlightHeading3,FlightAltitude3);else{Plane3(m,MainlandAirfield.X,MainlandAirfield.Y+70,(float)Math.Atan2(1700,11100),0);Plane3(m,IslandAirfield.X,IslandAirfield.Y+70,(float)Math.Atan2(1700,11100)+(float)Math.PI,0);}
                foreach(WorldService s in Services)if(Near3(s.X,s.Y,1600))m.Box(s.X-9,s.Y-9,0,18,18,3,Color.FromArgb(206,192,113));
            }else if(Level>=2){for(int car=0;car<3;car++)if(Level==3||TrainActive)Vehicle3(m,950,Level==3?480+car*290:TrainY-car*290,(float)Math.PI/2,car==0,false);if(Level==3){m.Box(Player.X-80,Player.Y-145,TrainDeck3-10,160,290,10,Wood3);m.At(Player.X,Player.Y,TrainDeck3,Player.Angle);m.Box(-7,-7,0,14,14,38,Iron3);m.Box(-10,-8,35,80,16,12,Iron3);m.At(0,0,0,0);foreach(int side in new[]{-1,1}){PointF p=AllyPosition(side);Person3(m,new Body{X=p.X,Y=p.Y,Angle=Player.Angle},Color.FromArgb(104,119,102),false,true,TrainDeck3);}}}
            if(!Mounted&&HorseHP>0&&!(IsFrontier&&(Aboard||Flying)))Horse3(m,Horse.X,Horse.Y,0,0);foreach(Body b in Enemies)if(b.HP>0)Person3(m,b,b.Police?Color.FromArgb(63,97,134):b.Elite?Color.FromArgb(94,46,46):Color.FromArgb(151,78,53),Level==3,true);
            if(!(IsFrontier&&(Flying||Aboard)))Person3(m,Player,Color.FromArgb(64,112,124),Mounted,true,Level==3?TrainDeck3:0);
            if(IsFrontier&&EventKind>0&&Near3(EventPosition.X,EventPosition.Y,1600)){m.At(EventPosition.X,EventPosition.Y,Ground3(EventPosition.X,EventPosition.Y),0);m.Cone(0,0,20,15,35,Color.Gold);m.At(0,0,0,0);}if(!IsFrontier&&Chapter=="ride"&&Checkpoint<route.Length){PointF p=route[Checkpoint];m.Cone(p.X,p.Y,0,30,55,Color.YellowGreen);}
            foreach(Bullet b in Bullets)if(Near3(b.X,b.Y,1800)){float old=m.Light;m.Light=1;m.Box(b.X-2,b.Y-2,Ground3(b.X,b.Y)+(Level==3&&b.Friendly?22+Math.Max(0,1-Distance(b.X,b.Y,Player.X,Player.Y)/800)*(TrainDeck3+38):Mounted?43:22),4,4,4,b.Friendly?Color.LightGoldenrodYellow:Color.OrangeRed);m.Light=old;}foreach(Pickup p in drops)if(Near3(p.X,p.Y,1600))m.Box(p.X-8,p.Y-8,0,16,16,12,Color.Goldenrod);Rain3(m);
        }
    }
}















