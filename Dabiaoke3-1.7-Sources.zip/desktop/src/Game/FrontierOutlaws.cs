using System;
using System.Collections.Generic;
using System.Drawing;
using System.Xml;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        public readonly PointF BankDoor=new PointF(2600,4970),Vault=new PointF(2730,4500),CellDoor=new PointF(3510,4800),PrisonExit=new PointF(4060,5340);
        public readonly PointF[] WagonRoute={new PointF(2780,5160),new PointF(4300,5300),new PointF(4400,4200),new PointF(4950,3700),new PointF(5600,4300),new PointF(6400,4300),new PointF(7150,3000),new PointF(8200,2600),new PointF(9000,3200),new PointF(9300,4200),new PointF(10500,4200)};
        readonly List<RectangleF> securityWalls=new List<RectangleF>();
        public bool BankGuardDown,PrisonGuardOneDown,PrisonGuardTwoDown,BankLooted,PrisonerFree,PrisonPaid,WagonActive,WagonLooted;
        public float BankCooldown,PrisonCooldown,BankOpening,WagonClock,WagonProgress,WagonHP=300,WagonOpening,RaidTheft;
        public PointF PrisonerPosition=new PointF(3510,4640);
        public PointF WagonPosition { get { return Along(WagonRoute,WagonProgress); } }
        public float RiverCenter(float y) { float offset=y-4300,blend=1-(float)Math.Exp(-offset*offset/200000);return 6000+blend*(380*(float)Math.Sin(y/710)+170*(float)Math.Sin(y/270)); }
        public float RiverWidth(float y) { return 165+25*(float)Math.Sin(y/450)+15*(float)Math.Cos(y/190); }
        public bool NearRiver(float x,float y,float margin) { return Math.Abs(x-RiverCenter(y))<RiverWidth(y)+margin; }
        void ConfigureOutlaws() {
            securityWalls.Clear();
            // Roofless playable interiors; these rectangles are shared by movement and bullet collision.
            securityWalls.AddRange(new[]{new RectangleF(2250,4400,700,20),new RectangleF(2250,4400,20,500),new RectangleF(2930,4400,20,500),new RectangleF(2250,4880,280,20),new RectangleF(2670,4880,280,20),new RectangleF(2290,4660,160,65),new RectangleF(2720,4660,170,65),new RectangleF(2300,4440,180,75),new RectangleF(2780,4440,120,75),new RectangleF(3200,4500,720,20),new RectangleF(3200,4500,20,500),new RectangleF(3900,4500,20,500),new RectangleF(3200,4980,270,20),new RectangleF(3620,4980,300,20),new RectangleF(3240,4720,220,14),new RectangleF(3560,4720,320,14),new RectangleF(3310,4550,15,170),new RectangleF(3720,4550,15,170),new RectangleF(3260,4840,130,65)});
            Buildings.Add(new Building(1720,4680,270,150,"saloon","STONEBRIDGE"));
            Buildings.Add(new Building(1860,5250,230,140,"store","GUNSMITH"));
            Services.Add(new WorldService("石桥镇酒馆","saloon",1850,4940,4));
            Services.Add(new WorldService("石桥镇枪械铺","gun",1980,5480,4));
            Services.Add(new WorldService("银行入口","bankdoor",BankDoor.X,BankDoor.Y,0));
            Services.Add(new WorldService("银行金库","vault",Vault.X,Vault.Y,0));
            Services.Add(new WorldService("监狱牢门","prison",CellDoor.X,CellDoor.Y,0));
            Services.Add(new WorldService("劫狱接应点","escape",PrisonExit.X,PrisonExit.Y,0));
            WorldService fish=Services.Find(s=>s.Kind=="fish"&&s.Index==0);if(fish!=null)fish.X=RiverCenter(fish.Y)-RiverWidth(fish.Y)-140;
            for(int i=0;i<8;i++)Residents.Add(new Body { ResidentId=48+i,X=2200+i*170,Y=5200,HP=100,Speed=20 });
            for(int i=0;i<8;i++) { float d=PathLength(MountainRoad)*(i+.25f)/8;PointF p=Along(MountainRoad,d);Residents.Add(new Body { ResidentId=56+i,X=p.X,Y=p.Y,HP=100,MaxHP=100,Speed=110,Hiker=true,Rider=true,RouteProgress=d }); }
        }
        public bool SecurityBlocked(float x,float y,float radius) {
            foreach(RectangleF wall in securityWalls)if(x>wall.X-radius&&x<wall.Right+radius&&y>wall.Y-radius&&y<wall.Bottom+radius) { if(EscapeHole&&wall.X==3200&&wall.Width==20&&y>4640+radius&&y<4710-radius)continue;return true; }
            return !ExecutionGateOpen&&x>3460-radius&&x<3560+radius&&y>4720-radius&&y<4734+radius;
        }
        void ResetOutlaws() { BankGuardDown=PrisonGuardOneDown=PrisonGuardTwoDown=BankLooted=PrisonerFree=PrisonPaid=WagonActive=WagonLooted=false;BankCooldown=PrisonCooldown=BankOpening=WagonClock=WagonProgress=WagonOpening=RaidTheft=0;WagonHP=300;PrisonerPosition=new PointF(3510,4640); }
        void SpawnSecurity(int id) {
            PointF p=id==1?new PointF(2590,4740):id==2?new PointF(3510,4860):id==3?new PointF(3790,4800):WagonPosition;
            Enemies.Add(new Body { X=p.X,Y=p.Y,HP=200,MaxHP=200,Police=true,Guard=id,Camp=-1,Speed=id==4?200:115,Shoot=.6f });
        }
        void SecurityDefeated(Body e) { if(e.Guard==1)BankGuardDown=true;if(e.Guard==2)PrisonGuardOneDown=true;if(e.Guard==3)PrisonGuardTwoDown=true;if(e.Guard==4)WagonHP=0; }
        bool OutlawInteraction(WorldService s) {
            if(s==null)return false;
            if(s.Kind=="bankdoor") { Announce("从敞开的正门走进银行 · 消灭保安后到金库按 Q");return true; }
            if(s.Kind=="vault") {
                if(BankLooted) { Announce("金库已空 · 补货剩余 "+(int)BankCooldown+" 秒");return true; }
                if(!BankGuardDown) { if(Wanted==0)RaiseWanted();Announce("保安仍在值守 · 必须先击败银行保安");return true; }
                if(BankOpening==0) { BankOpening=6;RaiseWanted();RaiseWanted();SaveFrontier(false);Announce("正在打开金库 · 留在附近6秒 · 受伤会中断"); }return true;
            }
            if(s.Kind=="prison") {
                if(ExecutionPhase!=0) { Announce(ExecutionPhase==4?"新囚犯正押入牢房":"囚犯已离开牢房 · 到押送队或绞刑台旁按 Q 截救");return true; }
                if(PrisonPaid) { Announce("囚犯已获救 · 本轮劫狱完成");return true; }
                if(!PrisonGuardOneDown||!PrisonGuardTwoDown) { if(Wanted==0)RaiseWanted();Announce("先击败两名狱警，才能取钥匙打开牢门");return true; }
                if(!PrisonerFree) { PrisonerFree=true;RaiseWanted();RaiseWanted();SaveFrontier(false);Announce("牢门已打开 · 护送囚犯到东南接应点，报酬 $180"); }return true;
            }
            if(s.Kind=="escape") { Announce(PrisonerFree&&!PrisonPaid?"把囚犯带到这个接应点，即可领取 $180":"劫狱接应点 · 先前往监狱救人");return true; }
            return false;
        }
        public void DispatchWagon() {
            Enemies.RemoveAll(e=>e.Guard==4);WagonActive=true;WagonLooted=false;WagonProgress=WagonOpening=0;WagonHP=300;SpawnSecurity(4);
            if(!OnIsland)Announce("石桥银行运钞马车出发 · M 查看金色方块");
        }
        public bool RobWagon() {
            if(!WagonActive||Distance(Player.X,Player.Y,WagonPosition.X,WagonPosition.Y)>240)return false;
            if(WagonLooted) { Announce("马车钱箱已被取走");return true; }
            bool guard=Enemies.Exists(e=>e.Guard==4&&e.HP>0);
            if(guard) { if(Wanted==0)RaiseWanted();Announce("先击败押运员，再按 X 打开钱箱");return true; }
            if(WagonOpening==0) { WagonOpening=4;WagonHP=0;RaiseWanted();SaveFrontier(false);Announce("打开马车钱箱 · 留在附近4秒"); }return true;
        }
        bool RaidOrders(Body body,float dt) {
            if(body.Guard==5||body.Guard==6)return ExecutionGuardOrders(body,dt);
            if(body.Guard>0&&Wanted==0) {
                if(body.Guard==4&&WagonActive) { PointF p=WagonPosition;body.X=p.X;body.Y=p.Y-55; }return true;
            }
            if(body.Raid==0)return false;
            if(Distance(body.X,body.Y,Player.X,Player.Y)<500&&Wanted>0)return false;
            PointF goal=body.Raid==1?(BankGuardDown?(body.Y>4840?new PointF(2600,4780):Vault):BankDoor):WagonPosition;
            if(Distance(body.X,body.Y,goal.X,goal.Y)>(body.Raid==1?35:140)) { body.Angle=Angle(body.X,body.Y,goal.X,goal.Y);Move(body,(float)Math.Cos(body.Angle)*body.Speed*dt,(float)Math.Sin(body.Angle)*body.Speed*dt);body.Step+=dt*8; }
            return true;
        }
        public bool SpawnHeistEvent(int kind) {
            if(kind==5&&!WagonActive)return false;
            PointF goal=kind==4?BankDoor:WagonPosition;
            if(Distance(Player.X,Player.Y,goal.X,goal.Y)>1600||kind==4&&BankLooted||kind==5&&WagonLooted)return false;
            EventKind=kind;EventPosition=goal;EventLife=120;RaidTheft=0;
            for(int i=0;i<5;i++) { float x=goal.X-300+i*110,y=goal.Y+250;if(!Blocked(x,y,16))Enemies.Add(new Body { X=x,Y=y,HP=180,MaxHP=180,Speed=155,Shoot=.6f,Camp=-2,Raid=kind==4?1:2 }); }
            Announce(kind==4?"帮派正在抢劫石桥银行 · 击退劫匪可获 $80":"帮派正在截击运钞马车 · 击退劫匪可获 $80");return true;
        }
        void UpdateOutlaws(float dt) {
            UpdatePrisonDrama(dt);
            BankCooldown=Math.Max(0,BankCooldown-dt);PrisonCooldown=Math.Max(0,PrisonCooldown-dt);
            WagonClock+=dt;if(WagonClock>=120) { WagonClock-=120;DispatchWagon(); }
            if(WagonActive) {
                if(WagonHP>0&&WagonOpening==0)WagonProgress+=180*dt;
                if(WagonProgress>=PathLength(WagonRoute)) { WagonActive=false;Enemies.RemoveAll(e=>e.Guard==4); }
            }
            if(BankLooted&&BankCooldown==0&&Distance(Player.X,Player.Y,BankDoor.X,BankDoor.Y)>1000) { BankLooted=BankGuardDown=false;Enemies.RemoveAll(e=>e.Guard==1);SpawnSecurity(1); }
            if(PrisonPaid&&PrisonCooldown==0&&Distance(Player.X,Player.Y,CellDoor.X,CellDoor.Y)>1000) { PrisonPaid=PrisonerFree=PrisonGuardOneDown=PrisonGuardTwoDown=false;SentenceClock=0;PrisonerGeneration++;PrisonerPosition=new PointF(3510,4640);Enemies.RemoveAll(e=>e.Guard==2||e.Guard==3);SpawnSecurity(2);SpawnSecurity(3); }
            if(BankOpening>0) { if(Distance(Player.X,Player.Y,Vault.X,Vault.Y)>160) { BankOpening=0;Announce("离开金库，开锁中断"); }else { BankOpening=Math.Max(0,BankOpening-dt);if(BankOpening==0) { Money+=250;BankLooted=true;BankCooldown=240;SaveFrontier(false);Announce("银行抢劫成功 · 获得 $250"); } } }
            if(WagonOpening>0) { if(!WagonActive||Distance(Player.X,Player.Y,WagonPosition.X,WagonPosition.Y)>250) { WagonOpening=0;Announce("离开马车，开锁中断"); }else { WagonOpening=Math.Max(0,WagonOpening-dt);if(WagonOpening==0) { WagonLooted=true;Money+=120;SaveFrontier(false);Announce("抢得马车钱箱 · 获得 $120"); } } }
            if(PrisonerFree&&!PrisonPaid) {
                // Walk through the cell opening and front door before following outside.
                PointF goal=PrisonerPosition.X<3920&&PrisonerPosition.Y<4800?new PointF(3510,4840):PrisonerPosition.X<3920&&PrisonerPosition.Y<5050?new PointF(3550,5100):new PointF(Player.X,Player.Y);
                float d=Distance(PrisonerPosition.X,PrisonerPosition.Y,goal.X,goal.Y);
                if(d>(PrisonerPosition.Y<5050?5:55)&&Distance(Player.X,Player.Y,PrisonerPosition.X,PrisonerPosition.Y)<850) { Body actor=new Body { X=PrisonerPosition.X,Y=PrisonerPosition.Y };float step=Math.Min(d,210*dt);Move(actor,(goal.X-actor.X)/d*step,(goal.Y-actor.Y)/d*step);PrisonerPosition=new PointF(actor.X,actor.Y); }
                if(Distance(PrisonerPosition.X,PrisonerPosition.Y,PrisonExit.X,PrisonExit.Y)<200&&Distance(Player.X,Player.Y,PrisonExit.X,PrisonExit.Y)<180) { PrisonPaid=true;PrisonCooldown=300;Money+=180;SaveFrontier(false);Announce("囚犯已交给接应人 · 劫狱报酬 $180"); }
            }
            if(EventKind==4||EventKind==5) {
                PointF target=EventKind==4?BankDoor:WagonPosition;EventPosition=target;
                bool robbers=Enemies.Exists(e=>e.Raid==(EventKind==4?1:2)&&e.HP>0),guard=EventKind==4?!BankGuardDown:Enemies.Exists(e=>e.Guard==4&&e.HP>0);
                if(!robbers) { Money+=80;EndEvent("帮派劫案已阻止 · 获得 $80");SaveFrontier(false); }
                else if(!guard&&Enemies.Exists(e=>e.Raid==(EventKind==4?1:2)&&e.HP>0&&Distance(e.X,e.Y,EventKind==4?Vault.X:target.X,EventKind==4?Vault.Y:target.Y)<180)) { RaidTheft=Math.Min(12,RaidTheft+dt);if(RaidTheft>=12) { int raid=EventKind==4?1:2;if(EventKind==4) { BankLooted=true;BankCooldown=240; }else WagonLooted=true;foreach(Body e in Enemies)if(e.Raid==raid)e.Raid=0;EventKind=0;EventLife=0;EventClock=Rand(120,180);Announce("劫匪带走了钱箱 · 本次拦截失败");SaveFrontier(false); } }
            }
        }
        void SaveOutlaws(Action<string,string> put) {
            put("bankDown",BankGuardDown.ToString());put("prison1",PrisonGuardOneDown.ToString());put("prison2",PrisonGuardTwoDown.ToString());put("bankLoot",BankLooted.ToString());put("prisonFree",PrisonerFree.ToString());put("prisonPaid",PrisonPaid.ToString());put("wagonActive",WagonActive.ToString());put("wagonLoot",WagonLooted.ToString());
            put("bankCool",Num(BankCooldown));put("prisonCool",Num(PrisonCooldown));put("bankOpen",Num(BankOpening));put("wagonClock",Num(WagonClock));put("wagonProgress",Num(WagonProgress));put("wagonHP",Num(WagonHP));put("wagonOpen",Num(WagonOpening));put("prisonX",Num(PrisonerPosition.X));put("prisonY",Num(PrisonerPosition.Y));put("raidTheft",Num(RaidTheft));
        }
        float[] ReadOutlaws(XmlElement e) {
            if(e.GetAttribute("version")!="4"&&e.GetAttribute("version")!="5"&&e.GetAttribute("version")!="6")return null;
            return new[]{Flag(e,"bankDown")?1f:0,Flag(e,"prison1")?1f:0,Flag(e,"prison2")?1f:0,Flag(e,"bankLoot")?1f:0,Flag(e,"prisonFree")?1f:0,Flag(e,"prisonPaid")?1f:0,Flag(e,"wagonActive")?1f:0,Flag(e,"wagonLoot")?1f:0,Value(e,"bankCool",0,240),Value(e,"prisonCool",0,300),Value(e,"bankOpen",0,6),Value(e,"wagonClock",0,120),Value(e,"wagonProgress",0,PathLength(WagonRoute)+10),Value(e,"wagonHP",0,300),Value(e,"wagonOpen",0,4),Value(e,"prisonX",55,25945),Value(e,"prisonY",55,5945),Value(e,"raidTheft",0,12)};
        }
        void LoadOutlaws(float[] a) {
            if(a==null) { SpawnSecurity(1);SpawnSecurity(2);SpawnSecurity(3);return; }
            BankGuardDown=a[0]>0;PrisonGuardOneDown=a[1]>0;PrisonGuardTwoDown=a[2]>0;BankLooted=a[3]>0;PrisonerFree=a[4]>0;PrisonPaid=a[5]>0;WagonActive=a[6]>0;WagonLooted=a[7]>0;BankCooldown=a[8];PrisonCooldown=a[9];BankOpening=a[10];WagonClock=a[11];WagonProgress=a[12];WagonHP=a[13];WagonOpening=a[14];PrisonerPosition=new PointF(a[15],a[16]);RaidTheft=a[17];
        }
    }
}
