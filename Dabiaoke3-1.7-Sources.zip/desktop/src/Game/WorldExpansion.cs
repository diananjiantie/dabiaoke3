using System;
using System.Drawing;
using System.Collections.Generic;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        public readonly PointF[] MountainRoad={new PointF(1500,2800),new PointF(2450,2800),new PointF(2800,1800),new PointF(3900,1200),new PointF(4800,2000),new PointF(4950,3700),new PointF(5600,4300),new PointF(6400,4300),new PointF(7150,3000),new PointF(8200,2600),new PointF(9000,3200),new PointF(9300,4200),new PointF(10500,4200)};
        public readonly PointF[] WestSpur={new PointF(4950,3700),new PointF(4400,4200),new PointF(3200,4100)};
        public readonly PointF[] EastSpur={new PointF(8200,2600),new PointF(8900,2100),new PointF(9100,1700)};
        public readonly PointF[] Railway={new PointF(1500,3300),new PointF(2600,3300),new PointF(3900,3700),new PointF(5200,3800),new PointF(6400,3500),new PointF(8000,3700),new PointF(9400,4700),new PointF(10500,4700),new PointF(10000,5500),new PointF(6500,5500),new PointF(5500,5000),new PointF(4500,5600),new PointF(2800,5650),new PointF(1400,5500),new PointF(700,4300),new PointF(1500,3300)};
        public const float TrainSpeed=950,StationWait=8;
        public int Wanted;
        public float EscapeClock,PoliceClock,MealTime;
        public bool ShotgunOwned;
        public float TripSeconds { get { return StationDistance(1)/TrainSpeed; } }
        public float RailCycle { get { return PathLength(Railway)/TrainSpeed+3*StationWait; } }
        public PointF RailPosition { get { return RailPoint(0); } }
        public PointF RailPoint(float behind) {
            return LoopRailPoint(behind);
        }
        public static float PathLength(PointF[] path) { float length=0;for(int i=1;i<path.Length;i++)length+=Distance(path[i-1].X,path[i-1].Y,path[i].X,path[i].Y);return length; }
        public static PointF Along(PointF[] path,float distance) {
            for(int i=1;i<path.Length;i++) { float length=Distance(path[i-1].X,path[i-1].Y,path[i].X,path[i].Y);if(distance<=length) { float f=Math.Max(0,distance)/length;return new PointF(path[i-1].X+(path[i].X-path[i-1].X)*f,path[i-1].Y+(path[i].Y-path[i-1].Y)*f); }distance-=length; }return path[path.Length-1];
        }
        static float SegmentDistance(PointF a,PointF b,float x,float y) { float dx=b.X-a.X,dy=b.Y-a.Y,t=Clamp(((x-a.X)*dx+(y-a.Y)*dy)/(dx*dx+dy*dy),0,1);return Distance(x,y,a.X+t*dx,a.Y+t*dy); }
        public float RoadDistance(float x,float y) { float d=float.MaxValue;foreach(PointF[] road in new[]{MountainRoad,WestSpur,EastSpur})for(int i=1;i<road.Length;i++)d=Math.Min(d,SegmentDistance(road[i-1],road[i],x,y));return d; }
        public bool MountainBlocked(float x,float y,float r) {
            if(x>1650&&x<4350&&y>4300&&y<5650)return false;
            if(!((x>2600-r&&x<5300+r||x>6750-r&&x<9500+r)&&y>350-r&&y<5650+r))return false;
            if(RoadDistance(x,y)<185-r)return false;
            foreach(PointF c in Camps)if(Distance(x,y,c.X,c.Y)<540-r)return false;
            foreach(PointF p in Plots)if(Distance(x,y,p.X,p.Y)<280-r)return false;
            return true;
        }
        void AddHikers() {
            for(int i=0;i<22;i++) { float progress=PathLength(MountainRoad)*(i+.5f)/22;PointF p=Along(MountainRoad,progress);Residents.Add(new Body { X=p.X,Y=p.Y,HP=100,MaxHP=100,Speed=35,Hiker=true,RouteProgress=progress,ResidentId=14+i }); }
        }
        public void HurtResident(Body npc,float damage) {
            if(npc.HP<=0)return;npc.HP=Math.Max(0,npc.HP-damage);npc.Hit=.2f;
            if(npc.HP<=0) { RaiseWanted();corpses.Add(new Corpse { X=npc.X,Y=npc.Y }); }
        }
        void RaiseWanted() { if(PoliceRespawn[LocalDistrict]>0) { Wanted=0;return; }Wanted=Math.Min(5,Wanted+1);EscapeClock=0;PoliceClock=0;Announce("通缉 "+Wanted+" 星 · 警察正在追捕 · 脱离视线后躲藏"); }
        void UpdateLaw(float dt) {
            UpdateRegionalLaw(dt);
        }
        public void AlternateService() {
            if(Captured)return;
            WorldService s=NearbyService();if(s==null||Flying||Aboard||MealTime>0||InDanger())return;
            if(s.Kind=="station") { BoardLoopTrain(s,true);return; }
            if(s.Kind=="gun") { if(GunUpgrade>=3) { Announce("枪械已升满");return; }if(!Pay(200+GunUpgrade*150))return;GunUpgrade++;Play("reload");SaveFrontier();Announce("升级完成 · 伤害 +"+GunUpgrade*25+"%"); }
            else if(s.Kind=="saloon") { if(!Pay(30))return;RestoreFrontier();SaveFrontier();Announce("住宿完毕 · 亚瑟和马匹状态已恢复"); }
        }
        void RescuePosition(Body b) {
            if(b==Player&&!PlayerTerrainBlocked(b.X,b.Y,b.R))return;
            if(!Blocked(b.X,b.Y,b.R))return;
            if(b.X>18000) { b.X=22000;b.Y=3130;return; }
            float best=float.MaxValue;PointF safe=new PointF(1500,2800);
            foreach(PointF[] path in new[]{MountainRoad,WestSpur,EastSpur})for(float d=0;d<PathLength(path);d+=80) { PointF p=Along(path,d);float distance=Distance(b.X,b.Y,p.X,p.Y);if(distance<best&&!Blocked(p.X,p.Y,b.R)) { best=distance;safe=p; } }
            b.X=safe.X;b.Y=safe.Y;
        }
        PointF ChasePoint(Body body) {
            PointF goal=new PointF(Player.X,Player.Y);
            if(!body.Police||ClearShot(body.X,body.Y,Player.X,Player.Y)) { body.Navigation.Clear();return goal; }
            if(Elapsed>=body.NextNavigation) {
                body.NextNavigation=Elapsed+2;body.Navigation.Clear();
                const int cell=100,cols=120;int start=(int)(body.Y/cell)*cols+(int)(body.X/cell);
                Queue<int> open=new Queue<int>();Dictionary<int,int> parent=new Dictionary<int,int>();open.Enqueue(start);parent[start]=-1;int found=-1;
                while(open.Count>0&&parent.Count<2200) {
                    int key=open.Dequeue(),xx=key%cols,yy=key/cols;float x=xx*cell+50,y=yy*cell+50;
                    if(Distance(x,y,Player.X,Player.Y)<160&&ClearShot(x,y,Player.X,Player.Y)) { found=key;break; }
                    foreach(Point offset in new[]{new Point(1,0),new Point(-1,0),new Point(0,1),new Point(0,-1)}) {
                        int nx=xx+offset.X,ny=yy+offset.Y,next=ny*cols+nx;
                        if(nx<1||nx>=119||ny<1||ny>=59||parent.ContainsKey(next))continue;
                        float tx=nx*cell+50,ty=ny*cell+50;
                        if(Blocked(tx,ty,body.R)||Blocked((x+tx)/2,(y+ty)/2,body.R))continue;
                        parent[next]=key;open.Enqueue(next);
                    }
                }
                if(found>=0) { while(found!=start&&found>=0) { body.Navigation.Add(new PointF(found%cols*cell+50,found/cols*cell+50));found=parent[found]; }body.Navigation.Reverse(); }
            }
            while(body.Navigation.Count>0&&Distance(body.X,body.Y,body.Navigation[0].X,body.Navigation[0].Y)<45)body.Navigation.RemoveAt(0);
            return body.Navigation.Count>0?body.Navigation[0]:goal;
        }
    }
}
