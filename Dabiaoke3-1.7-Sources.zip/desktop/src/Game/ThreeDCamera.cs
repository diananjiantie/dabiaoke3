using System;
using System.Drawing;
using System.Drawing.Drawing2D;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        public bool Use3D;
        public float CameraYaw,CameraDistance=245,CameraPitch=.10f;
        public float CameraSin {get{return (float)Math.Sin(CameraPitch);}} public float CameraCos {get{return (float)Math.Cos(CameraPitch);}} public const float CameraFocal=750; public float CameraFocusHeight {get{return (Level==3?TrainDeck3:IsFrontier&&Aboard?TrainDeck3:IsFrontier&&Flying?FlightAltitude3:0)+(Mounted?98:62);}}
        float cacheX3=float.NaN,cacheY3,cacheYaw3,cachePitch3,cacheDistance3,cacheFocus3,range3;
        public float CameraRange3 {get{float focus=CameraFocusHeight;if(cacheX3==CameraX&&cacheY3==CameraY&&cacheYaw3==CameraYaw&&cachePitch3==CameraPitch&&cacheDistance3==CameraDistance&&cacheFocus3==focus)return range3;cacheX3=CameraX;cacheY3=CameraY;cacheYaw3=CameraYaw;cachePitch3=CameraPitch;cacheDistance3=CameraDistance;cacheFocus3=focus;range3=CameraDistance;float sx=-(float)Math.Sin(CameraYaw)*CameraCos,sy=(float)Math.Cos(CameraYaw)*CameraCos,gz=Ground3(CameraX,CameraY)+focus;for(float d=30;d<=CameraDistance;d+=12){float x=CameraX+sx*d,y=CameraY+sy*d,z=gz+CameraSin*d;bool blocked=z<Ground3(x,y)+12;foreach(Building b in Buildings)if(x>b.X-15&&x<b.X+b.W+15&&y>b.Y-15&&y<b.Y+b.H+15&&z<228)blocked=true;if(IsFrontier)foreach(RectangleF wall in securityWalls)if(x>wall.X-10&&x<wall.Right+10&&y>wall.Y-10&&y<wall.Bottom+10&&z<98)blocked=true;if(blocked){range3=Math.Max(24,d-16);break;}}return range3;}}
        public void ResetFollowCamera3(){if(!Use3D)return;ResetMotion3();CameraYaw=(IsFrontier&&Flying?FlightHeading3:Player.Angle)+(float)Math.PI/2;CameraPitch=IsFrontier&&Flying?.17f:.10f;CameraDistance=IsFrontier&&Flying?760:245;CameraX=Player.X+(float)Math.Cos(CameraYaw)*55;CameraY=Player.Y+(float)Math.Sin(CameraYaw)*55;Mouse=new PointF(640,400);cacheX3=float.NaN;}
        float TerrainHeight3(float x,float y){if(!IsFrontier||SafeTown(x,y)||x<2600||x>9500||x>5300&&x<6750)return 0;foreach(PointF p in Plots)if(Distance(x,y,p.X,p.Y)<260)return 0;float road=RoadDistance(x,y);if(road<350)return 0;float rail=RailDistance3(x,y);if(rail<300)return 0;foreach(Building b in Buildings)if(x>b.X-240&&x<b.X+b.W+240&&y>b.Y-240&&y<b.Y+b.H+240)return 0;return Math.Min(1,(road-350)/350)*Math.Min(1,(rail-300)/330)*3.2f*(260+150*(float)Math.Sin(x/410)+110*(float)Math.Cos(y/570));}
        readonly System.Collections.Generic.Dictionary<long,float> terrainGrid3=new System.Collections.Generic.Dictionary<long,float>();
        int terrainLevel3=-1,terrainBuildings3=-1;
        float GridHeight3(float x,float y){if(terrainLevel3!=Level||terrainBuildings3!=Buildings.Count){terrainGrid3.Clear();terrainLevel3=Level;terrainBuildings3=Buildings.Count;}long key=((long)(int)x<<32)|(uint)(int)y;float height;if(!terrainGrid3.TryGetValue(key,out height)){height=TerrainHeight3(x,y);terrainGrid3[key]=height;}return height;}
        public float RailDistance3(float x,float y){float distance=float.MaxValue;for(int i=1;i<Railway.Length;i++)distance=Math.Min(distance,SegmentDistance(Railway[i-1],Railway[i],x,y));return distance;}
        // Match the two rendered triangles exactly; analytic height between vertices can put feet underground.
        public float Ground3(float x,float y){const float step=160;float gx=(float)Math.Floor(x/step)*step,gy=(float)Math.Floor(y/step)*step,u=(x-gx)/step,v=(y-gy)/step;float a=GridHeight3(gx,gy),b=GridHeight3(gx+step,gy),c=GridHeight3(gx+step,gy+step),d=GridHeight3(gx,gy+step);return u>=v?a+(b-a)*u+(c-b)*v:a+(c-d)*u+(d-a)*v;}
        public PointF Project3D(float x,float y,float z){z+=Ground3(x,y)-Ground3(CameraX,CameraY)-CameraFocusHeight;float dx=x-CameraX,dy=y-CameraY,c=(float)Math.Cos(CameraYaw),s=(float)Math.Sin(CameraYaw);float right=dx*c+dy*s,up=(dx*s-dy*c)*CameraSin+z*CameraCos,depth=CameraRange3-((-dx*s+dy*c)*CameraCos+z*CameraSin);depth=Math.Max(15,depth);return new PointF(640+CameraFocal*right/depth,400-CameraFocal*up/depth);}
        public PointF Unproject3D(float x,float y,float z){float rx=(x-640)/CameraFocal,uy=(400-y)/CameraFocal,c=(float)Math.Cos(CameraYaw),s=(float)Math.Sin(CameraYaw),range=CameraRange3,ox=CameraX-s*range*CameraCos,oy=CameraY+c*range*CameraCos,oz=Ground3(CameraX,CameraY)+CameraFocusHeight+range*CameraSin,dx=c*rx+s*(CameraCos+uy*CameraSin),dy=s*rx-c*(CameraCos+uy*CameraSin),dz=uy*CameraCos-CameraSin;float previous=0;bool above=oz>Ground3(ox,oy)+z;for(float t=8;t<=4200;t+=12){float xx=ox+dx*t,yy=oy+dy*t;bool nowAbove=oz+dz*t>Ground3(xx,yy)+z;if(above&&!nowAbove){float lo=previous,hi=t;for(int i=0;i<16;i++){float mid=(lo+hi)/2;if(oz+dz*mid>Ground3(ox+dx*mid,oy+dy*mid)+z)lo=mid;else hi=mid;}return new PointF(ox+dx*hi,oy+dy*hi);}previous=t;above=nowAbove;}return new PointF(ox+dx*4200,oy+dy*4200);}
        public void Render3DOverlay(Graphics graphics){g=graphics;g.SmoothingMode=SmoothingMode.AntiAlias;g.Clear(Color.Transparent);if(DeadEye)RectA(0,0,Width,Height,"#8c250d",32);using(Region sceneLabels=new Region(new Rectangle(0,80,1280,560))){sceneLabels.Exclude(new Rectangle(20,95,295,310));sceneLabels.Exclude(new Rectangle(980,95,280,215));sceneLabels.Exclude(new Rectangle(325,95,620,210));g.SetClip(sceneLabels,CombineMode.Replace);}
            foreach(Body e in Enemies)if(e.HP>0){PointF p=Project3D(e.X,e.Y,90);if(p.X<0||p.X>Width||p.Y<80||p.Y>Height-100)continue;if(IsFrontier)Ellipse(p.X,p.Y,4,4,e.Police?"#78a5e1":"#ed6853");if(e.Elite||e.HP<e.MaxHP){Rect(p.X-22,p.Y+9,44,4,"#38241d");Rect(p.X-22,p.Y+9,44*e.HP/e.MaxHP,4,"#e7754d");}}
            if(IsFrontier){foreach(Body n in Residents)if(n.HP>0){PointF p=Project3D(n.X,n.Y,n.Rider?115:86);if(p.X>0&&p.X<Width&&p.Y>80&&p.Y<Height-100)Ellipse(p.X,p.Y,3,3,"#bfc2be");}foreach(WorldService service in Services)if(Distance(service.X,service.Y,Player.X,Player.Y)<600){PointF p=Project3D(service.X,service.Y,18);PointF actor=Project3D(Player.X,Player.Y,Mounted?90:50);if(Math.Abs(p.X-actor.X)>85||Math.Abs(p.Y-actor.Y)>75)Text(service.Name,p.X,p.Y,12,"#ffe2a1",false,true);}foreach(Body e in EyeMarks)if(e.HP>0){PointF p=Project3D(e.X,e.Y,35);Line(p.X-8,p.Y-8,p.X+8,p.Y+8,"#ffd08a",3);Line(p.X+8,p.Y-8,p.X-8,p.Y+8,"#ffd08a",3);}}
            g.ResetClip();Header();if(IsFrontier)FrontierHUD();else HUD();Text((CameraLocked3?"视角锁定":"自由视角")+" · Ctrl 切换 · 鼠标转视角 · 滚轮调距离 · V 复位 · F6 画质 · F7 光束",Width/2,777,13,"#ead6b3",false,true);
            if(ShowFps){RectA(1050,267,200,28,"#1b2620",225);Text(DisplayFps+" FPS · GPU 3D",1060,272,14,"#d8e6a2");}

            if(NoticeTime>0)Text(Notice,Width/2,270,24,"#ffe1aa",true,true);if(MouseInside&&!Paused)Crosshair();if(Paused&&!WorldMap)EndPanel(true);else if(State=="won"||State=="lost")EndPanel(false);if(WorldMap)DrawFrontierMap();g=null;
        }
    }
}












