namespace ArthurFrontier {
    enum WeaponType {
        Revolver=0, Rifle=1, Shotgun=2
    }
    static class WeaponRules {
        public const int RevolverCapacity=6;
        public const int RifleCapacity=8;
        public const float RifleDamage=100;
        public const int BossRifleHits=10;
        public const float BossHealth=RifleDamage*BossRifleHits;
        public static int Capacity(WeaponType weapon) {
            return weapon==WeaponType.Shotgun?2:weapon==WeaponType.Rifle?RifleCapacity:RevolverCapacity;
        }
        public static float ReloadSeconds(WeaponType weapon) {
            return weapon==WeaponType.Shotgun?1.8f:weapon==WeaponType.Rifle?1.65f:1.3f;
        }
        public static float Damage(WeaponType weapon,bool deadEye) {
            return weapon==WeaponType.Shotgun?22:weapon==WeaponType.Rifle?RifleDamage:deadEye?65:40;
        }
    }
}
