﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using System.Xml;
namespace ArthurFrontier {
    sealed class WorldService {
        public string Name,Kind;
        public float X,Y;
        public int Index;
        public WorldService(string name,string kind,float x,float y,int index) { Name=name;Kind=kind;X=x;Y=y;Index=index; }
    }
    sealed partial class FrontierGame {
        public bool IsFrontier { get { return Level==4; } }
        public readonly List<WorldService> Services=new List<WorldService>();
        public readonly List<Body> Residents=new List<Body>();
        public readonly PointF[] Camps={new PointF(4100,1550),new PointF(8050,2950)};
        public readonly PointF[] Plots={new PointF(3200,4100),new PointF(9100,1700)};
        public readonly int[] HouseStage={0,0};
        public readonly bool[] CampCleared={false,false};
        public bool Contract,WorldMap,Aboard;
        public int GunUpgrade;
        public float RailClock,AutoSaveClock;
        public string SavePath=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"ArthurFrontier","frontier-save.xml");
        public float RailX { get { return RailPosition.X; } }
        public int RailStop { get { return CurrentRailStop(); } }
        int departure=-1;
        public bool SafeTown(float x,float y) { return x>1650&&x<4350&&y>4300&&y<5650||y>1900&&y<3650&&Math.Abs(x-1500)<900||y>3300&&y<5050&&Math.Abs(x-10500)<900||x>9550&&x<11700&&y>350&&y<1550||x>21400&&x<23000&&y>2350&&y<3450; }
        public bool RiverBlocked(float x,float y,float radius) {
            return NearRiver(x,y,radius)&&!(y>4110+radius&&y<4490-radius);
        }
        void ConfigureFrontier() {
            Services.Clear();Residents.Clear();
            for(int i=0;i<2;i++) {
                float x=i==0?1500:10500;string town=i==0?"日落镇":"冷杉镇";
                Buildings.Add(new Building(x-460,2380,260,150,"saloon","SALOON"));
                Buildings.Add(new Building(x+230,2380,240,150,"store","GUNSMITH"));
                Buildings.Add(new Building(x-120,2070,240,140,"sheriff","BOUNTIES"));
                Buildings.Add(new Building(x-160,3060,320,130,"stable","RAIL STATION"));
                Buildings.Add(new Building(x-680,2870,190,160,"stable","STABLE"));
                Services.Add(new WorldService(town+"酒馆","saloon",x-330,2610,i));
                Services.Add(new WorldService(town+"枪械铺","gun",x+350,2610,i));
                Services.Add(new WorldService("赏金告示板","bounty",x,2280,i));
                Services.Add(new WorldService(town+"车站","station",x,3460,i));
                for(int n=0;n<7;n++)Residents.Add(new Body { X=x-400+n*130,Y=2780+(n%2)*100,Angle=1.5f,Speed=22,HP=100,MaxHP=100,ResidentId=i*7+n });
            }
            foreach(Building b in Buildings)if(b.X>9000)b.Y+=1400;
            foreach(WorldService s in Services)if(s.Index==1)s.Y+=1400;
            foreach(Body n in Residents)if(n.X>9000)n.Y+=1400;
            AddHikers();
            ConfigureAdventure();
            ConfigureOutlaws();
            Buildings.Add(new Building(2650,5390,300,130,"stable","STONEBRIDGE STATION"));
            Services.Add(new WorldService("石桥镇车站","station",2800,5810,2));
            for(int i=0;i<2;i++) {
                PointF c=Camps[i];
                Buildings.Add(new Building(c.X-250,c.Y+(i==0?-210:300),150,100,"saloon",i==0?"RED SNAKES":"IRON WOLVES"));
                Buildings.Add(new Building(c.X+180,c.Y-180,90,70,"crate",""));
                Services.Add(new WorldService(i==0?"河畔宅地":"松林宅地","house",Plots[i].X,Plots[i].Y+60,i));
            }
            ConfigureNeighborhoods();
        }
        public void StartFrontier() {
            // An existing save is always resumed; starting from the menu cannot erase it.
            if(File.Exists(SavePath)) { LoadFrontier();return; }
            ResetFrontier();SaveFrontier();Announce("开放世界 · Q 互动 · M 地图 · F5 存档");
        }
        void ResetFrontier() {
            ResetAdventure();
            Start();HouseStage[0]=HouseStage[1]=0;CampCleared[0]=CampCleared[1]=false;
            Contract=false;GunUpgrade=0;WorldMap=false;Aboard=false;departure=-1;RailClock=0;AutoSaveClock=0;
            Wanted=0;EscapeClock=0;PoliceClock=0;MealTime=0;ShotgunOwned=false;ammunition[2]=0;
            LoadMap(4);Chapter="frontier";Enemies.Clear();Bullets.Clear();ActiveBoss=null;SpawnQueue=0;Wave=1;
            Player.X=1500;Player.Y=2800;Horse=new PointF(Player.X,Player.Y);CameraX=Player.X;CameraY=Player.Y;ResetFollowCamera3();
            Money=150;SelectedLevel=4;NoticeTime=0;
            for(int camp=0;camp<2;camp++)SpawnFrontierCamp(camp);
            SpawnSecurity(1);SpawnSecurity(2);SpawnSecurity(3);
        }
        void SpawnFrontierCamp(int camp) {
            CampCleared[camp]=false;
            for(int n=0;n<9;n++) {
                double a=n*Math.PI*2/9;float radius=n==8?0:320;
                Enemies.Add(new Body { X=Camps[camp].X+(float)Math.Cos(a)*radius,Y=Camps[camp].Y+(float)Math.Sin(a)*radius,
                    HP=n==8?500:100,MaxHP=n==8?500:100,Elite=n==8,Speed=n==8?68:76,R=n==8?23:16,Shoot=2+n*.2f,Camp=camp });
            }
        }
        public WorldService NearbyService() {
            WorldService found=null;float best=190;
            foreach(WorldService s in Services) { float d=Distance(Player.X,Player.Y,s.X,s.Y);if(d<best) { found=s;best=d; } }
            return found;
        }
        bool Pay(int price) { if(Money<price) { Announce("赏金不足 · 需要 $"+price);return false; }Money-=price;return true; }
        bool InDanger() { foreach(Body e in Enemies)if(e.HP>0&&(!e.Police||Wanted>0)&&Distance(Player.X,Player.Y,e.X,e.Y)<800)return true;return false; }
        public string ServiceHint(WorldService s) {
            if(s!=null&&s.Kind=="bankdoor")return "穿过正门进入银行 · 金库 Q 抢劫（先击败保安）";
            if(s!=null&&s.Kind=="vault")return BankOpening>0?"开金库中 · "+BankOpening.ToString("0.0")+" 秒":BankLooted?"金库已空":"Q 抢金库 · 需先击败保安 · $250";
            if(s!=null&&s.Kind=="prison")return "Q 开牢门 · 先击败两名狱警 · 护送获 $180";
            if(s!=null&&s.Kind=="escape")return "劫狱接应点 · 护送囚犯抵达领取 $180";
            if(s!=null&&s.Kind=="airport")return s.Index==0?"Q · $60 飞往白鹭岛（含免费返程）":"Q · 免费飞回风蚀镇";
            if(s!=null&&s.Kind=="fish")return "Q · 出售鲜鱼（$15 / 条） · 持有 "+Fish+" 条";
            if(s==null)return "Q 互动 · M 地图 · F5 存档 · F9 读档";
            if(s.Kind=="saloon")return "Q · $20 牛肉套餐 +60 生命（用餐2秒） · T 住宿 $30";
            if(s.Kind=="gun")return (ShotgunOwned?"Q · 装备短管霰弹枪":"Q · $120 购买短管霰弹枪")+(GunUpgrade>=3?" · 已升满":" · T 升级 $"+(200+GunUpgrade*150));
            if(s.Kind=="bounty")return CampCleared[0]&&CampCleared[1]?"Q · 接取新一轮悬赏（重新生成帮派）":Contract?"悬赏进行中 · 每名帮派敌人 $10":"Q · 接取帮派悬赏，每名敌人 $10";
            if(s.Kind=="station")return RailStop==s.Index?"$20车票 · Q 到"+StationName((s.Index+1)%3)+" · T 到"+StationName((s.Index+2)%3):"列车在途中 · 到站后按 Q / T 选择目的地";
            int stage=HouseStage[s.Index];return stage==3?"Q · 回家休息、恢复状态并存档":"Q · $"+new[]{100,200,300}[stage]+" "+new[]{"购买地皮并铺地基","搭建墙体","封顶完成房屋"}[stage];
        }
        public void InteractFrontier() {
            if(Captured)return;
            if(Flying||Aboard||MealTime>0)return;
            if(RescueExecutionPrisoner())return;
            WorldService s=NearbyService();
            if(OutlawInteraction(s))return;
            if(s==null&&AdventureInteraction(null))return;
            if(s==null) { Announce("靠近绿色标记后按 Q · M 查看地图");return; }
            if(InDanger()) { Announce("附近有敌人 · 先脱离战斗");return; }
            if(AdventureInteraction(s))return;
            if(s.Kind=="station") {
                BoardLoopTrain(s,false);return;
            }
            if(s.Kind=="saloon") { if(!Pay(20))return;MealTime=2;MouseHeld=false;SaveFrontier();Announce("牛肉套餐 · 用餐完成后恢复60生命");return; }
            if(s.Kind=="gun") { if(!ShotgunOwned) { if(!Pay(120))return;ShotgunOwned=true;ammunition[2]=2; }SwitchWeapon(WeaponType.Shotgun);SaveFrontier();Announce("短管霰弹枪已装备 · 3 切换 · 两发近距离散射");return; }
            if(s.Kind=="bounty") { Contract=true;if(CampCleared[0]&&CampCleared[1]) { Enemies.RemoveAll(e=>!e.Police);SpawnFrontierCamp(0);SpawnFrontierCamp(1); } }
            if(s.Kind=="house") { int stage=HouseStage[s.Index];if(stage<3) { if(!Pay(new[]{100,200,300}[stage]))return;HouseStage[s.Index]++; }else RestoreFrontier(); }
            SaveFrontier();Announce(s.Kind=="bounty"?"悬赏已接取 · M 查看帮派营地":s.Kind=="gun"?"升级完成 · 枪械伤害 +"+(GunUpgrade*25)+"%":s.Kind=="house"?"房屋阶段 "+HouseStage[s.Index]+" / 3 · 已存档":"休息完毕 · 已存档");
        }
        void RestoreFrontier() { Player.HP=100;HorseHP=200;Horse=new PointF(Player.X+60,Player.Y);ammunition[0]=6;ammunition[1]=8;ammunition[2]=ShotgunOwned?2:0;ReloadTime=0; }
        void UpdateFrontier(float dt) {
            UpdateAdventure(dt);
            RailClock=(RailClock+dt)%RailCycle;
            UpdateLaw(dt);
            if(MealTime>0) { MealTime=Math.Max(0,MealTime-dt);MouseHeld=false;if(MealTime==0) { Player.HP=Math.Min(100,Player.HP+60);SaveFrontier();Announce("套餐吃完了 · 恢复60生命"); } }
            if(Aboard) {
                Player.X=RailPosition.X;Player.Y=RailPosition.Y;Horse=new PointF(Player.X,Player.Y);MouseHeld=false;Invulnerable=1;
                if(RobberyTime<=0&&RailStop>=0&&(railDestination>=0?RailStop==railDestination:RailStop!=departure)) {
                    Aboard=false;Player.X=RailPlatforms[RailStop].X;Player.Y=RailPlatforms[RailStop].Y;railDestination=-1;Horse=new PointF(Player.X+60,Player.Y);SaveFrontier();Announce("列车抵达"+StationName(RailStop)+" · 已自动存档");
                }
            }
            for(int i=0;i<Residents.Count;i++) {
                Body n=Residents[i];if(n.HP<=0||Distance(n.X,n.Y,Player.X,Player.Y)>1400)continue;
                if(n.Hiker) { n.RouteProgress=(n.RouteProgress+n.Speed*dt)%PathLength(MountainRoad);PointF p=Along(MountainRoad,n.RouteProgress);n.Angle=Angle(n.X,n.Y,p.X,p.Y);n.X=p.X;n.Y=p.Y;n.Step+=n.Speed*dt*.065f;n.WalkBlend3=1;continue; }
                float cycle=(Elapsed+i*3.7f)%32,pace=n.Speed*(.85f+(n.ResidentId%5)*.17f);
                float direction=cycle<12?1:cycle<16?0:cycle<28?-1:0;
                float oldX=n.X,oldY=n.Y; if(direction!=0){float heading=(n.ResidentId%3-1)*.42f+(direction<0?(float)Math.PI:0);n.Angle=heading;Move(n,(float)Math.Cos(heading)*pace*dt,(float)Math.Sin(heading)*pace*dt);}
                float moved=Distance(oldX,oldY,n.X,n.Y);n.Step+=moved*.065f;n.WalkBlend3=Math.Min(1,moved/Math.Max(.001f,dt)/40);
            }
            for(int camp=0;camp<2;camp++)if(!CampCleared[camp]) {
                bool alive=false;foreach(Body e in Enemies)if(e.Camp==camp&&e.HP>0)alive=true;
                if(!alive) { CampCleared[camp]=true;SaveFrontier();Announce("帮派营地已清剿 · 每次击杀 $10 已到账"); }
            }
            AutoSaveClock+=dt;if(AutoSaveClock>=45&&!InDanger()) { AutoSaveClock=0;SaveFrontier(false); }
        }
        static string Num(float n) { return n.ToString("R",CultureInfo.InvariantCulture); }
        public bool SaveFrontier() { return SaveFrontier(true); }
        public bool SaveFrontier(bool notify) {
            if(!IsFrontier||Player.HP<=0)return false;
            try {
                Directory.CreateDirectory(Path.GetDirectoryName(SavePath));
                XmlWriterSettings settings=new XmlWriterSettings { Indent=true };
                using(XmlWriter w=XmlWriter.Create(SavePath+".tmp",settings)) {
                    w.WriteStartElement("frontier");w.WriteAttributeString("version","6");
                    Action<string,string> put=(k,v)=>w.WriteAttributeString(k,v);
                    SaveAdventure(put);
                    SaveOutlaws(put);
                    SaveRegionalLaw(put);
                    SavePrisonDrama(put);
                    put("x",Num(Player.X));put("y",Num(Player.Y));put("hp",Num(Player.HP));put("horseHP",Num(HorseHP));put("hx",Num(Horse.X));put("hy",Num(Horse.Y));
                    put("mounted",Mounted.ToString());put("money",Money.ToString());put("kills",Kills.ToString());put("upgrade",GunUpgrade.ToString());put("contract",Contract.ToString());
                    put("h0",HouseStage[0].ToString());put("h1",HouseStage[1].ToString());put("c0",CampCleared[0].ToString());put("c1",CampCleared[1].ToString());
                    put("rail",Num(RailClock));put("aboard",Aboard.ToString());put("departure",departure.ToString());put("elapsed",Num(Elapsed));
                    put("weapon",((int)Weapon).ToString());put("a0",ammunition[0].ToString());put("a1",ammunition[1].ToString());
                    put("shotgun",ShotgunOwned.ToString());put("a2",ammunition[2].ToString());put("wanted",Wanted.ToString());put("escape",Num(EscapeClock));put("meal",Num(MealTime));
                    foreach(Body e in Enemies)if(e.HP>0) { w.WriteStartElement("enemy");put("x",Num(e.X));put("y",Num(e.Y));put("hp",Num(e.HP));put("elite",e.Elite.ToString());put("camp",e.Camp.ToString());put("police",e.Police.ToString());put("guard",e.Guard.ToString());put("raid",e.Raid.ToString());put("maxHP",Num(e.MaxHP));put("district",e.LawDistrict.ToString());w.WriteEndElement(); }
                    foreach(Body n in Residents) { w.WriteStartElement("resident");put("id",n.ResidentId.ToString());put("x",Num(n.X));put("y",Num(n.Y));put("hp",Num(n.HP));put("progress",Num(n.RouteProgress));w.WriteEndElement(); }
                    w.WriteEndElement();
                }
                if(File.Exists(SavePath))File.Replace(SavePath+".tmp",SavePath,SavePath+".bak");else File.Move(SavePath+".tmp",SavePath);
                if(notify)Announce("存档完成 · F9 可读取");return true;
            } catch { if(notify)Announce("存档失败，请检查磁盘空间和目录权限");return false; }
        }
        static float Value(XmlElement e,string key,float lo,float hi) {
            float n;if(!float.TryParse(e.GetAttribute(key),NumberStyles.Float,CultureInfo.InvariantCulture,out n)||float.IsNaN(n)||float.IsInfinity(n)||n<lo||n>hi)throw new InvalidDataException(key);return n;
        }
        static bool Flag(XmlElement e,string key) { return bool.Parse(e.GetAttribute(key)); }
        public bool LoadFrontier() {
            string[] candidates={SavePath,SavePath+".bak"};
            foreach(string file in candidates)try {
                if(!File.Exists(file))continue;
                XmlDocument doc=new XmlDocument();doc.XmlResolver=null;
                using(XmlReader reader=XmlReader.Create(file,new XmlReaderSettings { DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null }))doc.Load(reader);
                XmlElement e=doc.DocumentElement;bool drama=e.GetAttribute("version")=="6",regional=e.GetAttribute("version")=="5"||drama,legacy=e.GetAttribute("version")=="1",outlaw=e.GetAttribute("version")=="4"||regional,adventure=e.GetAttribute("version")=="3"||outlaw;if(e.Name!="frontier"||!legacy&&!adventure&&e.GetAttribute("version")!="2")throw new InvalidDataException();
                float[] adventureState=ReadAdventure(e);
                float[] outlawState=ReadOutlaws(e);
                float[] lawState=ReadRegionalLaw(e);
                float[] dramaState=ReadPrisonDrama(e);
                // Validate everything before replacing the live world.
                float x=Value(e,"x",55,25945),y=Value(e,"y",55,5945),hp=Value(e,"hp",1,100),hhp=Value(e,"horseHP",0,200),hx=Value(e,"hx",0,26000),hy=Value(e,"hy",0,6000);
                int money=(int)Value(e,"money",0,10000000),kills=(int)Value(e,"kills",0,1000000),upgrade=(int)Value(e,"upgrade",0,3),h0=(int)Value(e,"h0",0,3),h1=(int)Value(e,"h1",0,3);
                float rail=Value(e,"rail",0,legacy?84:RailCycle),elapsed=Value(e,"elapsed",0,100000000);int dep=(int)Value(e,"departure",-1,regional?2:1),weapon=(int)Value(e,"weapon",0,legacy?1:2),a0=(int)Value(e,"a0",0,6),a1=(int)Value(e,"a1",0,8);
                bool mounted=Flag(e,"mounted"),contract=Flag(e,"contract"),c0=Flag(e,"c0"),c1=Flag(e,"c1"),aboard=Flag(e,"aboard");
                bool shotgun=!legacy&&Flag(e,"shotgun");int wanted=legacy?0:(int)Value(e,"wanted",0,5),a2=legacy?0:(int)Value(e,"a2",0,2);
                float escape=legacy?0:Value(e,"escape",0,25),meal=legacy?0:Value(e,"meal",0,2);
                if(weapon==2&&!shotgun)throw new InvalidDataException();
                List<Body> enemies=new List<Body>();foreach(XmlElement n in e.SelectNodes("enemy")) {
                    bool elite=Flag(n,"elite"),police=!legacy&&Flag(n,"police");int camp=(int)Value(n,"camp",police?-1:adventure?-2:0,police?-1:1);
                    int guard=outlaw?(int)Value(n,"guard",0,drama?6:4):0,raid=outlaw?(int)Value(n,"raid",0,2):0;
                    enemies.Add(new Body { X=Value(n,"x",50,25950),Y=Value(n,"y",50,5950),HP=Value(n,"hp",1,500),MaxHP=outlaw?Value(n,"maxHP",1,500):police?130:elite?500:100,Elite=elite,Police=police,Guard=guard,Raid=raid,LawDistrict=regional?(int)Value(n,"district",-1,4):-1,Camp=camp,R=elite?23:16,Speed=guard>0?115:raid>0?155:police?285+wanted*15:elite?68:76,Shoot=2 });
                }
                List<Body> residents=new List<Body>();HashSet<int> ids=new HashSet<int>();
                if(!legacy)foreach(XmlElement n in e.SelectNodes("resident")) { int id=(int)Value(n,"id",0,outlaw?63:adventure?47:35);if(!ids.Add(id))throw new InvalidDataException();residents.Add(new Body { ResidentId=id,X=Value(n,"x",50,25950),Y=Value(n,"y",50,5950),HP=Value(n,"hp",0,100),RouteProgress=Value(n,"progress",0,PathLength(MountainRoad)) }); }
                if(enemies.Count>60||!legacy&&residents.Count!=(outlaw?64:adventure?48:36))throw new InvalidDataException();
                ResetFrontier();Player.X=x;Player.Y=y;Player.HP=hp;HorseHP=hhp;Horse=new PointF(hx,hy);Mounted=mounted&&hhp>0;Player.R=Mounted?21:16;
                Money=money;Kills=kills;GunUpgrade=upgrade;HouseStage[0]=h0;HouseStage[1]=h1;Contract=contract;CampCleared[0]=c0;CampCleared[1]=c1;
                RailClock=regional?rail:MigrateRailClock(rail,legacy);Elapsed=elapsed;Aboard=aboard;departure=dep;Weapon=(WeaponType)weapon;ammunition[0]=a0;ammunition[1]=a1;
                ShotgunOwned=shotgun;Wanted=wanted;EscapeClock=escape;MealTime=meal;ammunition[2]=a2;
                LoadAdventure(adventureState);
                if(outlawState!=null)PrisonerFree=outlawState[4]>0;
                LoadPrisonDrama(dramaState);
                foreach(Body n in residents) { Body target=Residents[n.ResidentId];target.X=n.X;target.Y=n.Y;target.HP=n.HP;target.RouteProgress=n.RouteProgress; }
                if(legacy&&x>9500)Player.Y=Math.Min(5900,y+1400);
                if(!Aboard&&!Flying)RescuePosition(Player);else if(Aboard) { Player.X=RailPosition.X;Player.Y=RailPosition.Y; }
                Body horseBody=new Body { X=Horse.X,Y=Horse.Y,R=21 };if(legacy&&hx>9500)horseBody.Y+=1400;if(!Flying)RescuePosition(horseBody);Horse=Mounted?new PointF(Player.X,Player.Y):new PointF(horseBody.X,horseBody.Y);
                Enemies.Clear();Enemies.AddRange(enemies);LoadOutlaws(outlawState);LoadRegionalLaw(lawState);foreach(Body enemy in Enemies)RescuePosition(enemy);CameraX=Player.X;CameraY=Player.Y;ResetFollowCamera3();Invulnerable=2;WorldMap=false;
                Announce(file==SavePath?"存档已读取":"主存档无法读取 · 已恢复备用存档");return true;
            } catch { }
            Announce("没有可读取的有效存档 · 现有进度未更改");return false;
        }
    }
}


