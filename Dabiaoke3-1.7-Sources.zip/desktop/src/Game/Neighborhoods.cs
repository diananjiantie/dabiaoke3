﻿using System;
using System.Drawing;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        // Ten real minutes per day. Elapsed is already persisted by every world save.
        public float WorldHour { get { return (8+(Elapsed%600)*24/600)%24; } }
        public float NightStrength { get { float h=WorldHour;return h<5||h>=20?1:h<7?(7-h)/2:h<18?0:(h-18)/2; } }
        public int LitHouseCount { get { int n=0;if(NightStrength<=0)return n;foreach(Building b in Buildings)if(b.Kind=="home")n++;foreach(int stage in HouseStage)if(stage==3)n++;return n; } }
        void ConfigureNeighborhoods() {
            for(int town=0;town<2;town++) {
                float dx=town*9000,dy=town*1400;
                foreach(PointF p in new[]{new PointF(740,1950),new PointF(1040,1950),new PointF(1800,1950),new PointF(2110,1950),new PointF(2070,2380),new PointF(2070,2900)})
                    Buildings.Add(new Building(p.X+dx,p.Y+dy,180,125,"home",""));
            }
            foreach(PointF p in new[]{new PointF(1720,4370),new PointF(2020,4370),new PointF(3100,4250),new PointF(3440,4250),new PointF(3780,4250),new PointF(4080,5200),new PointF(9660,1050),new PointF(9960,1400),new PointF(10260,1400),new PointF(11150,550),new PointF(21500,2950),new PointF(21500,3250),new PointF(21900,3250),new PointF(22300,3250),new PointF(22600,2750),new PointF(22600,3100)})
                Buildings.Add(new Building(p.X,p.Y,180,125,"home",""));
        }
        void DrawOilLamp(float x,float y,int alpha) {
            PointF p=Project(x,y,68);
            Line(p.X-7,p.Y-13,p.X-7,p.Y-24,"#282722",3,alpha);
            Line(p.X-7,p.Y-24,p.X+3,p.Y-24,"#282722",3,alpha);
            Line(p.X+3,p.Y-24,p.X+3,p.Y-14,"#282722",2,alpha);
            RectA(p.X-5,p.Y-14,16,4,"#292b27",alpha);
            RectA(p.X-3,p.Y-10,12,16,"#b8a16d",alpha);
            RectA(p.X+2,p.Y-10,2,16,"#514c39",alpha);
            RectA(p.X-5,p.Y+6,16,4,"#292b27",alpha);
        }
        void DrawLampGlow(float x,float y,float strength) {
            if(!VisibleWorld(x,y,160))return;
            PointF p=Project(x,y,68),floor=Project(x,y+25,0);
            // Fixed concentric shapes avoid per-frame bitmaps, gradients and dynamic shadows.
            int a=(int)(strength*16)*4;
            Ellipse(floor.X,floor.Y,65,25,"#ffc366",a/3);
            Ellipse(p.X+3,p.Y-2,51,43,"#ffb650",a/5);
            Ellipse(p.X+3,p.Y-2,32,29,"#ffc86b",a/4);
            Ellipse(p.X+3,p.Y-2,17,18,"#ffd889",a/2);
            RectA(p.X-2,p.Y-9,10,14,"#ffd88c",a*3);
            Ellipse(p.X+3,p.Y,2,5,"#fff1bc",a*3);
        }
        void DrawNeighborhoodNight() {
            float strength=NightStrength;
            if(strength<=0)return;
            RectA(-15,-15,Width+30,Height+30,"#111e36",(int)(strength*32)*4);
            foreach(Building b in Buildings)if(b.Kind=="home")DrawLampGlow(b.X+b.W*.5f+34,b.Y+b.H+3,strength);
            for(int i=0;i<Plots.Length;i++)if(HouseStage[i]==3)DrawLampGlow(Plots[i].X+34,Plots[i].Y+3,strength);
        }
        void DrawWorldClock() {
            int minutes=(int)(WorldHour*60);
            Text("第 "+(1+(int)(Elapsed/600))+" 天  "+(minutes/60).ToString("00")+":"+(minutes%60).ToString("00")+" · "+(NightStrength==0?"白天":NightStrength==1?"夜晚":WorldHour<12?"晨曦":"黄昏")+(Use3D&&RainStrength3>0?" · 下雨":""),40,252,13,"#e8d6ad");
        }
    }
}


