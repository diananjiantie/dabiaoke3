﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Media;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
namespace ArthurFrontier {
    sealed partial class FrontierGame : IDisposable {
        public const int Width=1280,Height=800;
        public int WorldW { get { return IsFrontier?26000:2100; } }
        public int WorldH { get { return IsFrontier?6000:1500; } }
        public readonly HashSet<Keys> KeysDown=new HashSet<Keys>();
        public readonly List<Building> Buildings=new List<Building>();
        public readonly List<Body> Enemies=new List<Body>();
        public readonly List<Bullet> Bullets=new List<Bullet>();
        readonly List<Particle> particles=new List<Particle>();
        readonly List<Pickup> drops=new List<Pickup>();
        readonly List<Corpse> corpses=new List<Corpse>();
        readonly Random random=new Random();
        readonly Dictionary<string,Font> fonts=new Dictionary<string,Font>();
        readonly Dictionary<string,SoundPlayer> sounds=new Dictionary<string,SoundPlayer>();
        readonly List<MemoryStream> audioStreams=new List<MemoryStream>();
        readonly PointF[] route= {
            new PointF(650,730),new PointF(950,575),new PointF(1130,750)
        };
        Bitmap terrain,ground;
        readonly Dictionary<Building,BuildingSprite> buildingSprites=new Dictionary<Building,BuildingSprite>();
        readonly Dictionary<string,Bitmap> textSprites=new Dictionary<string,Bitmap>();
        readonly Dictionary<int,Bitmap> actorSprites=new Dictionary<int,Bitmap>();
        readonly Dictionary<int,SolidBrush> brushes=new Dictionary<int,SolidBrush>();
        readonly Dictionary<string,Pen> pens=new Dictionary<string,Pen>();
        static readonly Dictionary<string,Color> colors=new Dictionary<string,Color>();
        readonly List<DrawItem> drawList=new List<DrawItem>(48);
        readonly List<DrawItem> staticDrawItems=new List<DrawItem>();
        LinearGradientBrush topShade,bottomShade;
        public Body Player=new Body();
        public string State="intro",Chapter="ride";
        public bool Paused,DeadEye,Mounted,Muted,MouseInside,MouseHeld;
        public bool ShowCredits;
        public float Sensitivity=1;
        public string SettingsPath=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"ArthurFrontier","controls.txt");
        DateTime soundUntil=DateTime.MinValue;
        int soundPriority;
        public void SetSensitivity(float value) {
            Sensitivity=(float)Math.Round(Clamp(value,.5f,2f),1);
            try { Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath)); File.WriteAllText(SettingsPath,Sensitivity.ToString(System.Globalization.CultureInfo.InvariantCulture)); }
            catch { Announce("灵敏度已调整，本次未能保存设置"); }
        }
        public void MoveAim(float dx,float dy) {
            if(Use3D){CameraYaw+=dx*Sensitivity*.003f;CameraPitch=Clamp(CameraPitch+dy*Sensitivity*.002f,-.4f,.45f);Mouse=new PointF(640,400);return;}Mouse=new PointF(Clamp(Mouse.X+dx*Sensitivity,0,Width),Clamp(Mouse.Y+dy*Sensitivity,0,Height));
        }
        public PointF Mouse=new PointF(860,400),Horse=new PointF(300,730);
        public float CameraX=850,CameraY=700,ReloadTime,Cooldown,Invulnerable,DashTime,DashCooldown,Elapsed,Shake,NoticeTime;
        readonly int[] ammunition= {
            6,8,0
        };
        public WeaponType Weapon=WeaponType.Rifle;
        public int Ammo {
            get {
                return ammunition[(int)Weapon];
            }
            set {
                ammunition[(int)Weapon]=value;
            }
        }
        public int Capacity {
            get {
                return WeaponRules.Capacity(Weapon);
            }
        }
        public int Level=1;
        public float NormalHealth {
            get {
                return Level==2?160:Wave>=4?80:70;
            }
        }
        public float BossHealth {
            get {
                return Level==2?NormalHealth*10:WeaponRules.BossHealth;
            }
        }
        public Body ActiveBoss;
        public float HorseHP=200,HorseInvulnerable,BossQuiet,TrainClock,TrainY=-600;
        public bool TrainActive;
        public int TrainCount;
        public bool Endless;
        public float AllyCooldown;
        public PointF AllyPosition(int side) {
            return new PointF(Player.X+side*(Use3D?48:90),Player.Y);
        }
        public int SelectedLevel=1;
        public int Wave,Kills,Money,Checkpoint,SpawnQueue;
        public string RenderBackend="GDI";
        public int DisplayFps;
        public bool ShowFps;
        float spawnClock,waveDelay,hoofClock;
        public string Notice="";
        Graphics g;
        public FrontierGame() {
            try { float value;if(float.TryParse(File.ReadAllText(SettingsPath),System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out value)&&!float.IsNaN(value))Sensitivity=Clamp(value,.5f,2f); } catch { }
            ConfigureMap();
            CreateTerrain();
            CacheScenery();
            MakeSound("shot",135,.12f,.35f);
            MakeSound("reload",720,.075f,.11f);
            MakeSound("eye",220,.3f,.12f);
            MakeSound("hit",65,.2f,.3f);
            MakeSound("hoof",95,.05f,.09f);
            MakeSound("pickup",650,.14f,.11f);
            MakeSound("empty",170,.03f,.07f);
            MakeSound("won",660,.6f,.22f);
            MakeSound("lost",110,.6f,.25f);
        }
        void ConfigureMap() {
            Buildings.Clear();
            if(IsFrontier) { ConfigureFrontier();return; }
            if(Level==3)return;
            if(Level==1) {
                Buildings.Add(new Building(265,250,240,155,"saloon","SALOON"));
                Buildings.Add(new Building(1425,250,245,155,"sheriff","SHERIFF"));
                Buildings.Add(new Building(300,1060,230,170,"stable","STABLE"));
                Buildings.Add(new Building(1420,1090,250,150,"store","GENERAL STORE"));
                foreach(PointF p in new[] {
                    new PointF(660,465),new PointF(1220,1020),new PointF(680,1010),new PointF(1240,460),new PointF(945,300),new PointF(1090,1240)
                }) Buildings.Add(new Building(p.X,p.Y,48,48,"crate",""));
                foreach(PointF p in new[] {
                    new PointF(600,875),new PointF(1340,790),new PointF(930,1100)
                }) Buildings.Add(new Building(p.X,p.Y,38,38,"barrel",""));
            }
            else {
                Buildings.Add(new Building(330,280,300,130,"store","RAIL DEPOT"));
                Buildings.Add(new Building(1320,420,280,130,"sheriff","MINE OFFICE"));
                Buildings.Add(new Building(430,1090,260,140,"stable","SUPPLY CAMP"));
                Buildings.Add(new Building(1490,1050,180,170,"saloon","MICAH'S HIDEOUT"));
                foreach(PointF p in new[] {
                    new PointF(740,350),new PointF(1180,1100),new PointF(1570,740),new PointF(410,900),new PointF(820,1000)
                })Buildings.Add(new Building(p.X,p.Y,65,65,"crate",""));
            }
        }
        void LoadMap(int level) {
            Level=level;
            ground.Dispose();
            topShade.Dispose();
            bottomShade.Dispose();
            foreach(BuildingSprite b in buildingSprites.Values)b.Dispose();
            buildingSprites.Clear();
            staticDrawItems.Clear();
            foreach(Bitmap b in actorSprites.Values)b.Dispose();
            actorSprites.Clear();
            ConfigureMap();
            CreateTerrain();
            CacheScenery();
        }
        public void StartLevel(int level) {
            if(level==4) { StartFrontier();return; }
            SelectedLevel=level;
            if(level==3)StartThirdLevel();
            else if(level==2)StartSecondLevel();
            else Start();
        }
        public void Home() {
            if(IsFrontier&&State=="playing")SaveFrontier();
            WorldMap=false;
            State="intro";
            Paused=false;
            DeadEye=false;
            MouseHeld=false;
            KeysDown.Clear();
        }
        public void ContinueGame() {
            if(IsFrontier&&State=="lost") { LoadFrontier();return; }
            if(State=="intro") {
                StartLevel(SelectedLevel);
                return;
            }
            if(State=="won"&&Level==3) {
                Endless=true;
                State="playing";
                waveDelay=3;
                Announce("20 波挑战完成 · 无尽追击开始");
                return;
            }
            StartLevel(State=="won"?Math.Min(3,Level+1):Level);
        }
        public void StartThirdLevel() {
            Start();
            LoadMap(3);
            Chapter="train";
            Mounted=false;
            HorseHP=0;
            Enemies.Clear();
            Player.X=945;
            Player.Y=750;
            Player.R=16;
            CameraX=945;
            CameraY=850;if(Use3D){Player.Angle=(float)Math.PI/2;ResetFollowCamera3();}
            Weapon=WeaponType.Revolver;
            TrainY=680;
            Announce("第三关 · 列车重机枪 · 坚持 20 波");
        }
        public void StartSecondLevel() {
            Start();
            LoadMap(2);
            Chapter="town";
            Enemies.Clear();
            Player.X=1050;
            Player.Y=750;
            Horse=new PointF(1050,750);
            CameraX=1050;
            CameraY=750;ResetFollowCamera3();
            Announce("第二关 · 冷杉矿场 · 左轮射速强化");
        }
        static Color C(string h) {
            Color c;
            if(!colors.TryGetValue(h,out c)) {
                c=ColorTranslator.FromHtml(h);
                colors[h]=c;
            }
            return c;
        }
        static float Clamp(float n,float lo,float hi) {
            return Math.Max(lo,Math.Min(hi,n));
        }
        float Rand(float a,float b) {
            return a+(float)random.NextDouble()*(b-a);
        }
        static float Distance(float x,float y,float xx,float yy) {
            return (float)Math.Sqrt((x-xx)*(x-xx)+(y-yy)*(y-yy));
        }
        static float Angle(float x,float y,float xx,float yy) {
            return (float)Math.Atan2(yy-y,xx-x);
        }
        public PointF Project(float x,float y,float z) {
            if(Use3D)return Project3D(x,y,z);
            return new PointF(Width/2+(x-CameraX)+.24f*(y-CameraY),Height/2+.62f*(y-CameraY)-z);
        }
        public PointF Unproject(float x,float y,float z) {
            if(Use3D)return Unproject3D(x,y,z);
            float dy=(y-Height/2+z)/.62f;
            return new PointF(CameraX+x-Width/2-.24f*dy,CameraY+dy);
        }
        public void Start() {
            if(Level!=1)LoadMap(1);
            Endless=false;
            AllyCooldown=0;
            ActiveBoss=null;
            HorseHP=200;
            HorseInvulnerable=0;
            BossQuiet=0;
            TrainClock=0;
            TrainY=-600;
            TrainActive=false;
            TrainCount=0;
            Player=new Body {
                X=300,Y=730,R=21,HP=100,MaxHP=100
            };
            Horse=new PointF(Player.X,Player.Y);
            Mounted=true;
            Checkpoint=0;
            State="playing";
            Chapter="ride";
            Paused=false;
            DeadEye=false;
            Weapon=WeaponType.Rifle;
            ammunition[0]=6;
            ammunition[1]=8;
            Wave=0;
            Kills=0;
            Money=0;
            Elapsed=0;
            SpawnQueue=0;
            ReloadTime=0;
            Cooldown=0;
            Invulnerable=0;
            DashCooldown=0;
            DashTime=0;
            Shake=0;
            waveDelay=1;
            hoofClock=0;
            spawnClock=0;
            Enemies.Clear();
            Bullets.Clear();
            particles.Clear();
            drops.Clear();
            corpses.Clear();
            KeysDown.Clear();
            MouseHeld=false;
            CameraX=Player.X;
            CameraY=Player.Y;ResetFollowCamera3();
            Enemies.Add(new Body {
                X=90,Y=630,R=16,HP=70,MaxHP=70,Speed=105,Shoot=2,Variant=true
            });
            Enemies.Add(new Body {
                X=90,Y=880,R=16,HP=70,MaxHP=70,Speed=95,Shoot=3
            });
            Announce("序章 · 策马进入日落镇");
            Play("eye");
        }
        public void Announce(string s) {
            Notice=s;
            NoticeTime=3;
        }
        public void TogglePause() {
            if(State!="playing")return;
            Paused=!Paused;
            ResetMotion3();
            KeysDown.Clear();
            MouseHeld=false;
            DeadEye=false;
        }
        public void LoseFocus() {
            KeysDown.Clear();
            MouseHeld=false;
            if(State=="playing"&&!Paused)TogglePause();
        }
        public void KeyPressed(Keys key) {
            bool fresh=KeysDown.Add(key);
            if(IsFrontier&&Captured&&State=="playing"&&!Paused) {
                if(key==Keys.T&&fresh) { DigPrisonWall();return; }
                if(key!=Keys.F5&&key!=Keys.F9&&key!=Keys.Home&&key!=Keys.Escape&&key!=Keys.M)return;
            }
            if(ShowCredits) { if(key==Keys.Escape||key==Keys.Enter||key==Keys.Home)ShowCredits=false; return; }
            if(State=="intro"&&fresh&&key==Keys.D4) { StartFrontier();return; }
            if(State=="intro"&&fresh&&key==Keys.F9) { LoadFrontier();return; }
            if(IsFrontier&&fresh) {
                if(State=="playing"&&!Paused&&key==Keys.G) { FishAction();return; }
                if(State=="playing"&&!Paused&&key==Keys.X) { StartRobbery();return; }
                if(key==Keys.F5) { SaveFrontier();return; }
                if(key==Keys.F9) { LoadFrontier();return; }
                if(key==Keys.M&&State=="playing") { WorldMap=!WorldMap;Paused=WorldMap;MouseHeld=false;return; }
                if(WorldMap&&key==Keys.Escape) { WorldMap=false;Paused=false;return; }
                if(key==Keys.Q&&State=="playing"&&!Paused) { InteractFrontier();return; }
                if(key==Keys.T&&State=="playing"&&!Paused) { AlternateService();return; }
            }
            if(key==Keys.Home&&fresh) {
                Home();
                return;
            }
            if(State=="intro"&&fresh&&(key==Keys.D1||key==Keys.D2||key==Keys.D3)) {
                SelectedLevel=key==Keys.D1?1:key==Keys.D2?2:3;
                return;
            }
            if(key==Keys.Escape&&fresh) {
                TogglePause();
                return;
            }
            if(key==Keys.Enter&&fresh&&State=="playing"&&Paused){TogglePause();return;}
            if(key==Keys.Enter&&fresh&&(State=="intro"||State=="won"||State=="lost")) {
                ContinueGame();
                return;
            }
            if(State!="playing"||Paused)return;
            if(key==Keys.E&&fresh) {
                DeadEye=!DeadEye;
                Play("eye");
            }
            if(key==Keys.R)Reload();
            if(key==Keys.D1&&fresh)SwitchWeapon(WeaponType.Revolver);
            if(key==Keys.D2&&fresh)SwitchWeapon(WeaponType.Rifle);
            if(key==Keys.D3&&fresh&&IsFrontier)SwitchWeapon(WeaponType.Shotgun);
            if(key==Keys.F&&fresh)ToggleHorse();
            if(key==Keys.Space&&fresh&&DashCooldown<=0) {
                DashTime=Mounted?.34f:.17f;
                DashCooldown=Mounted?1.5f:1.25f;
                Invulnerable=Math.Max(Invulnerable,.25f);
            }
        }
        public void ToggleHorse() {
            if(IsFrontier&&Captured)return;
            if(IsFrontier&&(Flying||Aboard||MealTime>0))return;
            if(Level==3) {
                Announce("坚守车载重机枪 · 鼠标瞄准，按住左键射击");
                return;
            }
            if(HorseHP<=0) {
                Announce("马匹已倒下 · 本关改为徒步作战");
                return;
            }
            if(Chapter=="ride") {
                Announce("先沿金色路标骑入日落镇");
                return;
            }
            if(Mounted) {
                for(int i=0;i<8;i++) {
                    float a=(float)Math.PI*i/4;
                    float x=Player.X+(float)Math.Cos(a)*50,y=Player.Y+(float)Math.Sin(a)*50;
                    if(!Blocked(x,y,16)) {
                        Horse=new PointF(Player.X,Player.Y);
                        Player.X=x;
                        Player.Y=y;
                        Player.R=16;
                        Mounted=false;
                        Announce("已下马 · 靠近马匹按 F 上马");
                        return;
                    }
                }
                Announce("这里太拥挤，换个位置下马");
            }
            else if(Distance(Player.X,Player.Y,Horse.X,Horse.Y)<125) {
                Player.X=Horse.X;
                Player.Y=Horse.Y;
                Player.R=21;
                Mounted=true;
                Announce("已上马 · 可以在马背上射击");
            }
            else Announce("靠近地图上的马匹后按 F 上马");
        }
        public void SwitchWeapon(WeaponType weapon) {
            if(weapon==WeaponType.Shotgun&&(!IsFrontier||!ShotgunOwned)) { Announce("先到枪械铺购买短管霰弹枪");return; }
            if(Level==3)return;
            if(Weapon==weapon)return;
            Weapon=weapon;
            ReloadTime=0;
            Cooldown=Math.Max(Cooldown,.2f);
            if(weapon==WeaponType.Shotgun) { Announce("短管霰弹枪 · 两发装填 · 近距离散射");return; }
            Announce(Weapon==WeaponType.Rifle?(Level==2?"长枪 · 8 发 · 矿场敌人需要两枪":"长枪 · 8 发 · 普通敌人一枪击败"):"左轮 · 6 发 · 快速连射");
        }
        public void Reload() {
            if(Level==3)return;
            if(ReloadTime<=0&&Ammo<Capacity) {
                ReloadTime=WeaponRules.ReloadSeconds(Weapon);
                Play("reload");
            }
        }
        public bool Blocked(float x,float y,float r) {
            if(IsFrontier&&SecurityBlocked(x,y,r))return true;
            if(x<r+55||y<r+55||x>WorldW-r-55||y>WorldH-r-55)return true;
            if(IsFrontier&&RiverBlocked(x,y,r))return true;
            if(IsFrontier&&Ocean(x,y,r))return true;
            if(IsFrontier)for(int i=0;i<2;i++)if(HouseStage[i]>=2&&new RectangleF(Plots[i].X-100-r,Plots[i].Y-140-r,200+2*r,140+2*r).Contains(x,y))return true;
            foreach(Building o in Buildings)if(Distance(x,y,Clamp(x,o.X,o.X+o.W),Clamp(y,o.Y,o.Y+o.H))<r)return true;
            return false;
        }
        public void Move(Body b,float dx,float dy) {
            if(IsFrontier&&b==Player) {
                if(Flying)return;
                float factor=RiverBlocked(b.X,b.Y,b.R)?(Mounted?.55f:.35f):MountainBlocked(b.X,b.Y,b.R)?(Mounted?.3f:.65f):1;
                dx*=factor;dy*=factor;
                if(!PlayerTerrainBlocked(b.X+dx,b.Y,b.R))b.X+=dx;
                if(!PlayerTerrainBlocked(b.X,b.Y+dy,b.R))b.Y+=dy;
                return;
            }
            if(!Blocked(b.X+dx,b.Y,b.R))b.X+=dx;
            if(!Blocked(b.X,b.Y+dy,b.R))b.Y+=dy;
        }
        bool HitWall(float x,float y) {
            if(IsFrontier&&SecurityBlocked(x,y,0))return true;
            if(IsFrontier)for(int i=0;i<2;i++)if(HouseStage[i]>=2&&new RectangleF(Plots[i].X-100,Plots[i].Y-140,200,140).Contains(x,y))return true;
            foreach(Building o in Buildings)if(x>o.X&&x<o.X+o.W&&y>o.Y&&y<o.Y+o.H)return true;
            return false;
        }
        bool ClearShot(float x,float y,float xx,float yy) {
            int n=(int)Math.Ceiling(Distance(x,y,xx,yy)/16);
            for(int i=1;i<n;i++)if(HitWall(x+(xx-x)*i/n,y+(yy-y)*i/n))return false;
            return true;
        }
        void Burst(float x,float y,string color,int count,float speed) {
            for(int i=0;i<count;i++) {
                float a=Rand(0,(float)Math.PI*2),v=Rand(20,speed),life=Rand(.15f,.5f);
                particles.Add(new Particle {
                    X=x,Y=y,VX=(float)Math.Cos(a)*v,VY=(float)Math.Sin(a)*v,Life=life,MaxLife=life,Color=C(color),Size=Rand(2,5)
                });
            }
        }
        public void Fire() {
            if(IsFrontier&&Captured)return;
            if(IsFrontier&&(Flying||Aboard||MealTime>0||FishingTime>0))return;
            if(Level==3) {
                if(Cooldown>0)return;
                PointF target=Unproject(Mouse.X,Mouse.Y,22);
                float gunAngle=Angle(Player.X,Player.Y,target.X,target.Y);
                Player.Angle=gunAngle;
                Cooldown=.075f;
                Bullets.Add(new Bullet {
                    X=Player.X+(float)Math.Cos(gunAngle)*30,Y=Player.Y+(float)Math.Sin(gunAngle)*30,VX=(float)Math.Cos(gunAngle)*1550,VY=(float)Math.Sin(gunAngle)*1550,Life=1,Friendly=true,Damage=55
                });
                if(AllyCooldown<=0) {
                    foreach(int side in new[] {
                        -1,1
                    }) {
                        PointF ally=AllyPosition(side);
                        float aimAngle=Angle(ally.X,ally.Y,target.X,target.Y);
                        Bullets.Add(new Bullet {
                            X=ally.X+(float)Math.Cos(aimAngle)*28,Y=ally.Y+(float)Math.Sin(aimAngle)*28,VX=(float)Math.Cos(aimAngle)*1550,VY=(float)Math.Sin(aimAngle)*1550,Life=1,Friendly=true,Damage=35
                        });
                    }
                    AllyCooldown=.225f;
                }
                Burst(Player.X+(float)Math.Cos(gunAngle)*35,Player.Y+(float)Math.Sin(gunAngle)*35,"#ffe098",3,100);
                Shake=2;
                Play("shot");
                return;
            }
            if(ReloadTime>0||Cooldown>0)return;
            if(Ammo<=0) {
                Cooldown=.3f;
                Play("empty");
                if(NoticeTime<=0)Announce("弹巢已空 · 按 R 换弹");
                return;
            }
            float height=Mounted?43:22;
            PointF aim=Unproject(Mouse.X,Mouse.Y,height);
            bool marked=IsFrontier&&TakeMarkedAim(ref aim);
            if(DeadEye&&!IsFrontier&&!marked) {
                Body target=null;
                float best=110;
                foreach(Body e in Enemies) {
                    float d=Distance(e.X,e.Y,aim.X,aim.Y);
                    if(d<best&&ClearShot(Player.X,Player.Y,e.X,e.Y)) {
                        best=d;
                        target=e;
                    }
                }
                if(target!=null)aim=new PointF(target.X,target.Y);
            }
            float a=Angle(Player.X,Player.Y,aim.X,aim.Y);
            Player.Angle=a;
            Ammo--;
            if(IsFrontier&&DeadEye&&ResolveEyeShot())return;
            if(Weapon==WeaponType.Shotgun) {
                Cooldown=DeadEye?.4f:.7f;
                for(int pellet=-3;pellet<=3;pellet++) { float spread=a+pellet*.055f;Bullets.Add(new Bullet {
                    X=Player.X+(float)Math.Cos(spread)*28,Y=Player.Y+(float)Math.Sin(spread)*28,VX=(float)Math.Cos(spread)*900,VY=(float)Math.Sin(spread)*900,
                    Life=.36f,Friendly=true,Damage=22*(1+GunUpgrade*.25f) }); }
                Burst(Player.X+(float)Math.Cos(a)*32,Player.Y+(float)Math.Sin(a)*32,"#ffe098",9,180);Shake=7;Play("shot");return;
            }
            Cooldown=Weapon==WeaponType.Rifle?(DeadEye?.3f:.5f):(Level==2?(DeadEye?.08f:.14f):(DeadEye?.16f:.27f));
            float velocity=Weapon==WeaponType.Rifle?1450:1020;
            Bullets.Add(new Bullet {
                X=Player.X+(float)Math.Cos(a)*28,Y=Player.Y+(float)Math.Sin(a)*28,VX=(float)Math.Cos(a)*velocity,VY=(float)Math.Sin(a)*velocity,Life=Weapon==WeaponType.Rifle?1.1f:.9f,Friendly=true,Damage=WeaponRules.Damage(Weapon,DeadEye)*(IsFrontier?1+GunUpgrade*.25f:1)
            });
            Burst(Player.X+(float)Math.Cos(a)*32,Player.Y+(float)Math.Sin(a)*32,"#ffe098",7,180);
            Shake=DeadEye?3:5;
            Play("shot");
        }
        void Spawn() {
            if(Level==3) {
                float health=90+Math.Min(Wave,60)*6;
                Enemies.Add(new Body {
                    X=Rand(590,1300),Y=Rand(1130,1400),HP=health,MaxHP=health,Speed=45+Math.Min(Wave,40),Shoot=Rand(2,4),Variant=random.Next(2)==1
                });
                return;
            }
            int side=random.Next(4);
            float x=0,y=0;
            if(side<2) {
                x=side==0?85:WorldW-85;
                y=Rand(480,1000);
            }
            else {
                x=Rand(650,1330);
                y=side==2?85:WorldH-85;
            }
            bool elite=Wave==5&&SpawnQueue==1;
            float hp=elite?BossHealth:NormalHealth;
            Enemies.Add(new Body {
                X=x,Y=y,R=elite?23:16,HP=hp,MaxHP=hp,Elite=elite,Speed=elite?83:Rand(67,90)+Wave*6,Shoot=Rand(1.4f,3),Variant=random.Next(2)==1
            });
            if(elite) {
                ActiveBoss=Enemies[Enemies.Count-1];
                BossQuiet=0;
            }
        }
        public void StartWave() {
            if(Level==3) {
                Wave++;
                SpawnQueue=Math.Min(24,5+Wave);
                spawnClock=0;
                waveDelay=0;
                Player.HP=Player.MaxHP;
                Announce((Endless?"无尽追击 · ":"列车守卫 · ")+"第 "+Wave+" 波");
                return;
            }
            Wave++;
            SpawnQueue=5+Wave*2;
            spawnClock=0;
            waveDelay=0;
            if(Wave>1) {
                Player.HP=Math.Min(100,Player.HP+14);
                ammunition[0]=6;
                ammunition[1]=8;
                ReloadTime=0;
            }
            Announce(Wave==5?(Level==2?"最终首领 · 麦卡 · 1600 血量":"最终首领 · 长枪需命中 10 枪"):"第 "+Wave+" 波 · "+(Level==2?"守住冷杉矿场":"守住日落镇"));
        }
        public void Damage(float amount,bool policeAttack=false) {
            if(IsFrontier&&Captured)return;
            if(IsFrontier&&Aboard)return;
            if(Invulnerable>0||State!="playing")return;
            if(IsFrontier&&policeAttack&&Wanted>0&&Player.HP<=amount) { ArrestPending=true;Player.HP=1;Invulnerable=2;return; }
            if(Mounted)DamageHorse(amount);
            Player.HP=Math.Max(0,Player.HP-amount);
            if(IsFrontier&&(BankOpening>0||WagonOpening>0)) { BankOpening=WagonOpening=0;Announce("受伤了，开锁中断"); }
            if(IsFrontier&&MealTime>0) { MealTime=0;Announce("用餐被打断"); }
            Invulnerable=.65f;
            Shake=10;
            Burst(Player.X,Player.Y,"#bd5634",12,110);
            Play("hit");
            if(Player.HP<=0)Finish(false);
        }
        public void DamageHorse(float amount) {
            if(IsFrontier&&Aboard)return;
            if(HorseHP<=0||HorseInvulnerable>0)return;
            HorseHP=Math.Max(0,HorseHP-amount);
            HorseInvulnerable=.65f;
            if(HorseHP<=0) {
                Mounted=false;
                Player.R=16;
                Announce("马匹倒下 · 继续徒步战斗");
            }
        }
        public void UpdateWorldEvents(float dt) {
            HorseInvulnerable=Math.Max(0,HorseInvulnerable-dt);
            if(ActiveBoss!=null&&ActiveBoss.HP>0) {
                BossQuiet+=dt;
                float healTime=Math.Min(dt,Math.Max(0,BossQuiet-5));
                if(healTime>0)ActiveBoss.HP=Math.Min(ActiveBoss.MaxHP,ActiveBoss.HP+ActiveBoss.MaxHP*.02f*healTime);
            }
            if(Level!=2)return;
            TrainClock+=dt;
            if(TrainClock>=15) {
                TrainClock-=15;
                TrainActive=true;
                TrainY=-100;
                TrainCount++;
                Announce("列车驶入 · 远离铁轨！");
            }
            if(!TrainActive)return;
            TrainY+=420*dt;
            if(TrainY>WorldH+520) {
                TrainActive=false;
                return;
            }
            if(OnTrain(Player.X,Player.Y))Damage(30);
            if(!Mounted&&OnTrain(Horse.X,Horse.Y))DamageHorse(35);
            foreach(Body enemy in Enemies)if(enemy.HP>0&&OnTrain(enemy.X,enemy.Y)) {
                enemy.HP=Math.Max(0,enemy.HP-240*dt);
                if(enemy.Elite)BossQuiet=0;
                if(enemy.HP<=0)Kill(enemy);
            }
            Enemies.RemoveAll(delegate(Body enemy) {
                return enemy.HP<=0;
            });
        }
        bool OnTrain(float x,float y) {
            if(Use3D){if(!TrainActive||Math.Abs(x-950)>76)return false;for(int car=0;car<3;car++)if(Math.Abs(y-(TrainY-car*290))<125)return true;return false;}return TrainActive&&Math.Abs(x-945)<65&&y>TrainY-420&&y<TrainY+40;
        }
        void Kill(Body e) {
            if(IsFrontier)SecurityDefeated(e);
            if(IsFrontier&&e.Police) { RaiseWanted();RegionalOfficerDied(e);return; }
            Kills++;
            Money+=IsFrontier?10:e.Elite?150:25;
            Burst(e.X,e.Y,"#d7a65f",14,160);
            corpses.Add(new Corpse {
                X=e.X,Y=e.Y
            });
            if(Kills%4==0)drops.Add(new Pickup {
                X=e.X,Y=e.Y
            });
            if(corpses.Count>35)corpses.RemoveAt(0);
        }
        public void Finish(bool win) {
            State=win?"won":"lost";
            Play(win?"won":"lost");
            DeadEye=false;
            MouseHeld=false;
            KeysDown.Clear();
        }
        public void Update(float dt) {
            if(State!="playing"||Paused)return;
            if(IsFrontier&&ArrestPending)CapturePlayer();
            if(IsFrontier)UpdateFrontier(dt);
            UpdateWorldEvents(dt);
            if(State!="playing")return;
            Elapsed+=dt;
            AllyCooldown=Math.Max(0,AllyCooldown-dt);
            Cooldown=Math.Max(0,Cooldown-dt);
            Invulnerable=Math.Max(0,Invulnerable-dt);
            DashTime=Math.Max(0,DashTime-dt);
            DashCooldown=Math.Max(0,DashCooldown-dt);
            NoticeTime=Math.Max(0,NoticeTime-dt);
            if(ReloadTime>0) {
                ReloadTime-=dt;
                if(ReloadTime<=0) {
                    Ammo=Capacity;
                    Play("reload");
                }
            }
            // Dead Eye is intentionally unlimited: no meter, resource, cooldown or timeout.
            float wd=dt*(DeadEye?.22f:1);
            float dx=(KeysDown.Contains(Keys.D)?1:0)-(KeysDown.Contains(Keys.A)?1:0),dy=(KeysDown.Contains(Keys.S)?1:0)-(KeysDown.Contains(Keys.W)?1:0);
            if(Use3D){float c=(float)Math.Cos(CameraYaw),s=(float)Math.Sin(CameraYaw),oldDx=dx;dx=oldDx*c-dy*s;dy=oldDx*s+dy*c;}
            else{dx-=dy*.24f/.62f;dy/=.62f;}
            if(DashTime>0&&dx==0&&dy==0) {
                dx=(float)Math.Cos(Player.Angle);
                dy=(float)Math.Sin(Player.Angle);
            }
            if(Level==3||IsFrontier&&(Flying||Aboard||MealTime>0)) {
                dx=0;
                dy=0;
            }
            float len=(float)Math.Sqrt(dx*dx+dy*dy);
            float moved3=Use3D?MoveWeighted3(dx,dy,dt):0;
            if(Use3D?moved3>.001f:len>0) {
                float speed=Mounted?(DashTime>0?740:435):(DashTime>0?690:245);
                if(!Use3D){Move(Player,dx/len*speed*dt,dy/len*speed*dt);Player.Step+=dt*(Mounted?18:16);}
                if(Mounted) {
                    hoofClock-=dt;
                    if(hoofClock<=0) {
                        Play("hoof");
                        hoofClock=.21f;
                    }
                    if(random.NextDouble()<.35)Burst(Player.X-12,Player.Y+5,"#ceb17c",2,35);
                }
            }
            if(Mounted)Horse=new PointF(Player.X,Player.Y);
            if(Use3D)TurnBody3(VelocityX3,VelocityY3,dt);else{PointF aim=Unproject(Mouse.X,Mouse.Y,Mounted?43:22);Player.Angle=Angle(Player.X,Player.Y,aim.X,aim.Y);}
            if(MouseHeld)Fire();
            CameraX+=(Player.X+(Use3D?(float)Math.Cos(CameraYaw)*55:0)-CameraX)*Math.Min(1,dt*18);
            CameraY+=((Level==3&&!Use3D?850:Player.Y)+(Use3D?(float)Math.Sin(CameraYaw)*55:0)-CameraY)*Math.Min(1,dt*18);
            if(IsFrontier) { }
            else if(Chapter=="ride") {
                PointF target=route[Checkpoint];
                if(Distance(Player.X,Player.Y,target.X,target.Y)<95) {
                    Checkpoint++;
                    Play("pickup");
                    if(Checkpoint>=route.Length) {
                        Chapter="town";
                        waveDelay=.8f;
                        Announce("抵达日落镇 · F 可上下马");
                    }
                    else Announce("继续策马前进 · 路标 "+(Checkpoint+1)+" / 3");
                }
            }
            else if(Wave==0) {
                waveDelay-=dt;
                if(waveDelay<=0)StartWave();
            }
            else if(SpawnQueue>0) {
                spawnClock-=dt;
                if(spawnClock<=0) {
                    Spawn();
                    SpawnQueue--;
                    spawnClock=.5f;
                }
            }
            else if(Enemies.Count==0) {
                if((Level!=3&&Wave==5)||(Level==3&&Wave==20&&!Endless)) {
                    Finish(true);
                    return;
                }
                if(waveDelay<=0)waveDelay=3;
                waveDelay-=dt;
                if(waveDelay<=0)StartWave();
            }
            foreach(Body e in Enemies) {
                if(e.HP<=0)continue;
                if(IsFrontier&&(Flying||Aboard||Distance(e.X,e.Y,Player.X,Player.Y)>1400))continue;
                if(IsFrontier&&UpdateFaction(e,wd))continue;
                e.Hit=Math.Max(0,e.Hit-dt);
                PointF chase=IsFrontier?ChasePoint(e):new PointF(Player.X,Player.Y);
                e.Angle=Angle(e.X,e.Y,chase.X,chase.Y);
                float d=Distance(e.X,e.Y,Player.X,Player.Y);
                if(d>e.R+Player.R+2) {
                    float step=e.Speed*wd,ox=e.X,oy=e.Y;
                    Move(e,(float)Math.Cos(e.Angle)*step,(float)Math.Sin(e.Angle)*step);
                    if(Distance(ox,oy,e.X,e.Y)<step*.35f) {
                        float turn=e.Angle+(e.Variant?1.4f:-1.4f);
                        Move(e,(float)Math.Cos(turn)*step,(float)Math.Sin(turn)*step);
                    }
                    e.Step+=wd*10;
                }
                else Damage(12,IsArrestOfficer(e));
                if(Level==3&&e.Y<930)e.Y=930;
                e.Shoot-=wd;
                if(e.Shoot<=0&&d<760&&ClearShot(e.X,e.Y,Player.X,Player.Y)) {
                    float a=Angle(e.X,e.Y,Player.X,Player.Y)+Rand(-.1f,.1f),speed=e.Elite?280:230;
                    Bullets.Add(new Bullet {
                        X=e.X+(float)Math.Cos(a)*25,Y=e.Y+(float)Math.Sin(a)*25,VX=(float)Math.Cos(a)*speed,VY=(float)Math.Sin(a)*speed,Life=3.3f,PoliceShot=IsArrestOfficer(e)
                    });
                    e.Shoot=e.Elite?.85f:Rand(1.9f,3.1f);
                }
            }
            if(State!="playing")return;
            for(int i=0;i<Enemies.Count;i++)for(int j=i+1;j<Enemies.Count;j++) {
                Body a=Enemies[i],b=Enemies[j];
                float d=Distance(a.X,a.Y,b.X,b.Y),min=a.R+b.R+4;
                if(d>0&&d<min) {
                    float f=(min-d)*.5f,ux=(a.X-b.X)/d,uy=(a.Y-b.Y)/d;
                    Move(a,ux*f,uy*f);
                    Move(b,-ux*f,-uy*f);
                }
            }
            foreach(Bullet b in Bullets) {
                if(b.VisualOnly) { b.Life-=dt;continue; }
                float bt=b.Friendly?dt:wd;
                int steps=Math.Max(1,(int)Math.Ceiling(Math.Sqrt(b.VX*b.VX+b.VY*b.VY)*bt/10));
                b.LastX=b.X;
                b.LastY=b.Y;
                for(int n=0;n<steps&&b.Life>0;n++) {
                    b.X+=b.VX*bt/steps;
                    b.Y+=b.VY*bt/steps;
                    if(HitWall(b.X,b.Y)||b.X<0||b.Y<0||b.X>WorldW||b.Y>WorldH) {
                        b.Life=0;
                        Burst(b.X,b.Y,"#d8b475",4,80);
                        break;
                    }
                    if(b.Friendly) {
                        foreach(Body e in Enemies)if(e.HP>0&&Distance(b.X,b.Y,e.X,e.Y)<e.R+4) {
                            if(IsFrontier&&e.Police&&Wanted==0)RaiseWanted();
                            e.HP=Math.Max(0,e.HP-b.Damage);
                            if(e.Elite)BossQuiet=0;
                            e.Hit=.15f;
                            b.Life=0;
                            Burst(b.X,b.Y,"#e5c380",8,100);
                            if(e.HP<=0)Kill(e);
                            break;
                        }
                        if(IsFrontier&&b.Life>0)foreach(Body civilian in Residents)if(civilian.HP>0&&Distance(b.X,b.Y,civilian.X,civilian.Y)<20) {
                            HurtResident(civilian,b.Damage);b.Life=0;Burst(b.X,b.Y,"#c28a61",5,75);break;
                        }
                        if(IsFrontier&&b.Life>0&&WagonActive&&WagonHP>0&&Distance(b.X,b.Y,WagonPosition.X,WagonPosition.Y)<65) { WagonHP=Math.Max(0,WagonHP-b.Damage);b.Life=0;if(Wanted==0)RaiseWanted(); }
                        if(IsFrontier&&b.Life>0)foreach(Body spectator in ExecutionCrowd)if(spectator.HP>0&&Distance(b.X,b.Y,spectator.X,spectator.Y)<20) { HurtResident(spectator,b.Damage);b.Life=0;break; }
                    }
                    else if(b.Faction>0) {
                        foreach(Body opponent in Enemies)if(opponent.HP>0&&opponent.Police!=(b.Faction==1)&&Distance(b.X,b.Y,opponent.X,opponent.Y)<opponent.R+4) { opponent.HP=Math.Max(0,opponent.HP-b.Damage);opponent.Hit=.2f;b.Life=0;if(opponent.HP<=0) { SecurityDefeated(opponent);RegionalOfficerDied(opponent); }break; }
                    }
                    else if(Distance(b.X,b.Y,Player.X,Player.Y)<Player.R+4) {
                        b.Life=0;
                        Damage(14,b.PoliceShot);
                    }
                    else if(!Mounted&&HorseHP>0&&Distance(b.X,b.Y,Horse.X,Horse.Y)<25) {
                        b.Life=0;
                        DamageHorse(14);
                    }
                }
                b.Life-=bt;
            }
            Enemies.RemoveAll(delegate(Body e) {
                return e.HP<=0;
            });
            Bullets.RemoveAll(delegate(Bullet b) {
                return b.Life<=0;
            });
            foreach(Pickup d in drops) {
                d.Life-=dt;
                if(Distance(d.X,d.Y,Player.X,Player.Y)<42) {
                    Player.HP=Math.Min(100,Player.HP+25);
                    d.Life=0;
                    Play("pickup");
                    Burst(d.X,d.Y,"#aad47d",12,90);
                }
            }
            drops.RemoveAll(delegate(Pickup p) {
                return p.Life<=0;
            });
            foreach(Particle p in particles) {
                p.X+=p.VX*dt;
                p.Y+=p.VY*dt;
                p.VX*=.96f;
                p.VY*=.96f;
                p.Life-=dt;
            }
            particles.RemoveAll(delegate(Particle p) {
                return p.Life<=0;
            });
            foreach(Corpse c in corpses)c.Life-=dt;
            corpses.RemoveAll(delegate(Corpse c) {
                return c.Life<=0;
            });
            Shake=Math.Max(0,Shake-dt*35);
        }
    }
}







