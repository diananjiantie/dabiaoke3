﻿using System;
using System.Drawing;
using System.Xml;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        public const int LocalPoliceStrength=4;
        public const float PoliceRespawnSeconds=180;
        public readonly int[] PoliceSpawned=new int[5],PoliceDeaths=new int[5];
        public readonly float[] PoliceRespawn=new float[5];
        public readonly string[] DistrictNames={"日落地区","冷杉地区","石桥地区","风蚀地区","白鹭岛"};
        public int LocalDistrict { get { return DistrictAt(Player.X,Player.Y); } }
        public int DistrictAt(float x,float y) { return x>18000?4:x>9000&&y<2200?3:x<6000&&y>4300?2:x<6000?0:1; }
        void ResetRegionalLaw() { Array.Clear(PoliceSpawned,0,5);Array.Clear(PoliceDeaths,0,5);Array.Clear(PoliceRespawn,0,5);railDestination=-1; }
        void EnsureLocalPolice() {
            int district=LocalDistrict;if(Flying||Aboard||PoliceRespawn[district]>0)return;
            while(PoliceSpawned[district]<LocalPoliceStrength) {
                bool placed=false;
                for(int i=0;i<32;i++) {
                    float angle=(PoliceSpawned[district]*1.57f+i*.37f),x=Player.X+(float)Math.Cos(angle)*750,y=Player.Y+(float)Math.Sin(angle)*750;
                    if(DistrictAt(x,y)!=district||Blocked(x,y,16))continue;
                    Enemies.Add(new Body { X=x,Y=y,HP=130,MaxHP=130,Police=true,Camp=-1,LawDistrict=district,Speed=285,Shoot=1.5f });PoliceSpawned[district]++;placed=true;break;
                }
                if(!placed)break;
            }
        }
        void RegionalOfficerDied(Body e) {
            if(!e.Police||e.Guard!=0||e.LawDistrict<0||e.LawDeathHandled)return;
            e.LawDeathHandled=true;int district=e.LawDistrict;PoliceDeaths[district]=Math.Min(LocalPoliceStrength,PoliceDeaths[district]+1);
            if(PoliceDeaths[district]==LocalPoliceStrength) {
                Wanted=0;EscapeClock=PoliceClock=0;PoliceRespawn[district]=PoliceRespawnSeconds;
                Announce(DistrictNames[district]+"警员已全部阵亡 · 全部通缉清零 · 180秒后重建警队");SaveFrontier(false);
            }
        }
        void UpdateRegionalLaw(float dt) {
            for(int i=0;i<5;i++)if(PoliceRespawn[i]>0) {
                PoliceRespawn[i]=Math.Max(0,PoliceRespawn[i]-dt);
                if(PoliceRespawn[i]==0) { PoliceSpawned[i]=PoliceDeaths[i]=0;if(i==LocalDistrict)Announce("本地警队已重建 · 从新的犯罪重新计算通缉"); }
            }
            EnsureLocalPolice();
            if(PoliceRespawn[LocalDistrict]>0) { Wanted=0;EscapeClock=0;return; }
            if(Wanted<=0)return;
            bool seen=false;foreach(Body e in Enemies)if(e.Police&&e.HP>0&&!Aboard&&Distance(e.X,e.Y,Player.X,Player.Y)<950&&ClearShot(e.X,e.Y,Player.X,Player.Y))seen=true;
            EscapeClock=seen?0:EscapeClock+dt;
            if(EscapeClock>=25) { Wanted--;EscapeClock=0;if(Wanted==0)Announce("已摆脱通缉"); }
        }
        void SaveRegionalLaw(Action<string,string> put) {
            for(int i=0;i<5;i++) { put("lawSpawn"+i,PoliceSpawned[i].ToString());put("lawDead"+i,PoliceDeaths[i].ToString());put("lawReset"+i,Num(PoliceRespawn[i])); }
            put("railDestination",railDestination.ToString());
        }
        float[] ReadRegionalLaw(XmlElement root) {
            if(root.GetAttribute("version")!="5"&&root.GetAttribute("version")!="6")return null;
            float[] data=new float[16];
            for(int i=0;i<5;i++) { data[i]=Value(root,"lawSpawn"+i,0,4);data[5+i]=Value(root,"lawDead"+i,0,4);data[10+i]=Value(root,"lawReset"+i,0,180);if(data[5+i]>data[i]||data[10+i]>0&&data[5+i]!=4)throw new System.IO.InvalidDataException(); }
            data[15]=Value(root,"railDestination",-1,2);return data;
        }
        void LoadRegionalLaw(float[] data) {
            if(data==null) {
                // Old saves used unlimited reinforcements. Keep at most one finite squad per district.
                foreach(Body e in Enemies)if(e.Police&&e.Guard==0) { int d=DistrictAt(e.X,e.Y);if(PoliceSpawned[d]<4) { e.LawDistrict=d;PoliceSpawned[d]++; }else e.HP=0; }
                Enemies.RemoveAll(e=>e.HP<=0);railDestination=Aboard?(departure==0?1:0):-1;return;
            }
            for(int i=0;i<5;i++) { PoliceSpawned[i]=(int)data[i];PoliceDeaths[i]=(int)data[5+i];PoliceRespawn[i]=data[10+i]; }
            railDestination=(int)data[15];if(PoliceRespawn[LocalDistrict]>0)Wanted=0;
        }
        public readonly PointF[] RailStations={new PointF(1500,3300),new PointF(10500,4700),new PointF(2800,5650)};
        public readonly PointF[] RailPlatforms={new PointF(1500,3460),new PointF(10500,4860),new PointF(2800,5810)};
        int railDestination=-1;
        public string StationName(int id) { return id==0?"日落镇":id==1?"冷杉镇":id==2?"石桥镇":"途中"; }
        internal bool NearRail(float x,float y) { for(int i=1;i<Railway.Length;i++)if(SegmentDistance(Railway[i-1],Railway[i],x,y)<160)return true;return false; }
        float StationDistance(int id) {
            if(id==0)return 0;float length=0;for(int i=1;i<Railway.Length;i++) { length+=Distance(Railway[i-1].X,Railway[i-1].Y,Railway[i].X,Railway[i].Y);if(Railway[i]==RailStations[id])return length; }return length;
        }
        public float LegSeconds(int id) { return ((id==2?PathLength(Railway):StationDistance(id+1))-StationDistance(id))/TrainSpeed; }
        public float StationClock(int id) { return id*StationWait+StationDistance(id)/TrainSpeed; }
        public int RailNextStop { get { float t=RailClock%RailCycle;for(int i=2;i>=0;i--)if(t>=StationClock(i))return (i+1)%3;return 1; } }
        int CurrentRailStop() { float t=RailClock%RailCycle;for(int i=2;i>=0;i--)if(t>=StationClock(i))return t-StationClock(i)<StationWait?i:-1;return 0; }
        PointF LoopRailPoint(float behind) {
            float t=RailClock%RailCycle,distance=0;
            for(int i=2;i>=0;i--)if(t>=StationClock(i)) { distance=StationDistance(i)+Math.Max(0,t-StationClock(i)-StationWait)*TrainSpeed;break; }
            float length=PathLength(Railway);distance=(distance-behind)%length;if(distance<0)distance+=length;return Along(Railway,distance);
        }
        public float RailHeading3(float behind){PointF rear=LoopRailPoint(behind+65),front=LoopRailPoint(behind-65);return (float)Math.Atan2(front.Y-rear.Y,front.X-rear.X);}
        // The locomotive mesh has its smokebox at local -X and cab at +X.
        public static float VehicleModelHeading3(float forward,bool engine){return forward+(engine?(float)Math.PI:0);}
        bool BoardLoopTrain(WorldService station,bool farther) {
            if(Captured)return false;
            if(Flying||Aboard||MealTime>0||station==null||station.Kind!="station")return false;
            if(RailStop!=station.Index) { Announce("列车未到站 · 等候停靠再上车");return true; }
            if(InDanger()) { Announce("先脱离战斗再乘车");return true; }if(!Pay(20))return true;
            departure=station.Index;railDestination=(departure+(farther?2:1))%3;Aboard=true;MouseHeld=false;DeadEye=false;EyeMarks.Clear();Bullets.Clear();
            Player.X=RailPosition.X;Player.Y=RailPosition.Y;SaveFrontier(false);Announce("已上车 · 前往"+StationName(railDestination)+" · 马匹托运，到站自动下车");return true;
        }
        float MigrateRailClock(float clock,bool original) {
            float oldCycle=2*(StationWait+TripSeconds);if(original)clock=clock/84*oldCycle;
            float returnStart=StationWait*2+TripSeconds;
            if(clock<=returnStart)return clock;
            return returnStart+(clock-returnStart)/TripSeconds*(LegSeconds(1)+StationWait+LegSeconds(2));
        }
    }
}

