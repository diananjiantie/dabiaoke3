using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Xml;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        // 0 cell countdown, 1 escort, 2 last rescue window, 3 execution aftermath, 4 new intake.
        public int ExecutionPhase,ExecutionWaypoint,PrisonerGeneration=1,DigProgress;
        public float SentenceClock,ExecutionClock,DigFlash;
        public bool Captured,ArrestPending,EscapeHole;
        public readonly List<Body> ExecutionCrowd=new List<Body>();
        readonly PointF[] gallowsRoute={new PointF(3510,4840),new PointF(3550,5100),new PointF(3980,5100),new PointF(4160,4820),new PointF(4160,4740)};
        readonly PointF[] intakeRoute={new PointF(3550,5050),new PointF(3510,4840),new PointF(3510,4640)};
        public bool ExecutionGateOpen { get { return PrisonerFree||ExecutionPhase==1||ExecutionPhase==4; } }
        void ResetPrisonDrama() { ExecutionPhase=ExecutionWaypoint=DigProgress=0;PrisonerGeneration=1;SentenceClock=ExecutionClock=DigFlash=0;Captured=ArrestPending=EscapeHole=false;ExecutionCrowd.Clear(); }
        bool IsArrestOfficer(Body e) { return e.Police&&e.Guard!=1&&e.Guard!=4; }
        void CapturePlayer() {
            ArrestPending=false;Captured=true;EscapeHole=false;DigProgress=0;Mounted=false;Player.R=16;Player.HP=100;Player.X=3250;Player.Y=4680;
            Horse=new PointF(3180,5070);Wanted=0;EscapeClock=0;Aboard=Flying=false;railDestination=-1;DeadEye=false;EyeMarks.Clear();MouseHeld=false;
            BankOpening=WagonOpening=RobberyTime=MealTime=FishingTime=0;KeysDown.Clear();Bullets.Clear();Invulnerable=2;CameraX=Player.X;CameraY=Player.Y;
            SaveFrontier(false);Announce("你被捕了 · 连续点按 T 挖开左侧墙壁（30次）");
        }
        public void DigPrisonWall() {
            if(!Captured||Paused||State!="playing")return;
            DigProgress=Math.Min(30,DigProgress+1);DigFlash=.15f;Play("hit");
            if(DigProgress==30) {
                Captured=false;EscapeHole=true;Player.X=3120;Player.Y=4680;Invulnerable=3;KeysDown.Clear();RaiseWanted();RaiseWanted();
                SaveFrontier(false);Announce("墙壁挖通了 · 已越狱 · 马匹在监狱门外");
            }else if(DigProgress%5==0)SaveFrontier(false);
        }
        void CreateExecutionCrowd(int count) {
            ExecutionCrowd.Clear();for(int i=0;i<count;i++)ExecutionCrowd.Add(new Body { X=3930+i*75,Y=4930+(i%2)*50,HP=100,MaxHP=100,Angle=-1.5f });
        }
        void CreateExecutionEscort() {
            Enemies.RemoveAll(e=>e.Guard==5||e.Guard==6);
            for(int i=0;i<2;i++)Enemies.Add(new Body { X=PrisonerPosition.X+(i==0?-30:30),Y=PrisonerPosition.Y+65,HP=180,MaxHP=180,Police=true,Guard=5+i,Camp=-1,Speed=130,Shoot=1 });
        }
        void BeginExecutionEscort() {
            ExecutionPhase=1;ExecutionWaypoint=0;ExecutionClock=0;CreateExecutionEscort();CreateExecutionCrowd(random.Next(5,7));
            SaveFrontier(false);Announce("囚犯两分钟未获救 · 警察正押往绞刑台 · 仍可截救");
        }
        bool ExecutionGuardOrders(Body body,float dt) {
            if(body.Guard!=5&&body.Guard!=6)return false;
            if(Wanted>0&&Distance(body.X,body.Y,Player.X,Player.Y)<650)return false;
            if(ExecutionPhase==0)return true;
            PointF goal=new PointF(PrisonerPosition.X+(body.Guard==5?-30:30),PrisonerPosition.Y+70);
            float d=Distance(body.X,body.Y,goal.X,goal.Y);if(d>20) { float step=Math.Min(d,160*dt);body.Angle=Angle(body.X,body.Y,goal.X,goal.Y);Move(body,(goal.X-body.X)/d*step,(goal.Y-body.Y)/d*step);body.Step+=dt*7; }return true;
        }
        bool RescueExecutionPrisoner() {
            if(ExecutionPhase!=1&&ExecutionPhase!=2)return false;
            if(Distance(Player.X,Player.Y,PrisonerPosition.X,PrisonerPosition.Y)>170)return false;
            if(Enemies.Exists(e=>(e.Guard==5||e.Guard==6)&&e.HP>0)) { Announce("先击败两名押送警员，再靠近囚犯按 Q 解救");return true; }
            ExecutionPhase=0;SentenceClock=ExecutionClock=0;ExecutionCrowd.Clear();PrisonerFree=true;PrisonPaid=false;RaiseWanted();RaiseWanted();
            SaveFrontier(false);Announce("截救成功 · 护送至东南接应点领取 $180");return true;
        }
        void MoveSentencePrisoner(float dt,PointF[] route) {
            if(ExecutionWaypoint>=route.Length)return;PointF goal=route[ExecutionWaypoint];float d=Distance(PrisonerPosition.X,PrisonerPosition.Y,goal.X,goal.Y);
            if(d<7) { ExecutionWaypoint++;return; }
            Body actor=new Body { X=PrisonerPosition.X,Y=PrisonerPosition.Y,R=13 };float step=Math.Min(d,105*dt);Move(actor,(goal.X-actor.X)/d*step,(goal.Y-actor.Y)/d*step);PrisonerPosition=new PointF(actor.X,actor.Y);
        }
        void UpdatePrisonDrama(float dt) {
            DigFlash=Math.Max(0,DigFlash-dt);
            foreach(Body e in Enemies)if((e.Guard==5||e.Guard==6)&&e.HP>0&&Distance(e.X,e.Y,Player.X,Player.Y)>1400) { e.X=PrisonerPosition.X+(e.Guard==5?-30:30);e.Y=PrisonerPosition.Y+70; }
            if(Captured) { Wanted=0;MouseHeld=false;DeadEye=false; }
            if(PrisonerFree||PrisonPaid)return;
            if(ExecutionPhase==0) { SentenceClock=Math.Min(120,SentenceClock+dt);if(SentenceClock>=120)BeginExecutionEscort();return; }
            bool escort=Enemies.Exists(e=>(e.Guard==5||e.Guard==6)&&e.HP>0);
            if(ExecutionPhase==1) {
                if(!escort)return;MoveSentencePrisoner(dt,gallowsRoute);
                if(ExecutionWaypoint>=gallowsRoute.Length) { ExecutionPhase=2;ExecutionClock=15;SaveFrontier(false);Announce("囚犯已到绞刑台 · 还有15秒可以截救"); }
            }
            else if(ExecutionPhase==2) {
                if(!escort)return;ExecutionClock=Math.Max(0,ExecutionClock-dt);
                if(ExecutionClock==0) { ExecutionPhase=3;ExecutionClock=5;SaveFrontier(false);Announce("囚犯已被处决 · 新囚犯即将押入牢房"); }
            }
            else if(ExecutionPhase==3) {
                ExecutionClock=Math.Max(0,ExecutionClock-dt);if(ExecutionClock==0) {
                    ExecutionPhase=4;ExecutionWaypoint=0;PrisonerGeneration++;PrisonerPosition=new PointF(3550,5130);ExecutionCrowd.Clear();CreateExecutionEscort();SaveFrontier(false);
                }
            }
            else if(ExecutionPhase==4) {
                MoveSentencePrisoner(dt,intakeRoute);
                if(ExecutionWaypoint>=intakeRoute.Length) {
                    ExecutionPhase=0;SentenceClock=0;ExecutionWaypoint=0;Enemies.RemoveAll(e=>e.Guard==5||e.Guard==6);
                    PrisonGuardOneDown=PrisonGuardTwoDown=false;Enemies.RemoveAll(e=>e.Guard==2||e.Guard==3);SpawnSecurity(2);SpawnSecurity(3);SaveFrontier(false);Announce("新囚犯已押入牢房 · 新一轮120秒解救倒计时开始");
                }
            }
        }
        void SavePrisonDrama(Action<string,string> put) {
            put("captured",Captured.ToString());put("dig",DigProgress.ToString());put("hole",EscapeHole.ToString());put("sentence",Num(SentenceClock));put("executionPhase",ExecutionPhase.ToString());put("executionClock",Num(ExecutionClock));put("executionWaypoint",ExecutionWaypoint.ToString());put("prisonGeneration",PrisonerGeneration.ToString());put("crowdCount",ExecutionCrowd.Count.ToString());
            for(int i=0;i<ExecutionCrowd.Count;i++)put("crowdHP"+i,Num(ExecutionCrowd[i].HP));
        }
        float[] ReadPrisonDrama(XmlElement root) {
            if(root.GetAttribute("version")!="6")return null;
            float[] a=new float[15];a[0]=Flag(root,"captured")?1:0;a[1]=Value(root,"dig",0,30);a[2]=Flag(root,"hole")?1:0;a[3]=Value(root,"sentence",0,120);a[4]=Value(root,"executionPhase",0,4);a[5]=Value(root,"executionClock",0,15);a[6]=Value(root,"executionWaypoint",0,5);a[7]=Value(root,"prisonGeneration",1,1000000);a[8]=Value(root,"crowdCount",0,6);for(int i=0;i<(int)a[8];i++)a[9+i]=Value(root,"crowdHP"+i,0,100);return a;
        }
        void LoadPrisonDrama(float[] a) {
            if(a==null)return;Captured=a[0]>0;DigProgress=(int)a[1];EscapeHole=a[2]>0;SentenceClock=a[3];ExecutionPhase=(int)a[4];ExecutionClock=a[5];ExecutionWaypoint=(int)a[6];PrisonerGeneration=(int)a[7];CreateExecutionCrowd((int)a[8]);for(int i=0;i<ExecutionCrowd.Count;i++)ExecutionCrowd[i].HP=a[9+i];
            if(Captured) { Player.X=3250;Player.Y=4680;Mounted=false;Player.R=16;Wanted=0;DeadEye=false; }
        }
    }
}
