﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Xml;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        public readonly PointF MainlandAirfield=new PointF(10900,1300),IslandAirfield=new PointF(22000,3000);
        public float FlightHeading3 {get{return (float)Math.Atan2(IslandAirfield.Y-MainlandAirfield.Y,IslandAirfield.X-MainlandAirfield.X)+(FlightReturn?(float)Math.PI:0);}}
        static float EaseFlight3(float t){t=Clamp(t,0,1);return t*t*(3-2*t);}
        public float FlightAltitude3 {get{return Flying?420*EaseFlight3((FlightTime-1)/5)*EaseFlight3((23-FlightTime)/5):0;}}
        public float FlightPitch3 {get{return Flying?.10f*(float)Math.Sin(Math.PI*Clamp((FlightTime-1)/5,0,1))-.08f*(float)Math.Sin(Math.PI*Clamp((FlightTime-18)/5,0,1)):0;}}
        public bool Flying,FlightReturn,ReturnTicket;
        public float FlightTime,FishingTime,RobberyTime,RobberyCooldown,EventClock=120,EventLife;
        public int Fish,EventKind,EventsCompleted;
        public PointF FishingOrigin,EventPosition;
        public bool FishBiting;
        public readonly List<Body> EyeMarks=new List<Body>();
        Body eyeShotTarget;
        float EyeRange { get { return Weapon==WeaponType.Shotgun?280:Weapon==WeaponType.Revolver?850:1050; } }
        Body ScreenAimTarget(float radius) {
            Body found=null;float best=radius;
            foreach(Body e in Enemies)if(e.HP>0&&Distance(Player.X,Player.Y,e.X,e.Y)<=EyeRange&&ClearShot(Player.X,Player.Y,e.X,e.Y)) {
                PointF torso=Project(e.X,e.Y,35);float d=Distance(Mouse.X,Mouse.Y,torso.X,torso.Y);
                // Include the visible head and torso, rather than assuming the shooter's height.
                PointF head=Project(e.X,e.Y,58);d=Math.Min(d,Distance(Mouse.X,Mouse.Y,head.X,head.Y));
                if(d<best) { best=d;found=e; }
            }return found;
        }
        bool ResolveEyeShot() {
            Body target=eyeShotTarget;eyeShotTarget=null;if(target==null)return false;
            if(target.Police&&Wanted==0)RaiseWanted();
            float damage=(Weapon==WeaponType.Shotgun?154:WeaponRules.Damage(Weapon,true))*(1+GunUpgrade*.25f);
            target.HP=Math.Max(0,target.HP-damage);target.Hit=.2f;if(target.HP<=0)Kill(target);
            Cooldown=Weapon==WeaponType.Rifle?.3f:Weapon==WeaponType.Shotgun?.4f:.16f;
            Bullets.Add(new Bullet { X=target.X,Y=target.Y,LastX=Player.X,LastY=Player.Y,Friendly=true,VisualOnly=true,Life=.10f });
            Burst(target.X,target.Y,"#e5c380",6,90);Play("shot");Shake=3;return true;
        }
        bool EyeExecuting;
        public bool OnIsland { get { return Player.X>18000; } }
        bool PlayerTerrainBlocked(float x,float y,float r) {
            if(Captured&&(x<3235||x>3290||y<4540||y>4700))return true;
            if(SecurityBlocked(x,y,r))return true;
            if(Ocean(x,y,r))return true;
            foreach(Building b in Buildings)if(Distance(x,y,Clamp(x,b.X,b.X+b.W),Clamp(y,b.Y,b.Y+b.H))<r)return true;
            for(int i=0;i<2;i++)if(HouseStage[i]>=2&&new RectangleF(Plots[i].X-100-r,Plots[i].Y-140-r,200+2*r,140+2*r).Contains(x,y))return true;
            return false;
        }
        public bool Ocean(float x,float y,float r) {
            if(x>=55+r&&x<=12000-r&&y>=55+r&&y<=5945-r)return false;
            float dx=(x-22000)/(2600-r),dy=(y-3000)/(2300-r);
            return dx*dx+dy*dy>1;
        }
        void ConfigureAdventure() {
            Buildings.Add(new Building(9850,550,260,160,"saloon","WIND RIDGE"));
            Buildings.Add(new Building(10400,550,240,150,"store","GUNSMITH"));
            Buildings.Add(new Building(10780,900,300,160,"stable","AIRFIELD"));
            Buildings.Add(new Building(21700,2500,240,150,"saloon","EGRET ISLAND"));
            Buildings.Add(new Building(22200,2550,220,150,"store","FISH MARKET"));
            Services.Add(new WorldService("风蚀镇酒馆","saloon",9980,800,2));
            Services.Add(new WorldService("风蚀镇枪械铺","gun",10520,800,2));
            Services.Add(new WorldService("风蚀镇机场","airport",10900,1300,0));
            Services.Add(new WorldService("白鹭岛机场","airport",22000,3000,1));
            Services.Add(new WorldService("白鹭岛酒馆","saloon",21820,2750,3));
            Services.Add(new WorldService("白鹭岛鱼市","fish",22310,2800,3));
            Services.Add(new WorldService("碧水河鱼贩","fish",5670,3900,0));
            for(int i=0;i<12;i++)Residents.Add(new Body { ResidentId=36+i,X=i<6?9900+i*110:21600+(i-6)*130,Y=i<6?1050:3200,Speed=18,HP=100 });
        }
        void ResetAdventure() {
            ResetPrisonDrama();
            ResetRegionalLaw();
            ResetOutlaws();
            Flying=FlightReturn=ReturnTicket=FishBiting=EyeExecuting=false;
            FlightTime=FishingTime=RobberyTime=RobberyCooldown=EventLife=0;EventClock=120;
            Fish=EventKind=EventsCompleted=0;EyeMarks.Clear();
        }
        bool AdventureInteraction(WorldService s) {
            if(s==null) {
                if(EventKind>0&&Distance(Player.X,Player.Y,EventPosition.X,EventPosition.Y)<180) {
                    if(EventKind>=4) { Announce("击退全部劫匪，系统会自动结算拦截报酬");return true; }
                    if(EventKind==1) { Money+=25;EndEvent("帮助迷路旅人指路 · 获得 $25"); }
                    else if(EventKind==2) { if(!Pay(10))return true;Player.HP=Math.Min(100,Player.HP+20);EndEvent("资助受伤旅人 · 分享药品恢复20生命"); }
                    else { bool danger=false;foreach(Body e in Enemies)if(!e.Police&&e.HP>0&&Distance(e.X,e.Y,EventPosition.X,EventPosition.Y)<900)danger=true;if(danger)Announce("伏击者仍在附近 · 先救下商人");else { Money+=50;EndEvent("救下商人 · 获得 $50"); } }
                    SaveFrontier(false);return true;
                }return false;
            }
            if(s.Kind=="airport") {
                if(Wanted>0) { Announce("机场拒绝通缉旅客 · 先摆脱追捕");return true; }
                bool back=s.Index==1;
                if(!back&&!Pay(60))return true;
                // An outbound fare includes the return, so an empty wallet never strands the player.
                if(!back)ReturnTicket=true;
                Flying=true;FlightReturn=back;FlightTime=0;Mounted=false;MouseHeld=false;DeadEye=false;EyeMarks.Clear();EyeExecuting=false;FishingTime=0;Bullets.Clear();
                PointF start=back?IslandAirfield:MainlandAirfield;Player.X=start.X;Player.Y=start.Y+70;Player.Angle=FlightHeading3;ResetFollowCamera3();
                SaveFrontier(false);Announce(back?"飞往风蚀镇 · 返程免费":"飞往白鹭岛 · $60 含返程及马匹托运");return true;
            }
            if(s.Kind=="fish") { if(Fish==0)Announce("没有鱼可卖 · 河岸或岛岸按 G 钓鱼");else { int cash=Fish*15;Money+=cash;Fish=0;SaveFrontier(false);Announce("出售全部鲜鱼 · 获得 $"+cash); }return true; }
            return false;
        }
        public bool FishingShore(float x,float y) {
            if(x<12000)return Math.Abs(x-RiverCenter(y))>=RiverWidth(y)+20&&Math.Abs(x-RiverCenter(y))<RiverWidth(y)+210;
            float dx=(x-22000)/2600,dy=(y-3000)/2300,v=dx*dx+dy*dy;
            return v>.73f&&v<.98f;
        }
        public void FishAction() {
            if(Captured)return;
            if(Flying||Aboard||MealTime>0||Mounted) { Announce("下马后在岸边按 G 钓鱼");return; }
            if(FishingTime>0) { if(FishBiting) { Fish++;Play("pickup");Announce("钓到一条鲜鱼 · 鱼市售价 $15"); }else Announce("收竿太早，鱼儿跑了");FishingTime=0;FishBiting=false;SaveFrontier(false);return; }
            if(!FishingShore(Player.X,Player.Y)) { Announce("靠近碧水河岸或白鹭岛海岸再按 G");return; }
            if(InDanger()) { Announce("先脱离战斗再钓鱼");return; }
            FishingOrigin=new PointF(Player.X,Player.Y);FishingTime=Rand(3,6);FishBiting=false;MouseHeld=false;Announce("已抛竿 · 等待咬钩提示，再按 G 收竿");
        }
        public void StartRobbery() {
            if(Captured)return;
            if(Flying||MealTime>0||RobberyTime>0)return;
            if(!Aboard&&RobWagon())return;
            if(RobberyCooldown>0) { Announce("车厢已被洗劫 · "+(int)RobberyCooldown+" 秒后补货");return; }
            if(!Aboard&&Distance(Player.X,Player.Y,RailPosition.X,RailPosition.Y)>300) { Announce("靠近列车或乘车后按 X 抢劫");return; }
            RobberyTime=5;Aboard=true;railDestination=RailNextStop;departure=(railDestination+2)%3;
            RaiseWanted();RaiseWanted();Announce("正在撬开列车保险箱 · 5 秒后取走赃款");
        }
        void EndEvent(string text) { EventKind=0;EventLife=0;EventClock=Rand(120,180);EventsCompleted++;Announce(text); }
        public void SpawnAdventureEvent(int kind) {
            if(Flying||Aboard||EventKind!=0)return;
            if(Enemies.Count>36)return;
            if(kind>=4) { if(SpawnHeistEvent(kind))return;kind=3; }
            float x=Player.X+350,y=Player.Y+180;
            if(Blocked(x,y,25)) { x=Player.X-300;y=Player.Y; }
            if(Blocked(x,y,25))return;
            EventKind=kind;EventPosition=new PointF(x,y);EventLife=100;
            if(kind==3)for(int i=0;i<5;i++) { float bx=x+150+i*55,by=y+120;if(!Blocked(bx,by,16))Enemies.Add(new Body { X=bx,Y=by,Camp=-2,HP=180,MaxHP=180,Speed=150,Shoot=.7f }); }
            Announce(kind==1?"偶遇 · 迷路旅人需要指路（黄色菱形）":kind==2?"偶遇 · 受伤旅人求助（黄色菱形）":"偶遇 · 商人遭遇帮派伏击（黄色菱形）");
        }
        public void MarkDeadEye() {
            if(Captured)return;
            if(!IsFrontier||State!="playing"||Paused||!DeadEye||Flying||Aboard||EyeExecuting)return;
            Body target=ScreenAimTarget(50);
            if(target==null)return;
            if(EyeMarks.Contains(target)) { EyeMarks.Remove(target);return; }
            if(EyeMarks.Count>=Ammo) { Announce("标记数量不能超过当前弹药 · R 换弹");return; }
            EyeMarks.Add(target);Play("eye");
        }
        bool TakeMarkedAim(ref PointF aim) {
            eyeShotTarget=null;
            if(!DeadEye) { EyeMarks.Clear();EyeExecuting=false;return false; }
            EyeMarks.RemoveAll(e=>e.HP<=0||!Enemies.Contains(e)||Distance(Player.X,Player.Y,e.X,e.Y)>EyeRange||!ClearShot(Player.X,Player.Y,e.X,e.Y));
            if(EyeMarks.Count==0) { EyeExecuting=false;eyeShotTarget=ScreenAimTarget(27);if(eyeShotTarget!=null)aim=new PointF(eyeShotTarget.X,eyeShotTarget.Y);return eyeShotTarget!=null; }
            Body target=EyeMarks[0];EyeMarks.RemoveAt(0);EyeExecuting=EyeMarks.Count>0;eyeShotTarget=target;aim=new PointF(target.X,target.Y);return true;
        }
        void UpdateAdventure(float dt) {
            UpdateOutlaws(dt);
            if(!DeadEye) { EyeExecuting=false;EyeMarks.Clear(); }
            if(EyeExecuting&&EyeMarks.Count>0&&Ammo>0)Fire();
            if(Flying) {
                FlightTime+=dt;PointF from=FlightReturn?IslandAirfield:MainlandAirfield,to=FlightReturn?MainlandAirfield:IslandAirfield;
                float f=EaseFlight3(FlightTime/24);Player.Angle=FlightHeading3;Player.X=from.X+(to.X-from.X)*f;Player.Y=from.Y+(to.Y-from.Y)*f+70;Horse=new PointF(Player.X,Player.Y);Invulnerable=2;
                if(f>=1) { Flying=false;FlightTime=0;Player.Y+=60;Horse=new PointF(Player.X+65,Player.Y);if(FlightReturn)ReturnTicket=false;ResetFollowCamera3();SaveFrontier(false);Announce("飞机抵达 · 马匹已卸下 · Q 乘机返航"); }
            }
            RobberyCooldown=Math.Max(0,RobberyCooldown-dt);
            if(RobberyTime>0) { RobberyTime=Math.Max(0,RobberyTime-dt);if(RobberyTime==0) { Money+=100;RobberyCooldown=120;SaveFrontier(false);Announce("列车抢劫成功 · 获得 $100 · 警方正在追捕"); } }
            if(FishingTime>0) {
                if(Distance(Player.X,Player.Y,FishingOrigin.X,FishingOrigin.Y)>25||InDanger()||Mounted) { FishingTime=0;FishBiting=false;Announce("移动或战斗打断了钓鱼"); }
                else { FishingTime-=dt;if(FishingTime<=0) { if(!FishBiting) { FishBiting=true;FishingTime=2;Play("pickup");Announce("咬钩了！现在按 G 收竿"); }else { FishBiting=false;FishingTime=0;Announce("错过咬钩，鱼儿跑了"); } } }
            }
            Enemies.RemoveAll(e=>e.Guard==0&&e.LawDistrict<0&&(e.Camp==-2||e.Police&&Wanted==0)&&Distance(e.X,e.Y,Player.X,Player.Y)>2200);
            if(EventKind>0) { EventLife-=dt;if(EventLife<=0) { EventKind=0;EventLife=0;EventClock=Rand(120,180); } }
            else if(!Flying&&!Aboard) { EventClock-=dt;if(EventClock<=0) { EventClock=120;SpawnAdventureEvent(Distance(Player.X,Player.Y,BankDoor.X,BankDoor.Y)<1400?4:WagonActive&&Distance(Player.X,Player.Y,WagonPosition.X,WagonPosition.Y)<1400?5:random.Next(1,4)); } }
            // Keep a bounded local patrol. Far actors are still sleeping, as in the existing world.
        }
        // Police and bandits exchange actual projectiles; only Arthur's bullets earn bounty.
        bool UpdateFaction(Body body,float dt) {
            Body target=null;float best=body.Police&&Wanted>0?Distance(body.X,body.Y,Player.X,Player.Y):900;
            foreach(Body other in Enemies)if(other!=body&&other.HP>0&&other.Police!=body.Police) { float d=Distance(body.X,body.Y,other.X,other.Y);if(d<best&&ClearShot(body.X,body.Y,other.X,other.Y)) { best=d;target=other; } }
            if(target==null)return RaidOrders(body,dt)||body.Police&&(Wanted==0||body.LawDistrict>=0&&body.LawDistrict!=LocalDistrict);
            body.Angle=Angle(body.X,body.Y,target.X,target.Y);body.Shoot-=dt;body.Step+=dt*6;
            if(best>400)Move(body,(float)Math.Cos(body.Angle)*body.Speed*dt,(float)Math.Sin(body.Angle)*body.Speed*dt);
            if(body.Shoot<=0) { Bullets.Add(new Bullet { X=body.X+(float)Math.Cos(body.Angle)*28,Y=body.Y+(float)Math.Sin(body.Angle)*28,VX=(float)Math.Cos(body.Angle)*450,VY=(float)Math.Sin(body.Angle)*450,Life=2,Damage=25,Faction=body.Police?1:2 });body.Shoot=1.2f; }
            return true;
        }
        void SaveAdventure(Action<string,string> put) {
            put("fish",Fish.ToString());put("flying",Flying.ToString());put("flightReturn",FlightReturn.ToString());put("returnTicket",ReturnTicket.ToString());put("flightTime",Num(FlightTime));
            put("robTime",Num(RobberyTime));put("robCooldown",Num(RobberyCooldown));put("eventKind",EventKind.ToString());put("eventX",Num(EventPosition.X));put("eventY",Num(EventPosition.Y));put("eventLife",Num(EventLife));put("eventClock",Num(EventClock));put("eventsDone",EventsCompleted.ToString());
        }
        float[] ReadAdventure(XmlElement e) {
            if(e.GetAttribute("version")!="3"&&e.GetAttribute("version")!="4"&&e.GetAttribute("version")!="5"&&e.GetAttribute("version")!="6")return new float[14];
            return new[]{Value(e,"fish",0,100000),Flag(e,"flying")?1:0,Flag(e,"flightReturn")?1:0,Flag(e,"returnTicket")?1:0,Value(e,"flightTime",0,24),Value(e,"robTime",0,5),Value(e,"robCooldown",0,120),Value(e,"eventKind",0,5),Value(e,"eventX",0,26000),Value(e,"eventY",0,6000),Value(e,"eventLife",0,120),Value(e,"eventClock",0,180),Value(e,"eventsDone",0,100000),0f};
        }
        void LoadAdventure(float[] a) { Fish=(int)a[0];Flying=a[1]>0;FlightReturn=a[2]>0;ReturnTicket=a[3]>0;FlightTime=a[4];RobberyTime=a[5];RobberyCooldown=a[6];EventKind=(int)a[7];EventPosition=new PointF(a[8],a[9]);EventLife=a[10];EventClock=a[11]>0?a[11]:35;EventsCompleted=(int)a[12]; }
    }
}
