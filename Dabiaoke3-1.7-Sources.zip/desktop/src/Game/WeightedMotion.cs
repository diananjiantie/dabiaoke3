﻿using System;
using System.Drawing;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        public bool CameraLocked3=false;
        public float VelocityX3,VelocityY3,MotionSpeed3,MotionBlend3;
        bool motionMounted3;
        public void ToggleCameraLock3(){CameraLocked3=!CameraLocked3;Announce(CameraLocked3?"视角锁定 · 角色随镜头转向":"自由视角 · 鼠标环绕，移动或开枪时角色转向");}
        public void ResetMotion3(){VelocityX3=VelocityY3=MotionSpeed3=MotionBlend3=0;motionMounted3=Mounted;}
        public float MoveWeighted3(float dx,float dy,float dt){
            if(motionMounted3!=Mounted){ResetMotion3();motionMounted3=Mounted;}
            if(Level==3||IsFrontier&&(Captured||Flying||Aboard||MealTime>0)){ResetMotion3();return 0;}
            float input=(float)Math.Sqrt(dx*dx+dy*dy),speed=Mounted?(DashTime>0?740:435):(DashTime>0?550:210),tx=input>0?dx/input*speed:0,ty=input>0?dy/input*speed:0;
            float ax=tx-VelocityX3,ay=ty-VelocityY3,change=(float)Math.Sqrt(ax*ax+ay*ay),limit=dt*(Mounted?(input>0?580:800):(input>0?2400:6500));
            if(!Mounted && input>0 && VelocityX3*tx+VelocityY3*ty<0){VelocityX3=VelocityY3=0;ax=tx;ay=ty;change=speed;}
            if(change>limit){ax*=limit/change;ay*=limit/change;}VelocityX3+=ax;VelocityY3+=ay;
            float x=Player.X,y=Player.Y;Move(Player,VelocityX3*dt,VelocityY3*dt);float mx=Player.X-x,my=Player.Y-y;
            if(Math.Abs(mx)<.001f)VelocityX3=0;if(Math.Abs(my)<.001f)VelocityY3=0;
            float moved=(float)Math.Sqrt(mx*mx+my*my);MotionSpeed3=moved/Math.Max(.001f,dt);MotionBlend3+=(Math.Min(1,MotionSpeed3/(Mounted?435:210))-MotionBlend3)*Math.Min(1,dt*10);
            Player.Step+=moved*(Mounted?.035f:.065f);return moved;
        }
        void TurnBody3(float dx,float dy,float dt){if(IsFrontier&&Flying){Player.Angle=FlightHeading3;return;}float target=Player.Angle;if(MouseHeld||DeadEye||Level==3||CameraLocked3&&dx*dx+dy*dy<1){PointF aim=Unproject(Mouse.X,Mouse.Y,Mounted?43:22);target=Angle(Player.X,Player.Y,aim.X,aim.Y);}else if(dx*dx+dy*dy>.1f)target=(float)Math.Atan2(dy,dx);float delta=(float)Math.Atan2(Math.Sin(target-Player.Angle),Math.Cos(target-Player.Angle));Player.Angle+=Clamp(delta,-dt*(Mounted?4.5f:14f),dt*(Mounted?4.5f:14f));}
    }
}
