using System;
using System.Collections.Generic;
using System.Drawing;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        void DrawRiver() {
            foreach(float margin in new[]{50f,0f,-55f}) {
                PointF[] edges=new PointF[242];for(int i=0;i<=120;i++) { float y=i*50,c=RiverCenter(y),w=RiverWidth(y)+margin;edges[i]=Project(c-w,y,0);edges[241-i]=Project(c+w,y,0); }
                Poly(edges,margin>0?"#a9af79":margin==0?"#477e89":"#548f9c");
            }
        }
        void AddOutlawScene(List<DrawItem> scene) {
            if(VisibleWorld(2600,4680,750))scene.Add(new DrawItem(4400,delegate { DrawBankInterior(); }));
            if(VisibleWorld(3550,4800,750))scene.Add(new DrawItem(4500,delegate { DrawPrisonInterior(); }));
            if(WagonActive&&VisibleWorld(WagonPosition.X,WagonPosition.Y,350))scene.Add(new DrawItem(WagonPosition.Y+40,delegate { DrawBankWagon(); }));
            if(!PrisonPaid&&VisibleWorld(PrisonerPosition.X,PrisonerPosition.Y,100))scene.Add(new DrawItem(PrisonerPosition.Y+5,delegate { DrawExecutionPrisoner(); }));
            foreach(Body civilian in ExecutionCrowd) { Body spectator=civilian;if(spectator.HP>0&&VisibleWorld(spectator.X,spectator.Y,100))scene.Add(new DrawItem(spectator.Y,delegate { DrawResident(spectator); })); }
            if(VisibleWorld(4160,4780,300))scene.Add(new DrawItem(4790,delegate {
                Box(4050,4660,220,140,22,"#a3865b","#634d35","#856b46");
                foreach(int x in new[]{4080,4240}) { PLine(Project(x,4700,20),Project(x,4700,175),"#685137",10); }
                PLine(Project(4060,4700,175),Project(4260,4700,175),"#806440",13);
                PLine(Project(4160,4700,174),Project(4160,4700,105),"#cfb685",3);PointF rope=Project(4160,4700,93);using(Pen pen=new Pen(C("#cfb685"),3))g.DrawEllipse(pen,rope.X-9,rope.Y-12,18,25);
                for(int i=0;i<3;i++)Box(4090,4800+i*18,90,18,18-i*5,"#ad9367","#665438","#8a704d");
                PointF label=Project(4160,4820,0);Text("绞刑台",label.X,label.Y+14,15,"#dfc59a",true,true);
            }));
        }
        void RoomFloor(float x,float y,float width,float depth,string color) {
            WorldRect(x,y,width,depth,color);for(float yy=y;yy<y+depth;yy+=35)PLine(Project(x,yy,0),Project(x+width,yy,0),"#8b795b",1);
        }
        void DrawBankInterior() {
            RoomFloor(2250,4400,700,500,"#b99b70");
            WorldRect(2500,4570,210,300,"#80553e");
            foreach(RectangleF wall in securityWalls)if(wall.X<3000)Box(wall.X,wall.Y,wall.Width,wall.Height,wall.Width>100&&wall.Height>40?35:55,"#c6b391","#8b795b","#a49272");
            // Teller counters, ledgers, lamps, safe wheels and stacks of cash.
            foreach(int x in new[]{2320,2770}) {
                Box(x,4670,45,30,43,"#f0ddad","#9e8962","#c8b387");
                PointF lamp=Project(x+65,4680,53);Ellipse(lamp.X,lamp.Y,11,6,"#ddc98c");Line(lamp.X,lamp.Y,lamp.X,lamp.Y-18,"#594e37",3);
            }
            foreach(int x in new[]{2310,2790}) {
                Box(x,4445,85,60,72,"#63716b","#36433f","#48554e");PointF wheel=Project(x+45,4510,42);Ellipse(wheel.X,wheel.Y,12,12,"#a5afa0");Line(wheel.X-8,wheel.Y,wheel.X+8,wheel.Y,"#414d44",3);
                if(!BankLooted)for(int i=0;i<3;i++)Box(x+100,4450+i*20,35,15,15,"#b6bd7c","#6b744b","#899459");
            }
            PointF label=Project(2590,4410,85);Text("石桥银行 · 柜台 / 金库",label.X,label.Y,19,"#ffe4ae",true,true);
        }
        void DrawPrisonInterior() {
            RoomFloor(3200,4500,720,500,"#999b8c");
            foreach(RectangleF wall in securityWalls)if(wall.X>=3200) {
                if(EscapeHole&&wall.X==3200&&wall.Width==20) { Box(3200,4500,20,140,55,"#a7aa9c","#686f65","#858c7e");Box(3200,4710,20,290,55,"#a7aa9c","#686f65","#858c7e");continue; }
                Box(wall.X,wall.Y,wall.Width,wall.Height,wall.Height<20&&wall.Y==4720?10:55,"#a7aa9c","#686f65","#858c7e");
            }
            for(int x=3245;x<3880;x+=23)if(!(ExecutionGateOpen&&x>3460&&x<3560))PLine(Project(x,4728,0),Project(x,4728,72),"#454e48",3);
            PLine(Project(3240,4728,72),Project(3880,4728,72),"#515b51",4);
            foreach(int x in new[]{3250,3370,3780}) { Box(x,4560,70,100,18,"#807a66","#51584f","#6c7162");Box(x,4560,70,25,24,"#cdc9ab","#848a78","#aaa98c");PointF bucket=Project(x+85,4630,6);Ellipse(bucket.X,bucket.Y,12,8,"#5b655b"); }
            Box(3270,4848,65,30,62,"#b9a781","#746a53","#9b8e6b");
            PointF label=Project(3550,4510,85);Text("石桥监狱 · 值班桌 / 铁栏牢房",label.X,label.Y,19,"#e5e2c9",true,true);
        }
        void DrawBankWagon() {
            PointF pos=WagonPosition,next=Along(WagonRoute,WagonProgress+5);float a=Angle(pos.X,pos.Y,next.X,next.Y),cx=(float)Math.Cos(a),cy=(float)Math.Sin(a);
            Func<float,float,float,PointF> p=(side,front,z)=>Project(pos.X+front*cx-side*cy,pos.Y+front*cy+side*cx,z);
            DrawHorse(pos.X+115*cx,pos.Y+115*cy,a,Elapsed*8,true);
            PLine(p(-20,20,20),p(-20,110,20),"#785e3e",4);PLine(p(20,20,20),p(20,110,20),"#785e3e",4);
            foreach(int side in new[]{-1,1})foreach(int axle in new[]{-42,37}) { PointF wheel=p(side*52,axle,16);Ellipse(wheel.X,wheel.Y,18,22,"#443f32");Ellipse(wheel.X,wheel.Y,11,15,"#a38b5c"); }
            Poly(new[]{p(-45,-65,20),p(45,-65,20),p(45,55,20),p(-45,55,20)},"#725336");
            Poly(new[]{p(-45,-65,20),p(-45,-65,85),p(-45,55,85),p(-45,55,20)},"#845739");
            Poly(new[]{p(45,-65,20),p(45,-65,85),p(45,55,85),p(45,55,20)},"#986944");
            Poly(new[]{p(-45,-65,85),p(45,-65,85),p(45,55,85),p(-45,55,85)},"#c4a46d");
            PointF label=p(0,0,120);Text(WagonLooted?"空钱箱":WagonOpening>0?"开箱 "+WagonOpening.ToString("0.0"):"银行运钞马车 · X",label.X,label.Y,16,"#ffe5a6",true,true);
        }
        void OutlawMap(RectangleF r,bool labels) {
            PointF bank=MapPoint(r,2600,4700),prison=MapPoint(r,3550,4780);Rect(bank.X-5,bank.Y-5,10,10,"#f5d26f");Rect(prison.X-5,prison.Y-5,10,10,"#bec7ca");
            if(labels) { Text("石桥镇 · 银行",bank.X-40,bank.Y+35,14,"#f3d893",true,true);Text("监狱 / 绞刑台",prison.X+40,prison.Y+60,13,"#dbe0ce",true,true); }
            if(WagonActive) { PointF wagon=MapPoint(r,WagonPosition.X,WagonPosition.Y);Rect(wagon.X-5,wagon.Y-5,10,10,"#ffad45"); }
        }
    }
}
