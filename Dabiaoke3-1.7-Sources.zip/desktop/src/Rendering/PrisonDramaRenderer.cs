using System;
using System.Drawing;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        void DrawExecutionPrisoner() {
            if(ExecutionPhase!=3) { DrawResident(new Body { X=PrisonerPosition.X,Y=PrisonerPosition.Y,Step=PrisonerFree||ExecutionPhase==1||ExecutionPhase==4?Elapsed*6:0 });return; }
            // Non-graphic aftermath silhouette aligned with the existing rope.
            PointF p=Project(4160,4700,62);
            Line(p.X-5,p.Y-10,p.X-6,p.Y+20,"#545b4f",5);Line(p.X+5,p.Y-10,p.X+6,p.Y+20,"#545b4f",5);
            Rect(p.X-10,p.Y-40,20,30,"#7c8264");Line(p.X-12,p.Y-32,p.X-13,p.Y-7,"#8b8e6d",4);Line(p.X+12,p.Y-32,p.X+13,p.Y-7,"#8b8e6d",4);Ellipse(p.X,p.Y-49,8,9,"#bd9d79");
        }
        void DrawPrisonDramaOverlay() {
            if(Captured) {
                RectA(330,250,620,98,"#15201f",235);Text("被捕入狱 · 连续点按 T 挖墙",640,263,23,"#f2d4a1",true,true);
                Rect(380,306,520,12,"#514b3c");Rect(380,306,520*DigProgress/30,12,"#d8b26e");Text(DigProgress+" / 30 · 长按不计连续次数 · F5 保存进度",640,325,13,"#ded2b5",false,true);
            }
            else if(!PrisonPaid&&!PrisonerFree&&Player.X<4700&&Player.X>2700&&Player.Y>4000) {
                string status=ExecutionPhase==0?"牢房囚犯 · "+(int)Math.Ceiling(120-SentenceClock)+"秒后押送":ExecutionPhase==1?"囚犯正在押往绞刑台 · 击败押送警员后 Q 截救":ExecutionPhase==2?"绞刑台 · 最后 "+(int)Math.Ceiling(ExecutionClock)+" 秒 · Q 截救":ExecutionPhase==3?"行刑结束 · 新囚犯即将押入":"正在押入新囚犯";
                RectA(330,250,620,40,"#192521",225);Text(status,640,260,17,"#eed2a2",true,true);
            }
            if(!Use3D&&(Captured||EscapeHole)) {
                PointF p=Project(3210,4675,27);int cracks=Captured?DigProgress:30;
                if(EscapeHole) { Ellipse(p.X,p.Y,23,28,"#283329");Text("逃生洞口",p.X,p.Y-50,13,"#f0d6aa",true,true); }
                else {
                    for(int i=0;i<cracks/5;i++)Line(p.X-18+i*5,p.Y-25+i%2*12,p.X+8-i*3,p.Y+20-i*4,"#463d30",2);
                    if(DigFlash>0) { Rect(p.X-14,p.Y+10,6,5,"#bcad8f");Rect(p.X+12,p.Y+17,5,5,"#d0bea0"); }
                }
            }
        }
    }
}

