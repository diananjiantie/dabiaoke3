using System;
using System.Drawing;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        void DrawAdventureGround() {
            if(CameraX>11000) {
                WorldRect(12000,0,14000,6000,"#396e83");
                int left=(int)(CameraX-1300)/240*240,top=(int)(CameraY-1000)/180*180;
                for(int y=top;y<CameraY+1100;y+=180)for(int x=left;x<CameraX+1300;x+=240) {
                    if(x<12000)continue;
                    float dx=(x+120-22000)/2600,dy=(y+90-3000)/2300,d=dx*dx+dy*dy;
                    if(d>1.08f) { PointF p=Project(x+(float)Math.Sin(Elapsed*.8+x)*15,y,0);Line(p.X,p.Y,p.X+45,p.Y,"#6198a8",2); }
                }
                foreach(float scale in new[]{1f,.95f}) { PointF[] coast=new PointF[72];for(int i=0;i<72;i++) { double a=i*Math.PI*2/72;coast[i]=Project(22000+(float)Math.Cos(a)*2600*scale,3000+(float)Math.Sin(a)*2300*scale,0); }Poly(coast,scale==1?"#d6c18e":"#7f935b"); }
            }
            WorldRect(9650,420,1300,760,"#b7a17c");
            WorldRect(10550,1180,1100,260,"#d1bd8c");
            WorldRect(21400,2900,1500,260,"#d1bd8c");
            for(int i=0;i<10;i++) { WorldRect(10580+i*105,1300,45,12,"#f6e8b4");WorldRect(21440+i*140,3020,50,12,"#f6e8b4"); }
            if(CameraX>18000)for(int y=1200;y<5000;y+=360)for(int x=20000;x<24200;x+=380) {
                if(Ocean(x,y,150)||!VisibleWorld(x,y,160)||SafeTown(x,y))continue;
                PointF p=Project(x,y,0);g.DrawImageUnscaled(actorSprites[9000],(int)p.X-55,(int)p.Y-150);
            }
        }
        public PointF FlyerPoint(float x,float y,float span,float forward,bool returning) {
            float dx=IslandAirfield.X-MainlandAirfield.X,dy=IslandAirfield.Y-MainlandAirfield.Y;
            float length=(float)Math.Sqrt(dx*dx+dy*dy),sign=returning?-1:1;
            dx=dx/length*sign;dy=dy/length*sign;
            // Rotate in world space before the isometric projection: wings remain perpendicular to travel.
            return new PointF(x+forward*dx-span*dy,y+forward*dy+span*dx);
        }
        void DrawFlyer(float x,float y,bool flying) {
            float height=flying?40+(float)Math.Sin(Math.PI*Clamp(FlightTime/24,0,1))*45:12;
            bool returning=flying?FlightReturn:x>18000;
            Func<float,float,float,PointF> p=(span,forward,z)=> { PointF world=FlyerPoint(x,y,span,forward,returning);return Project(world.X,world.Y,height+z); };
            PointF shadow=Project(x,y,0);
            PointF[] shade=new PointF[4];int k=0;foreach(PointF corner in new[]{new PointF(-175,-40),new PointF(175,-40),new PointF(175,45),new PointF(-175,45)}) { PointF w=FlyerPoint(x,y,corner.X,corner.Y,returning);shade[k++]=Project(w.X,w.Y,0); }Poly(shade,"#315764");
            // Skids, forward canard booms and rear rudder frame share the same longitudinal axis.
            foreach(int side in new[]{-1,1}) {
                PLine(p(side*25,-105,-6),p(side*25,145,-6),"#6d5136",4);
                PLine(p(side*25,130,18),p(side*25,-95,5),"#9b7b50",3);
                PLine(p(side*25,-30,8),p(side*16,-135,22),"#8a6c45",3);
            }
            foreach(int z in new[]{0,55}) {
                Poly(new[]{p(-175,-38,z),p(175,-38,z),p(175,42,z),p(-175,42,z)},"#e9dfb4");
                for(int rib=-150;rib<=150;rib+=30)PLine(p(rib,-38,z),p(rib,42,z),"#b9a277",1);
                PLine(p(-175,42,z),p(175,42,z),"#846849",3);
                PLine(p(-175,-38,z),p(175,-38,z),"#a0875e",2);
                if(z==0) {
                    // Prone pilot and small engine on the lower wing.
                    PLine(p(-18,-18,9),p(-18,15,9),"#594838",9);
                    PointF head=p(-18,22,13);Ellipse(head.X,head.Y,7,6,"#bd956b");
                    Poly(new[]{p(5,-12,14),p(32,-12,14),p(32,17,14),p(5,17,14)},"#59615b");
                    for(int strut=-150;strut<=150;strut+=75) {
                        PLine(p(strut,-34,0),p(strut,-34,55),"#806441",3);
                        PLine(p(strut,38,0),p(strut,38,55),"#806441",3);
                        if(strut<150)PLine(p(strut,-34,0),p(strut+75,-34,55),"#a38f6a",1);
                    }
                }
            }
            // Twin forward elevator surfaces make the nose visually distinct from the tail.
            foreach(int z in new[]{12,30})Poly(new[]{p(-60,113,z),p(60,113,z),p(60,145,z),p(-60,145,z)},"#f0e6c5");
            foreach(int side in new[]{-1,1}) {
                PLine(p(side*50,130,12),p(side*50,130,30),"#8a6c45",2);
                Poly(new[]{p(side*15,-115,7),p(side*15,-145,7),p(side*15,-145,42),p(side*15,-115,42)},"#d9ceaa");
                // Propellers rotate in the span/vertical plane, perpendicular to thrust.
                float a=flying?Elapsed*35*side:.8f,ds=(float)Math.Cos(a)*36,dz=(float)Math.Sin(a)*36;
                PLine(p(side*88,-65,25),p(side*88,-36,25),"#6c6451",3);
                PLine(p(side*88-ds,-65,25-dz),p(side*88+ds,-65,25+dz),"#725035",5);
            }
            if(!flying)Text("1903 · 莱特飞行器",shadow.X,shadow.Y+65,14,"#fff0c2",true,true);
        }
        void DrawAdventureOverlay() {
            if(!Use3D)foreach(Body e in EyeMarks) { PointF p=Project(e.X,e.Y,70);Line(p.X-9,p.Y-9,p.X+9,p.Y+9,"#ff4f43",3);Line(p.X+9,p.Y-9,p.X-9,p.Y+9,"#ff4f43",3); }
            if(!Use3D&&EventKind>0&&VisibleWorld(EventPosition.X,EventPosition.Y,100)) {
                PointF p=Project(EventPosition.X,EventPosition.Y,0);
                DrawResident(new Body { X=EventPosition.X,Y=EventPosition.Y });
                Poly(new[]{new PointF(p.X,p.Y-110),new PointF(p.X+10,p.Y-100),new PointF(p.X,p.Y-90),new PointF(p.X-10,p.Y-100)},"#ffda68");
                Text(EventKind==1?"Q 帮助指路 +$25":EventKind==2?"Q 资助 $10":"Q 营救商人 +$50",p.X,p.Y-135,14,"#ffe3a1",true,true);
            }
            if(!Use3D&&FishingTime>0) { PointF p=Project(Player.X,Player.Y,25);Line(p.X,p.Y,p.X+90,p.Y-45,"#d8b47c",3);Line(p.X+90,p.Y-45,p.X+145,p.Y+20,"#e5e0c7",1); }
            RectA(26,286,259,58,"#182620",215);Text("鲜鱼 "+Fish+" 条 · 偶遇完成 "+EventsCompleted,40,294,14,"#f0d6a2");
            Text(DeadEye?"右键标记 "+EyeMarks.Count+" · 左键执行":"G 钓鱼 · X 抢列车 · E 死眼",40,319,13,"#e1c39d");
            string status=Flying?"莱特飞行器 · "+(FlightReturn?"返回风蚀镇":"前往白鹭岛")+" · "+(24-FlightTime).ToString("0")+" 秒":RobberyTime>0?"正在撬保险箱 · "+RobberyTime.ToString("0.0")+" 秒":FishingTime>0?(FishBiting?"咬钩！立即按 G 收竿":"等待咬钩 · 移动会取消"):OnIsland?"白鹭岛 · 仅限飞机往返":Player.Y<1600&&Player.X>9500?"风蚀镇 · 北部机场":EventKind>0?"附近有黄色偶遇标记 · Q 互动":"自由探索 · 骑马渡河 · 徒步翻山";
            RectA(350,205,580,35,"#182620",210);Text(status,640,211,17,"#ffe1a4",true,true);
        }
    }
}

