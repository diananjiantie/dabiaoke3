using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Media;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        void CreateTerrain() {
            if(IsFrontier) { terrain=new Bitmap(2,2);return; }
            terrain=new Bitmap(WorldW,WorldH);
            Random r=new Random(71);
            using(Graphics q=Graphics.FromImage(terrain)) {
                q.Clear(C("#ac8551"));
                using(Brush b=new SolidBrush(C("#b9935f")))q.FillRectangle(b,550,0,830,WorldH);
                using(Brush b=new SolidBrush(C("#ba9460")))q.FillRectangle(b,0,480,WorldW,520);
                using(Brush dark=new SolidBrush(Color.FromArgb(27,91,65,37)))using(Brush light=new SolidBrush(Color.FromArgb(25,242,209,153)))for(int i=0;i<18000;i++) {
                    int x=r.Next(WorldW),y=r.Next(WorldH);
                    q.FillRectangle(i%2==0?dark:light,x,y,r.Next(1,5),r.Next(1,3));
                }
                using(Pen p=new Pen(Color.FromArgb(35,89,64,37),2)) {
                    foreach(int x in new[] {
                        730,755,1170,1195
                    })q.DrawBezier(p,x,0,x+25,450,x-30,1000,x+30,WorldH);
                    foreach(int y in new[] {
                        645,670,860,885
                    })q.DrawBezier(p,0,y,600,y+20,1500,y-20,WorldW,y);
                }
                for(int i=0;i<180;i++) {
                    int x=r.Next(WorldW),y=r.Next(WorldH);
                    if(x>540&&x<1390&&y>440&&y<1030)continue;
                    using(Brush b=new SolidBrush(C("#897343")))q.FillEllipse(b,x,y,r.Next(4,14),r.Next(2,6));
                }
                if(Level>=2) {
                    q.Clear(C("#697c79"));
                    using(Brush road=new SolidBrush(C("#a69d82")))q.FillRectangle(road,0,600,WorldW,300);
                    using(Pen rail=new Pen(C("#343f43"),7))using(Pen sleeper=new Pen(C("#685444"),10)) {
                        for(int y=80;y<WorldH-70;y+=42)q.DrawLine(sleeper,890,y,1000,y);
                        q.DrawLine(rail,905,60,905,WorldH-60);
                        q.DrawLine(rail,985,60,985,WorldH-60);
                    }
                    using(Brush rock=new SolidBrush(C("#526560")))for(int i=0;i<220;i++) {
                        int x=r.Next(WorldW),y=r.Next(WorldH);
                        if(y>580&&y<920)continue;
                        q.FillEllipse(rock,x,y,18,9);
                    }
                    using(Brush pine=new SolidBrush(C("#284c42")))for(int x=100;x<WorldW-100;x+=145)foreach(int y in new[] {
                        140,1370
                    })q.FillPolygon(pine,new[] {
                        new Point(x,y-70),new Point(x-30,y),new Point(x+30,y)
                    });
                }
                using(Pen p=new Pen(C("#685134"),5))q.DrawRectangle(p,52,52,WorldW-104,WorldH-104);
            }
        }
        Font Font(float size,bool bold) {
            string key=size+":"+bold;
            Font f;
            if(!fonts.TryGetValue(key,out f)) {
                f=new Font("Microsoft YaHei UI",size,bold?FontStyle.Bold:FontStyle.Regular,GraphicsUnit.Pixel);
                fonts[key]=f;
            }
            return f;
        }
        SolidBrush Brush(string color,int alpha=255) {
            int key=Color.FromArgb(alpha,C(color)).ToArgb();
            SolidBrush b;
            if(!brushes.TryGetValue(key,out b)) {
                b=new SolidBrush(Color.FromArgb(key));
                brushes.Add(key,b);
            }
            return b;
        }
        void Text(string s,float x,float y,float size,string color,bool bold=false,bool center=false) {
            string key=s+"|"+size+"|"+color+"|"+bold;
            Bitmap image;
            if(!textSprites.TryGetValue(key,out image)) {
                if(textSprites.Count>=384) {
                    foreach(Bitmap old in textSprites.Values)old.Dispose();
                    textSprites.Clear();
                }
                Font f=Font(size,bold);
                SizeF measure=g.MeasureString(s,f);
                image=new Bitmap((int)Math.Ceiling(measure.Width)+2,(int)Math.Ceiling(measure.Height)+2,System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
                using(Graphics q=Graphics.FromImage(image)) {
                    q.TextRenderingHint=System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
                    q.DrawString(s,f,Brush(color),PointF.Empty);
                }
                textSprites.Add(key,image);
            }
            g.DrawImageUnscaled(image,(int)Math.Round(center?x-image.Width/2f:x),(int)Math.Round(y));
        }
        void Rect(float x,float y,float w,float h,string c) {
            g.FillRectangle(Brush(c),x,y,w,h);
        }
        void RectA(float x,float y,float w,float h,string c,int alpha) {
            g.FillRectangle(Brush(c,alpha),x,y,w,h);
        }
        void Ellipse(float x,float y,float rx,float ry,string c,int alpha=255) {
            g.FillEllipse(Brush(c,alpha),x-rx,y-ry,rx*2,ry*2);
        }
        void Line(float x,float y,float xx,float yy,string c,float width=1,int alpha=255) {
            string key=c+"|"+width+"|"+alpha;
            Pen p;
            if(!pens.TryGetValue(key,out p)) {
                p=new Pen(Color.FromArgb(alpha,C(c)),width);
                p.StartCap=LineCap.Round;
                p.EndCap=LineCap.Round;
                pens.Add(key,p);
            }
            g.DrawLine(p,x,y,xx,yy);
        }
        void PLine(PointF a,PointF b,string c,float width=1,int alpha=255) {
            Line(a.X,a.Y,b.X,b.Y,c,width,alpha);
        }
        void Poly(PointF[] points,string c,int alpha=255) {
            g.FillPolygon(Brush(c,alpha),points);
        }
        void Box(float x,float y,float w,float d,float z,string top,string side,string front,int alpha=255) {
            PointF b=Project(x+w,y,0),c=Project(x+w,y+d,0),f=Project(x,y+d,0),at=Project(x,y,z),bt=Project(x+w,y,z),ct=Project(x+w,y+d,z),ft=Project(x,y+d,z);
            Poly(new[] {
                b,c,ct,bt
            },side,alpha);
            Poly(new[] {
                f,c,ct,ft
            },front,alpha);
            Poly(new[] {
                at,bt,ct,ft
            },top,alpha);
        }
        void DrawBuilding(Building o,bool forceFade=false) {
            float x=o.X,y=o.Y,w=o.W,h=o.H,z=o.Kind=="crate"?32:o.Kind=="barrel"?35:95;
            Poly(new[] {
                Project(x+w,y,0),Project(x+w+z*.7f,y+z*.55f,0),Project(x+w+z*.7f,y+h+z*.55f,0),Project(x+z*.7f,y+h+z*.55f,0),Project(x,y+h,0)
            },"#3e2d19",65);
            if(o.Kind=="crate") {
                Box(x,y,w,h,32,"#c09255","#74502d","#986936");
                for(int i=10;i<48;i+=12)PLine(Project(x+i,y,32),Project(x+i,y+h,32),"#725033");
                PLine(Project(x+4,y+h,4),Project(x+w-4,y+h,28),"#d0a16a",4);
                return;
            }
            if(o.Kind=="barrel") {
                PointF p=Project(x+19,y+19,0);
                Rect(p.X-18,p.Y-35,36,35,"#8f6139");
                Ellipse(p.X,p.Y,18,10,"#805230");
                foreach(int z1 in new[] {
                    7,27
                }) {
                    Ellipse(p.X,p.Y-z1,19,10,"#403a31");
                    Ellipse(p.X,p.Y-z1-4,18,9,"#9b7043");
                }
                Ellipse(p.X,p.Y-35,18,10,"#c49b61");
                Ellipse(p.X,p.Y-35,13,6,"#a67c49");
                return;
            }
            PointF pp=Project(Player.X,Player.Y,35),left=Project(x,y,140),right=Project(x+w,y+h,0);
            bool occluded=forceFade||(State!="intro"&&Player.Y<y+h&&pp.X>left.X-15&&pp.X<right.X+15&&pp.Y>left.Y-10&&pp.Y<right.Y+12);
            int a=occluded?100:255;
            Box(x-10,y+h,w+20,34,8,"#a88250","#66492f","#80603c",a);
            Box(x,y,w,h,z,"#ae8050","#63442f",o.Kind=="sheriff"?"#a38b63":"#ac7947",a);
            for(int zz=12;zz<95;zz+=13)PLine(Project(x,y+h,zz),Project(x+w,y+h,zz),"#63462e",2,a/2);
            PointF r1=Project(x-8,y+h/2,z+42),r2=Project(x+w+8,y+h/2,z+42);
            Poly(new[] {
                Project(x-10,y-8,z),Project(x+w+10,y-8,z),r2,r1
            },"#b4814e",a);
            Poly(new[] {
                r1,r2,Project(x+w+10,y+h+9,z),Project(x-10,y+h+9,z)
            },o.Kind=="sheriff"?"#826f54":"#78543b",a);
            for(int i=8;i<w;i+=18) {
                PLine(Project(x+i,y-8,z),Project(x+i,y+h/2,z+42),"#d4a063",1,a/2);
                PLine(Project(x+i,y+h/2,z+42),Project(x+i,y+h+9,z),"#33281d",1,a/2);
            }
            PointF door=Project(x+w*.5f-18,y+h,0);
            RectA(door.X,door.Y-59,36,59,"#392d24",a);
            RectA(door.X+3,door.Y-54,13,51,"#5c4030",a);
            RectA(door.X+20,door.Y-54,13,51,"#664532",a);
            foreach(float xx in new[] {
                x+25,x+w-62
            }) {
                PointF win=Project(xx,y+h,58);
                RectA(win.X-3,win.Y-3,40,32,"#d0a773",a);
                RectA(win.X,win.Y,34,26,"#2f4145",a);
                Line(win.X+17,win.Y,win.X+17,win.Y+26,"#ab8658",2,a);
            }
            if(o.Kind=="home") { Box(x+20,y+25,25,25,126,"#98876b","#5c493b","#7c6350",a);DrawOilLamp(x+w*.5f+34,y+h+3,a);return; }
            PointF sign=Project(x+w/2,y+h+2,81);
            RectA(sign.X-77,sign.Y-13,154,25,"#322820",a);
            if(!occluded)Text(o.Label,sign.X,sign.Y-9,14,"#f4dab0",false,true);
            Box(x+w-55,y+25,25,25,126,"#98876b","#5c493b","#7c6350",a);
        }
        void DrawHorse(float x,float y,float angle,float step,bool ridden) {
            PointF p=Project(x,y,0);
            float dir=(float)Math.Cos(angle)>=0?1:-1;
            GraphicsState save=g.Save();
            g.TranslateTransform(p.X,p.Y);
            g.ScaleTransform(dir,1);
            Ellipse(12,6,43,12,"#322619",75);
            float stride=(float)Math.Sin(step)*8;
            Line(-18,-23,-22+stride,-2,"#563726",6);
            Line(16,-24,20-stride,-2,"#563726",6);
            Line(-9,-23,-12-stride,-3,"#835231",6);
            Line(23,-24,27+stride,-3,"#835231",6);
            foreach(float xx in new[] {
                -22+stride,20-stride,-12-stride,27+stride
            })Line(xx-2,0,xx+4,0,"#30271e",5);
            Ellipse(0,-30,32,17,"#99633c");
            Ellipse(2,-34,28,11,"#b07b49");
            Poly(new[] {
                new PointF(18,-35),new PointF(23,-64),new PointF(35,-64),new PointF(34,-29)
            },"#a56b3f");
            Ellipse(34,-63,14,9,"#b7824d");
            Ellipse(44,-60,9,6,"#8a5735");
            Line(28,-66,27,-77,"#78502f",4);
            Line(35,-68,37,-78,"#956137",4);
            Line(21,-38,22,-64,"#3a2b23",5);
            Line(-29,-31,-42,-43,"#392b22",5);
            Ellipse(38,-65,2,2,"#201e1b");
            Line(42,-63,44,-56,"#473426",2);
            Rect(-13,-43,27,12,"#473a2b");
            Ellipse(0,-43,16,5,"#654831");
            Line(-8,-41,-8,-19,"#422f23",2);
            Line(11,-40,11,-19,"#422f23",2);
            if(ridden)Line(38,-57,0,-48,"#3c2b20",1.5f);
            g.Restore(save);
            if(!ridden) {
                Text("亚瑟的马",p.X,p.Y-97,13,"#f1dab0",false,true);
                Text("靠近按 F 上马",p.X,p.Y-79,12,"#dcc29a",false,true);
            }
        }
        void DrawCowboy(Body b,bool player) {
            bool riding=player&&Mounted&&!(IsFrontier&&Aboard)||!player&&Level==3;
            if(riding) {
                if(Level==3&&!player) {
                    int hd=((int)Math.Round(b.Angle/(Math.PI*2)*16)+32)%16,hp=((int)Math.Floor(b.Step/(Math.PI*2)*4)%4+4)%4;
                    PointF h=Project(b.X,b.Y,0);
                    g.DrawImageUnscaled(actorSprites[10000+hd*4+hp],(int)h.X-96,(int)h.Y-135);
                }
                else DrawHorse(b.X,b.Y,b.Angle,b.Step,true);
            }
            PointF p=Project(b.X,b.Y,player&&IsFrontier&&Aboard?95:player&&Level==3?35:riding?34:0);
            float scale=b.Elite?1.35f:1;
            if(!riding)Ellipse(p.X+14*scale,p.Y+5*scale,25*scale,9*scale,"#302115",80);
            if(player&&Invulnerable>0&&!(IsFrontier&&Aboard)&&((int)(Elapsed*16)%2==0))return;
            int kind=player?(Level==3?0:Weapon==WeaponType.Shotgun?6:Weapon==WeaponType.Rifle?5:0):b.Police?7:b.Hit>0?(b.Elite?4:3):b.Elite?2:1;
            int direction=((int)Math.Round(b.Angle/(Math.PI*2)*32)+64)%32,phase=((int)Math.Floor(b.Step/(Math.PI*2)*4)%4+4)%4;
            Bitmap image=actorSprites[kind*128+direction*4+phase];
            g.DrawImageUnscaled(image,(int)Math.Round(p.X-image.Width/2f),(int)Math.Round(p.Y-image.Height+12));
            if(player&&Level==3) {
                PointF muzzle=Project(b.X+(float)Math.Cos(b.Angle)*55,b.Y+(float)Math.Sin(b.Angle)*55,55);
                PointF mount=Project(b.X,b.Y,49);
                Line(mount.X,mount.Y,muzzle.X,muzzle.Y,"#222b2f",12);
                Line(mount.X-16,mount.Y+25,mount.X,mount.Y,"#4c5050",6);
            }
            float labelY=p.Y-77*scale;
            if(IsFrontier&&!player)Ellipse(p.X,labelY+6,4,4,b.Police?"#76a8ea":"#ed554b");
            else Text(player?"亚瑟":Level==3?"平克顿侦探":b.Elite?(Level==2?"麦卡":"肺结核 · 首领"):"肺结核",p.X,labelY,player?14:12,player?"#fff0c9":"#f5d9b2",false,true);
            if(!player&&(b.HP<b.MaxHP||b.Elite)) {
                Rect(p.X-19,labelY+21,38,3,"#4c342a");
                Rect(p.X-19,labelY+21,38*b.HP/b.MaxHP,3,"#e57242");
            }
        }
        void CacheActors() {
            for(int kind=0;kind<8;kind++)for(int direction=0;direction<32;direction++)for(int phase=0;phase<4;phase++) {
                bool player=kind==0||kind==5||kind==6,elite=kind==2||kind==4;
                float scale=elite?1.35f:1;
                Bitmap image=new Bitmap(elite?128:96,elite?128:100,System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
                using(Graphics q=Graphics.FromImage(image)) {
                    g=q;
                    q.SmoothingMode=SmoothingMode.AntiAlias;
                    q.TranslateTransform(image.Width/2,image.Height-12);
                    q.ScaleTransform(scale,scale);
                    float stride=(float)Math.Sin(phase*Math.PI/2)*3,a=(float)(direction*Math.PI*2/32);
                    string coat=kind==7?"#334b76":player?"#426d81":kind>=3?"#f9cf87":elite?"#3b3030":"#934835";
                    Line(-5,-18,-7+stride,-3,"#34342e",7);
                    Line(5,-18,7-stride,-3,"#424039",7);
                    Ellipse(-6+stride,-2,7,3,"#2c251f");
                    Ellipse(8-stride,-2,7,3,"#2c251f");
                    Poly(new[] {
                        new PointF(-11,-35),new PointF(10,-35),new PointF(13,-15),new PointF(-12,-15)
                    },coat);
                    Rect(-8,-20,18,4,"#593d29");
                    Rect(-1,-20,4,4,"#cca158");
                    float gx=(float)Math.Cos(a)*25+(float)Math.Sin(a)*6,gy=(float)Math.Sin(a)*15.5f;
                    Line(5,-30,gx*.65f,-22+gy*.65f,"#ae8256",6);
                    Line(gx*.65f,-22+gy*.65f,gx,-22+gy,"#292b29",5);
                    Line(gx*.7f,-24+gy*.7f,gx,-24+gy,"#aba395",1.5f);
                    if(kind==5) {
                        Line(-gx*.35f,-22-gy*.35f,gx*.75f,-22+gy*.75f,"#714a2d",7);
                        Line(gx*.65f,-23+gy*.65f,gx*1.55f,-23+gy*1.55f,"#252b2c",4);
                        Line(-5,-29,gx*.5f,-20+gy*.5f,"#c49462",4);
                    }
                    if(kind==6) { Line(-gx*.2f,-22-gy*.2f,gx*.65f,-22+gy*.65f,"#886039",7);Line(gx*.55f,-23+gy*.55f,gx*1.15f,-23+gy*1.15f,"#212b30",7);Line(gx*.55f,-25+gy*.55f,gx*1.15f,-25+gy*1.15f,"#bdc0a6",1); }
                    Ellipse(0,-40,8,9,"#d5a174");
                    Rect(-7,-37,14,4,"#815b39");
                    Ellipse(0,-47,17,6,player?"#bc9255":"#604c34");
                    Ellipse(0,-50,10,7,player?"#9a713c":"#7f6846");
                    Rect(-9,-49,18,3,"#483825");
                }
                actorSprites.Add(kind*128+direction*4+phase,image);
            }
        }
        void DrawRoute() {
            PointF target=route[Checkpoint],p=Project(target.X,target.Y,0);
            float pulse=(float)Math.Sin(Elapsed*4)*5;
            using(Pen pen=new Pen(Color.FromArgb(180,C("#f0c975")),3))g.DrawEllipse(pen,p.X-55-pulse,p.Y-22-pulse/2,110+pulse*2,44+pulse);
            Line(p.X,p.Y-12,p.X,p.Y-90,"#e1b266",3);
            Poly(new[] {
                new PointF(p.X,p.Y-90),new PointF(p.X+37,p.Y-81),new PointF(p.X,p.Y-70)
            },"#ebc079");
            Text(Checkpoint==2?"日落镇入口":"骑行路标 "+(Checkpoint+1)+" / 3",p.X,p.Y-119,16,"#ffdda0",true,true);
            PointF a=Project(Player.X,Player.Y,0);
            using(Pen pen=new Pen(Color.FromArgb(95,C("#ecca80")),2)) {
                pen.DashStyle=DashStyle.Dash;
                g.DrawLine(pen,a,p);
            }
            if(p.X<50||p.X>1230||p.Y<180||p.Y>650) {
                float xx=Clamp(p.X,75,1205),yy=Clamp(p.Y,215,600);
                Ellipse(xx,yy,23,23,"#302518",210);
                Text("➤",xx,yy-17,27,"#efc270",true,true);
                Text(((int)Distance(Player.X,Player.Y,target.X,target.Y)).ToString()+" m",xx,yy+28,13,"#efdab6",false,true);
            }
        }
        public void Render(Graphics graphics) {
            g=graphics;
            g.SmoothingMode=SmoothingMode.AntiAlias;
            g.TextRenderingHint=System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            Rect(0,0,Width,Height,"#665035");
            if(State=="intro") {
                CameraX=850;
                CameraY=700;
            }
            GraphicsState world=g.Save();
            if(Shake>0&&State=="playing"&&!Paused)g.TranslateTransform(Rand(-Shake,Shake),Rand(-Shake,Shake));
            PointF groundOrigin=Project(0,0,0);
            g.CompositingMode=CompositingMode.SourceCopy;
            if(IsFrontier) { g.CompositingMode=CompositingMode.SourceOver;DrawFrontierGround(); }
            else Blit(ground,(int)Math.Round(groundOrigin.X),(int)Math.Round(groundOrigin.Y));
            g.CompositingMode=CompositingMode.SourceOver;
            foreach(Corpse c in corpses) {
                PointF p=Project(c.X,c.Y,0);
                Ellipse(p.X,p.Y,23,7,"#523c29",100);
            }
            if(State=="playing"&&Chapter=="ride")DrawRoute();
            foreach(Pickup d in drops) {
                PointF p=Project(d.X,d.Y,8+(float)Math.Sin(Elapsed*4)*3);
                Ellipse(p.X,p.Y+12,24,10,"#cde098",65);
                Rect(p.X-10,p.Y-12,20,20,"#ead8af");
                Rect(p.X-3,p.Y-9,6,14,"#963f2b");
                Rect(p.X-7,p.Y-5,14,6,"#963f2b");
            }
            List<DrawItem> scene=drawList;
            scene.Clear();
            scene.AddRange(staticDrawItems);
            if(IsFrontier)AddFrontierScene(scene);
            if(State=="intro") {
                Body demo=new Body {
                    X=1150,Y=780,Angle=-.3f
                };
                scene.Add(new DrawItem(780,delegate {
                    DrawHorse(demo.X,demo.Y,demo.Angle,0,false);
                }));
                Body a=new Body {
                    X=1120,Y=680,Angle=-.2f
                };
                scene.Add(new DrawItem(a.Y,delegate {
                    DrawCowboy(a,true);
                }));
            }
            else {
                if(Level!=3&&!Mounted&&HorseHP>0&&!(IsFrontier&&Flying))scene.Add(new DrawItem(Horse.Y,delegate {
                    DrawHorse(Horse.X,Horse.Y,0,0,false);
                }));
                foreach(Body e in Enemies) {
                    PointF p=Project(e.X,e.Y,0);
                    if(p.X< -90||p.X>Width+90||p.Y< -20||p.Y>Height+120)continue;
                    Body actor=e;
                    scene.Add(new DrawItem(e.Y,delegate {
                        DrawCowboy(actor,false);
                    }));
                }
                scene.Add(new DrawItem(IsFrontier&&Aboard?Player.Y+45:Level==3?800:Player.Y,delegate {
                    if(IsFrontier&&Flying)DrawFlyer(Player.X,Player.Y,true);else DrawCowboy(Player,true);
                }));
            }
            if(Level==3) {
                DrawPassingGrass();
                for(int i=0;i<18;i++) {
                    int item=i;
                    float depth=RoadsideY(item,680);
                    scene.Add(new DrawItem(depth,delegate {
                        DrawPassingTree(item);
                    }));
                }
                scene.Add(new DrawItem(801,delegate {
                    DrawAlly(-1,"河西阿");
                    DrawAlly(1,"约翰马斯顿");
                }));
                for(int i=0;i<3;i++) {
                    int car=i;
                    scene.Add(new DrawItem(480+i*145,delegate {
                        float old=TrainY;
                        TrainY=480+car*290;
                        DrawTrainCar(car);
                        TrainY=old;
                    }));
                }
                float offset=(Elapsed*240)%90;
                for(int y=-100;y<1600;y+=90) {
                    PointF a=Project(860,y+offset,0),b=Project(880,y+offset+24,0);
                    PLine(a,b,"#c6c9b8",3);
                }
            }
            if(Level==2&&TrainActive)for(int i=0;i<3;i++) {
                int car=i;
                scene.Add(new DrawItem(TrainY-i*145,delegate {
                    DrawTrainCar(car);
                }));
            }
            scene.Sort(delegate(DrawItem a,DrawItem b) {
                return a.Depth.CompareTo(b.Depth);
            });
            foreach(DrawItem d in scene)d.Draw();
            foreach(Bullet b in Bullets) {
                float z=b.Friendly?(Mounted?43:22):22;
                PointF p=Project(b.X,b.Y,z),last=Project(b.LastX,b.LastY,z);
                string color=b.Friendly?"#ffe3a0":"#ff6037";
                if(b.LastX!=0)PLine(last,p,color,b.Friendly?2:3);
                Ellipse(p.X,p.Y,b.Friendly?3:5,b.Friendly?2:4,color);
            }
            foreach(Particle pt in particles) {
                PointF p=Project(pt.X,pt.Y,18);
                using(Brush brush=new SolidBrush(Color.FromArgb((int)(Clamp(pt.Life/pt.MaxLife,0,1)*255),pt.Color)))g.FillRectangle(brush,p.X,p.Y,pt.Size,pt.Size);
            }
            if(DeadEye) {
                PointF aim=Unproject(Mouse.X,Mouse.Y,Mounted?43:22);
                Body screenTarget=IsFrontier?ScreenAimTarget(27):null;
                foreach(Body e in Enemies)if(IsFrontier?e==screenTarget:Distance(e.X,e.Y,aim.X,aim.Y)<110&&ClearShot(Player.X,Player.Y,e.X,e.Y)) {
                    PointF p=Project(e.X,e.Y,27);
                    using(Pen pen=new Pen(C("#ffe6b6"),2))g.DrawEllipse(pen,p.X-24,p.Y-24,48,48);
                    Line(p.X-7,p.Y-7,p.X+7,p.Y+7,"#ffdfaf",2);
                    Line(p.X+7,p.Y-7,p.X-7,p.Y+7,"#ffdfaf",2);
                }
            }
            if(IsFrontier)DrawNeighborhoodNight();
            g.Restore(world);
            g.FillRectangle(topShade,0,0,Width,190);
            g.FillRectangle(bottomShade,0,580,Width,220);
            if(DeadEye) {
                if(RenderBackend!="GPU")RectA(0,0,Width,Height,"#8c250d",55);
                if(!IsFrontier) { Text("死 神 之 眼",Width/2,180,25,"#ffe1ac",true,true);Text("无限使用 · E 关闭",Width/2,218,13,"#f4c991",false,true); }
            }
            Header();
            if(State=="intro")Intro();
            else if(IsFrontier)FrontierHUD();
            else HUD();
            if(ShowFps) {
                RectA(1060,194,183,27,"#211a16",215);
                Text(DisplayFps+" FPS · "+RenderBackend,1073,199,13,"#d8e6a2");
            }
            if(State=="playing"&&!Paused) {
                if(NoticeTime>0)Text(Notice,Width/2,270,24,"#ffe1aa",true,true);
                if(MouseInside)Crosshair();
            }
            if(Paused&&!WorldMap)EndPanel(true);
            else if(State=="won"||State=="lost")EndPanel(false);
            if(WorldMap)DrawFrontierMap();
            if(ShowCredits) {
                RectA(0,0,Width,Height,"#1c130d",248);
                Text("关于制作人员",Width/2,235,40,"#f4e3bf",true,true);
                Text("制作人员 · 共两人",Width/2,310,18,"#c8b69a",false,true);
                Text("不死战狼",Width/2,365,30,"#dba55b",true,true);
                Text("点按",Width/2,420,30,"#dba55b",true,true);
                Button(HomeButton,"返回选关   ·   ESC",true);
            }
        }
        void Header() {
            Text("✦",35,26,31,"#dba55b",true);
            Text("大镖客3",80,27,23,"#f4e3bf",true);
            Text("THE FRONTIER III",81,59,10,"#c2aa85");
            Text((IsFrontier?"大世界 · 荒野与远海":Level==3?"第三关 · 列车追击":Level==2?"第二关 · 冷杉矿场":"第一关 · 日落镇"),922,40,13,"#d1ba98");
            Button(new RectangleF(1090,29,80,35),Muted?"音效 关":"音效 开",false);
            Button(new RectangleF(1183,29,55,35),Paused?"继续":"暂停",false);
        }
        public RectangleF HomeButton {
            get {
                return new RectangleF(500,605,280,42);
            }
        }
        public RectangleF LevelButton(int level) {
            return new RectangleF(108+(level-1)*320,495,295,65);
        }
        public RectangleF MainButton {
            get {
                return new RectangleF(108,584,270,58);
            }
        }
        public RectangleF ResumeButton {
            get {
                return new RectangleF(500,533,280,58);
            }
        }
        void Button(RectangleF r,string label,bool primary) {
            RectA(r.X,r.Y,r.Width,r.Height,primary?"#dba55b":"#211a16",primary?255:160);
            using(Pen pen=new Pen(C(primary?"#f2c985":"#766348")))g.DrawRectangle(pen,r.X,r.Y,r.Width,r.Height);
            Text(label,r.X+r.Width/2,r.Y+(r.Height-(primary?25:18))/2,primary?19:13,primary?"#24190e":"#f4e3bf",primary,true);
        }
        void Intro() {
            using(LinearGradientBrush b=new LinearGradientBrush(new Rectangle(0,0,Width,Height),Color.FromArgb(243,23,18,15),Color.FromArgb(25,23,18,15),0f))g.FillRectangle(b,0,0,Width,Height);
            Text("NEW AUSTIN  /  1899",108,155,13,"#dba55b");
            if(NoticeTime>0)Text(Notice,108,112,15,"#f4d89d");
            Line(108,203,152,203,"#dba55b");
            Text("策马穿过黄沙，枪声就在前方。",172,192,15,"#c1a785");
            Text("大镖客",103,236,84,"#f4e3bf",true);
            Text("3",375,236,84,"#dba55b",true);
            Text("THE FRONTIER III",109,347,17,"#bda98b");
            Text("你是亚瑟。穿越日落镇与矿场，再登上列车阻击平克顿侦探。",109,413,17,"#d0bea3");
            Text("八发长枪，无限死眼。这一次，把命运握在手里。",109,447,17,"#d0bea3");
            for(int level=1;level<=3;level++)Button(LevelButton(level),(SelectedLevel==level?"✓ ":"")+level+" · "+(level==1?"日落镇":level==2?"冷杉矿场":"列车 · 20 波 / 无尽"),SelectedLevel==level);
            Button(MainButton,"开始所选关卡   →",true);
            Button(new RectangleF(410,584,220,58),"关于制作人员",false);
            Button(new RectangleF(660,584,50,58),"−",false);
            Text("灵敏度 "+Sensitivity.ToString("0.0")+"×",735,602,17,"#f4e3bf");
            Button(new RectangleF(920,584,50,58),"+",false);
            Line(109,647,603,647,"#796344",1);
            Button(new RectangleF(108,662,310,58),"4 · 开放世界 / 继续旅程",true);
            Button(new RectangleF(438,662,180,58),"F9 · 读取存档",false);
            Text("自由荒野 · 飞机海岛 · 列车抢劫 · 钓鱼偶遇",650,682,15,"#c3ad8a");
            Text("1 / 2 / 3 选关 · Enter 开始 · F11 全屏 · F3 帧率 · 灵敏度自动保存",109,746,13,"#a38e72");
        }
        float RoadsideY(int index,float speed) {
            return ((index*197+Elapsed*speed)%2200)-350;
        }
        void DrawPassingTree(int index) {
            float x=index%2==0?430+(index%3)*90:1250+(index%3)*105;
            PointF p=Project(x,RoadsideY(index,680),0);
            Bitmap tree=actorSprites[9000];
            if(p.X< -130||p.X>Width+130||p.Y< -30||p.Y>Height+180)return;
            g.DrawImageUnscaled(tree,(int)p.X-55,(int)p.Y-150);
        }
        void DrawPassingGrass() {
            for(int i=0;i<48;i++) {
                float x=i%2==0?580+(i%4)*53:1100+(i%5)*62;
                PointF p=Project(x,RoadsideY(i,880),0);
                if(p.Y<0||p.Y>Height)continue;
                g.DrawImageUnscaled(actorSprites[9001],(int)p.X-18,(int)p.Y-20);
            }
        }
        void DrawAlly(int side,string name) {
            PointF world=AllyPosition(side),target=Unproject(Mouse.X,Mouse.Y,22),p=Project(world.X,world.Y,35);
            float a=Angle(world.X,world.Y,target.X,target.Y);
            int direction=((int)Math.Round(a/(Math.PI*2)*32)+64)%32;
            Bitmap sprite=actorSprites[(side<0?5:0)*128+direction*4];
            g.DrawImageUnscaled(sprite,(int)(p.X-sprite.Width/2),(int)(p.Y-sprite.Height+12));
            Text(name,p.X,p.Y-83,13,"#d5e6b0",true,true);
            if(AllyCooldown>.18f) {
                PointF tip=Project(world.X+(float)Math.Cos(a)*36,world.Y+(float)Math.Sin(a)*36,55);
                Ellipse(tip.X,tip.Y,5,4,"#ffdf83");
            }
        }
        void CacheRoadside() {
            Graphics previousGraphics=g;
            for(int d=0;d<16;d++)for(int phase=0;phase<4;phase++) {
                Bitmap horseImage=new Bitmap(192,160,System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
                using(Graphics q=Graphics.FromImage(horseImage)) {
                    g=q;
                    q.SmoothingMode=SmoothingMode.AntiAlias;
                    q.TranslateTransform(96-Width/2,135-Height/2);
                    DrawHorse(0,0,(float)(d*Math.PI*2/16),(float)(phase*Math.PI/2),true);
                }
                actorSprites[10000+d*4+phase]=horseImage;
            }
            g=previousGraphics;
            Bitmap tree=new Bitmap(110,160,System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            using(Graphics q=Graphics.FromImage(tree)) {
                q.FillEllipse(Brush("#3e4b3b"),12,142,88,15);
                q.FillRectangle(Brush("#70523a"),50,85,12,65);
                foreach(int y in new[] {
                    8,38,68
                })q.FillPolygon(Brush(y==38?"#426e48":"#315c41"),new[] {
                    new Point(55,y),new Point(7,y+72),new Point(103,y+72)
                });
            }
            actorSprites[9000]=tree;
            Bitmap grass=new Bitmap(38,25,System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            using(Graphics q=Graphics.FromImage(grass))using(Pen pen=new Pen(C("#a1b56c"),3)) {
                q.DrawLine(pen,18,24,3,8);
                q.DrawLine(pen,18,24,16,2);
                q.DrawLine(pen,18,24,31,6);
            }
            actorSprites[9001]=grass;
        }
        void DrawTrainCar(int index) {
            float y=TrainY-index*145;
            if(Level==3&&index==2) {
                Box(810,y-130,270,150,35,"#a48050","#393e3d","#79603e");
                return;
            }
            PointF center=Project(945,y,0);
            if(center.Y< -200||center.Y>Height+220)return;
            Box(890,y-120,110,130,index==0?64:49,index==0?"#2e383d":"#72533e","#20292d","#473a32");
            Box(902,y-100,86,85,72,index==0?"#454f50":"#b08a57","#393e3d","#79603e");
            if(index==0) {
                Box(928,y-20,30,28,100,"#3c4142","#222b2e","#303638");
                PointF light=Project(945,y+11,40);
                Ellipse(light.X,light.Y,10,7,"#ffda85");
            }
        }
        void HUD() {
            if(Level!=3)Text("马匹  "+(int)HorseHP+" / 200",37,184,12,"#d8d7b4");
            if(Level!=3) {
                Rect(37,206,205,6,"#303734");
                Rect(37,206,205*HorseHP/200,6,"#8aad83");
            }
            if(Level==2)Text(TrainActive?"列车通过 · 避开铁轨":"下班列车  "+Math.Ceiling(15-TrainClock)+" 秒",37,230,13,"#ebce9d");
            Text("亚瑟",37,104,20,"#f4e3bf",true);
            Text(Level==3?"机枪手":Mounted?"骑乘中":"徒步",102,108,13,"#cbb38f");
            RectA(37,140,205,6,"#24190e",190);
            Rect(37,140,205*Player.HP/100,6,"#d26547");
            Text(((int)Player.HP)+" / 100",37,154,12,"#dbc6a6");
            if(Chapter=="ride") {
                Text("序章 · 荒野骑行",Width/2,98,17,"#ebce9d",true,true);
                Text("沿金色路标抵达日落镇  "+Math.Min(3,Checkpoint+1)+" / 3",Width/2,133,14,"#d4bd99",false,true);
            }
            else {
                Text(Level==3?(Endless?"无尽追击":"列车守卫 · 20 波挑战"):Level==2?"第二关 · 冷杉矿场":"第一关 · 日落镇",Width/2,99,13,"#d8c4a8",false,true);
                Text(Math.Max(1,Wave).ToString("00")+(Level==3?(Endless?" / ∞":" / 20"):" / 05"),Width/2,120,34,"#f3ddba",false,true);
                Text("剩余 "+(SpawnQueue+Enemies.Count)+" 名敌人",Width/2,164,13,"#d4bd99",false,true);
            }
            if(ActiveBoss!=null) {
                float remaining=Math.Max(0,ActiveBoss.HP);
                RectA(365,190,550,65,"#172225",230);
                Text((Level==2?"麦卡":"肺结核 · 首领")+(BossQuiet>5&&ActiveBoss.HP>0&&ActiveBoss.HP<ActiveBoss.MaxHP?" · 回血中":""),Width/2,192,17,"#f4e3bf",true,true);
                Rect(380,224,520,12,"#423c3b");
                Rect(380,224,520*Clamp(remaining/ActiveBoss.MaxHP,0,1),12,"#d65b48");
                Text(((int)Math.Ceiling(remaining))+" / "+(int)ActiveBoss.MaxHP,Width/2,237,12,"#f4e3bf",false,true);
            }
            Text("赏金",1086,108,13,"#d4bd99");
            Text("$"+Money,1086,132,28,"#f5dbad");
            Text("击败",1184,108,13,"#d4bd99");
            Text(Kills.ToString(),1184,132,28,"#f5dbad");
            Text("[ E ]  死神之眼  "+(DeadEye?"开启":"关闭"),37,676,19,DeadEye?"#ffc576":"#efd5a8",true);
            Text("无限使用 · 随时开关",37,711,13,"#cdb594");
            if(Level==3) {
                Text("重机枪 · 无限弹药",1000,669,22,"#f4e3bf",true);
                Text("三人集中火力 · 左键射击 · 每波满血 · Home 选关",Width/2,742,16,"#d9be94",false,true);
                return;
            }
            Text(Mounted?"[ F ] 下马   ·   空格策马冲刺":"[ F ] 上马   ·   空格闪避",448,704,14,"#d9be94");
            Text(Ammo.ToString(),1124,635,56,"#f4e3bf",true);
            Text("/ "+Capacity,1178,670,22,"#c5ac88");
            for(int i=0;i<Capacity;i++)RectA(1058+i*22,706,10,19,i<Ammo?"#e0ac60":"#574834",255);
            Text(ReloadTime>0?"换弹中 "+Math.Max(0,ReloadTime).ToString("0.0")+"s":(Weapon==WeaponType.Rifle?"长枪 · R 换弹":"左轮 · R 换弹"),1091,738,13,"#d3ba93");
            Text("WASD 移动     左键 射击     R 换弹     E 死眼     F 上下马     空格 冲刺 / 闪避     1/2 切枪    ESC 暂停    F11 全屏",Width/2,776,12,"#c1ac8e",false,true);
        }
        void Crosshair() {
            float x=Mouse.X,y=Mouse.Y;
            string c=DeadEye?"#ffe0a1":"#fff0ce";
            float r=DeadEye?12:8;
            using(Pen p=new Pen(C(c),1.5f))g.DrawEllipse(p,x-r,y-r,r*2,r*2);
            foreach(PointF d in new[] {
                new PointF(1,0),new PointF(-1,0),new PointF(0,1),new PointF(0,-1)
            })Line(x+d.X*12,y+d.Y*12,x+d.X*18,y+d.Y*18,c,1.5f);
            Ellipse(x,y,1.5f,1.5f,c);
        }
        void EndPanel(bool pause) {
            RectA(0,0,Width,Height,"#1c130d",235);
            Text(pause?"TAKE A BREATH":"THE FRONTIER REMEMBERS",Width/2,206,13,"#dba55b",false,true);
            Text(pause?"歇一口气":State=="won"?"传说，仍在继续。":"亚瑟倒下了。",Width/2,255,48,"#f4e3bf",true,true);
            Text(pause?"按 ESC 或点击继续，回到荒野。":State=="won"?(Level==1?"日落镇已守住。下一站：冷杉矿场，追击麦卡。":Level==2?"麦卡已被击败。下一站：列车追击战！":"成功坚持 20 波！可继续挑战无尽平克顿侦探。"):"左轮还温热。再来一次，把命运握在手里。",Width/2,338,17,"#c8b69a",false,true);
            if(!pause) {
                Line(370,395,910,395,"#71583a");
                Text("击败敌人",428,417,13,"#c8b69a",false,true);
                Text(Kills.ToString(),428,446,30,"#efd6ac",true,true);
                Text("获得赏金",640,417,13,"#c8b69a",false,true);
                Text("$"+Money,640,446,30,"#efd6ac",true,true);
                Text("存活时间",852,417,13,"#c8b69a",false,true);
                Text(((int)Elapsed/60)+":"+((int)Elapsed%60).ToString("00"),852,446,30,"#efd6ac",true,true);
            }
            Button(ResumeButton,pause?"继续战斗   →":State=="lost"?"重试本关   ↻":Level==3?"继续无尽模式   →":"进入下一关   →",true);
            Button(HomeButton,"返回主页选关",false);
            if(!pause&&State=="won") {
                Text("制作人员 · 共两人",Width/2,675,16,"#c8b69a",false,true);
                Text("不死战狼   ·   点按",Width/2,708,26,"#dba55b",true,true);
            }
        }
        public void Click(float x,float y) {
            if(WorldMap) { WorldMap=false;Paused=false;return; }
            if(ShowCredits) { if(HomeButton.Contains(x,y))ShowCredits=false;return; }
            if((Paused||State=="won"||State=="lost")&&HomeButton.Contains(x,y)) {
                Home();
                return;
            }
            if(Paused) {
                if(ResumeButton.Contains(x,y))TogglePause();
                return;
            }
            if(State=="won"||State=="lost") {
                if(ResumeButton.Contains(x,y))ContinueGame();
                return;
            }
            if(new RectangleF(1090,29,80,35).Contains(x,y)) {
                Muted=!Muted;
                if(Muted) { foreach(SoundPlayer player in sounds.Values)player.Stop(); }
                else { soundUntil=DateTime.MinValue; Play("reload"); }
                return;
            }
            if(new RectangleF(1183,29,55,35).Contains(x,y)) {
                TogglePause();
                return;
            }
            if(State=="intro") {
                if(new RectangleF(108,662,310,58).Contains(x,y)) { StartFrontier();return; }
                if(new RectangleF(438,662,180,58).Contains(x,y)) { LoadFrontier();return; }
                if(new RectangleF(410,584,220,58).Contains(x,y)) { ShowCredits=true;return; }
                if(new RectangleF(660,584,50,58).Contains(x,y)) { SetSensitivity(Sensitivity-.1f);return; }
                if(new RectangleF(920,584,50,58).Contains(x,y)) { SetSensitivity(Sensitivity+.1f);return; }
                for(int level=1;level<=3;level++)if(LevelButton(level).Contains(x,y)) {
                    SelectedLevel=level;
                    return;
                }
                if(MainButton.Contains(x,y))StartLevel(SelectedLevel);
                return;
            }
            MouseHeld=true;
        }
        void MakeSound(string name,float freq,float seconds,float volume) {
            int rate=22050,count=(int)(rate*seconds);
            MemoryStream stream=new MemoryStream();
            BinaryWriter w=new BinaryWriter(stream);
            w.Write(Encoding.ASCII.GetBytes("RIFF"));
            w.Write(36+count*2);
            w.Write(Encoding.ASCII.GetBytes("WAVEfmt "));
            w.Write(16);
            w.Write((short)1);
            w.Write((short)1);
            w.Write(rate);
            w.Write(rate*2);
            w.Write((short)2);
            w.Write((short)16);
            w.Write(Encoding.ASCII.GetBytes("data"));
            w.Write(count*2);
            Random noise=new Random(29);
            for(int i=0;i<count;i++) {
                double t=(double)i/rate,fade=Math.Pow(1-(double)i/count,2),wave=Math.Sin(2*Math.PI*freq*t*(1-.35*t/seconds));
                if(name=="shot"||name=="hit")wave=wave*.35+(noise.NextDouble()*2-1)*.65;
                w.Write((short)(wave*fade*volume*short.MaxValue));
            }
            w.Flush();
            stream.Position=0;
            audioStreams.Add(stream);
            SoundPlayer p=new SoundPlayer(stream);
            try {
                p.Load();
            }
            catch {
            }
            sounds[name]=p;
        }
        void Play(string name) {
            if(Muted)return;
            int priority=name=="won"||name=="lost"?4:name=="shot"||name=="hit"?3:name=="hoof"?0:2;
            DateTime now=DateTime.UtcNow;
            if(now<soundUntil&&priority<soundPriority)return;
            try {
                sounds[name].Play();
                soundPriority=priority;
                soundUntil=now.AddSeconds(priority==4?.6:name=="eye"?.3:name=="hit"?.2:name=="shot"?.12:.08);
            }
            catch {
            }
        }
        void CacheScenery() {
            bool previous3D=Use3D;Use3D=false;
            ground=new Bitmap(IsFrontier?2:(int)Math.Ceiling(WorldW+.24f*WorldH)+2,IsFrontier?2:(int)Math.Ceiling(.62f*WorldH)+2,System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            using(Graphics q=Graphics.FromImage(ground)) {
                q.Clear(C("#665035"));
                q.InterpolationMode=InterpolationMode.Bilinear;
                q.DrawImage(terrain,new[] {
                    new PointF(0,0),new PointF(WorldW,0),new PointF(.24f*WorldH,.62f*WorldH)
                });
            }
            terrain.Dispose();
            terrain=null;
            float cx=CameraX,cy=CameraY;
            CameraX=0;
            CameraY=0;
            foreach(Building o in Buildings) {
                int left=(int)Math.Floor(Width/2+o.X+.24f*o.Y-32),top=(int)Math.Floor(Height/2+.62f*o.Y-150);
                int right=(int)Math.Ceiling(Width/2+o.X+o.W+.24f*(o.Y+o.H)+145),bottom=(int)Math.Ceiling(Height/2+.62f*(o.Y+o.H)+100);
                BuildingSprite sprite=new BuildingSprite {
                    X=left-Width/2,Y=top-Height/2,Normal=new Bitmap(right-left,bottom-top,System.Drawing.Imaging.PixelFormat.Format32bppPArgb),Faded=new Bitmap(right-left,bottom-top,System.Drawing.Imaging.PixelFormat.Format32bppPArgb)
                };
                foreach(bool faded in new[] {
                    false,true
                })using(Graphics q=Graphics.FromImage(faded?sprite.Faded:sprite.Normal)) {
                    g=q;
                    q.SmoothingMode=SmoothingMode.AntiAlias;
                    q.TextRenderingHint=System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
                    q.TranslateTransform(-left,-top);
                    DrawBuilding(o,faded);
                }
                buildingSprites.Add(o,sprite);
                Building item=o;
                staticDrawItems.Add(new DrawItem(o.Y+o.H,delegate {
                    DrawCachedBuilding(item);
                }));
            }
            CacheActors();
            CacheRoadside();
            Use3D=previous3D;CameraX=cx;
            CameraY=cy;
            g=null;
            topShade=new LinearGradientBrush(new Rectangle(0,0,Width,190),Color.FromArgb(150,22,15,11),Color.Transparent,90f);
            bottomShade=new LinearGradientBrush(new Rectangle(0,580,Width,220),Color.Transparent,Color.FromArgb(205,22,15,11),90f);
        }
        void Blit(Bitmap image,int x,int y) {
            int sx=Math.Max(0,-x),sy=Math.Max(0,-y),dx=Math.Max(0,x),dy=Math.Max(0,y),w=Math.Min(image.Width-sx,Width-dx),h=Math.Min(image.Height-sy,Height-dy);
            if(w<=0||h<=0)return;
            g.DrawImage(image,new Rectangle(dx,dy,w,h),new Rectangle(sx,sy,w,h),GraphicsUnit.Pixel);
        }
        void DrawCachedBuilding(Building o) {
            BuildingSprite sprite=buildingSprites[o];
            PointF origin=Project(0,0,0);
            int x=(int)Math.Round(origin.X+sprite.X),y=(int)Math.Round(origin.Y+sprite.Y);
            if(x>Width||y>Height||x+sprite.Normal.Width<0||y+sprite.Normal.Height<0)return;
            PointF p=Project(Player.X,Player.Y,35),left=Project(o.X,o.Y,140),right=Project(o.X+o.W,o.Y+o.H,0);
            bool fade=State!="intro"&&Player.Y<o.Y+o.H&&p.X>left.X-15&&p.X<right.X+15&&p.Y>left.Y-10&&p.Y<right.Y+12;
            Blit(fade?sprite.Faded:sprite.Normal,x,y);
        }
        public void Dispose() {
            if(terrain!=null)terrain.Dispose();
            ground.Dispose();
            topShade.Dispose();
            bottomShade.Dispose();
            foreach(BuildingSprite b in buildingSprites.Values)b.Dispose();
            foreach(Bitmap b in actorSprites.Values)b.Dispose();
            foreach(Bitmap b in textSprites.Values)b.Dispose();
            foreach(SolidBrush b in brushes.Values)b.Dispose();
            foreach(Pen p in pens.Values)p.Dispose();
            foreach(Font f in fonts.Values)f.Dispose();
            foreach(SoundPlayer p in sounds.Values)p.Dispose();
            foreach(MemoryStream s in audioStreams)s.Dispose();
        }
    }
}





