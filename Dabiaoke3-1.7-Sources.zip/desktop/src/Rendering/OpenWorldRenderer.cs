using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
namespace ArthurFrontier {
    sealed partial class FrontierGame {
        void WorldRect(float x,float y,float w,float h,string color) {
            Poly(new[]{Project(x,y,0),Project(x+w,y,0),Project(x+w,y+h,0),Project(x,y+h,0)},color);
        }
        bool VisibleWorld(float x,float y,int margin) {
            PointF p=Project(x,y,0);return p.X> -margin&&p.X<Width+margin&&p.Y> -margin&&p.Y<Height+margin;
        }
        void DrawRoad(PointF[] path,float width,string color) {
            GraphicsState state=g.Save();using(Matrix matrix=new Matrix(1,0,.24f,.62f,Width/2-CameraX-.24f*CameraY,Height/2-.62f*CameraY))g.MultiplyTransform(matrix);
            using(Pen pen=new Pen(C(color),width)) { pen.StartCap=pen.EndCap=LineCap.Round;pen.LineJoin=LineJoin.Round;g.DrawLines(pen,path); }g.Restore(state);
        }
        void DrawFrontierGround() {
            g.SmoothingMode=SmoothingMode.None;
            Rect(0,0,Width,Height,"#758255");
            int left=(int)Math.Floor((CameraX-1150)/200)*200,top=(int)Math.Floor((CameraY-800)/200)*200;
            for(int y=top;y<CameraY+1000;y+=200)for(int x=left;x<CameraX+1150;x+=200) {
                if(x<0||y<0||x>=WorldW||y>=WorldH)continue;
                int hash=(x/200*31+y/200*17)&7;
                WorldRect(x,y,200,200,hash<2?"#7c8958":hash<5?"#748252":"#6e7c4f");
            }
            // Roads, water and bridges are vector strips; no giant terrain bitmap.
            WorldRect(2600,350,2700,5300,"#8b886c");WorldRect(6750,350,2750,5300,"#85836b");
            foreach(PointF[] road in new[]{MountainRoad,WestSpur,EastSpur})DrawRoad(road,340,"#b7a47a");
            for(int town=0;town<2;town++) {
                float x=town==0?1500:10500,y=town==0?0:1400;
                WorldRect(x-830,2200+y,1660,940,"#ad966b");
                WorldRect(x-90,2060+y,180,1450,"#c0ac7f");
            }
            WorldRect(1650,4350,2700,1230,"#ad996f");
            DrawRiver();
            WorldRect(5540,4110,960,380,"#98754f");
            for(int x=5560;x<6490;x+=30) {
                PLine(Project(x,4110,0),Project(x,4490,0),"#634f38",2);
            }
            DrawRoad(Railway,115,"#665e4d");DrawRoad(Railway,70,"#bcb89d");DrawRoad(Railway,58,"#665e4d");
            WorldRect(2480,5710,640,160,"#c3ac7b");
            for(float d=0;d<PathLength(Railway);d+=50) { PointF p=Along(Railway,d),next=Along(Railway,d+2);if(!VisibleWorld(p.X,p.Y,100))continue;float a=Angle(p.X,p.Y,next.X,next.Y)+(float)Math.PI/2;PLine(Project(p.X+(float)Math.Cos(a)*47,p.Y+(float)Math.Sin(a)*47,0),Project(p.X-(float)Math.Cos(a)*47,p.Y-(float)Math.Sin(a)*47,0),"#433e32",5); }
            for(int i=0;i<2;i++) {
                PointF c=Camps[i];WorldRect(c.X-320,c.Y-280,640,560,CampCleared[i]?"#8c8761":"#897557");
                float x=i==0?1500:10500;WorldRect(x-240,i==0?3370:4770,480,150,"#c3ac7b");
            }
            g.CompositingMode=CompositingMode.SourceOver;
            DrawAdventureGround();
            g.SmoothingMode=SmoothingMode.AntiAlias;
            for(int y=top;y<CameraY+1000;y+=150)for(int x=left;x<CameraX+1150;x+=150) {
                int hash=(x/150*37+y/150*53)&31;
                if(NearRail(x,y)||RoadDistance(x,y)<200||MountainBlocked(x,y,0)||NearRiver(x,y,140)||SafeTown(x,y)||x<100||x>11900||y<100||y>5900)continue;
                PointF p=Project(x+hash*3,y,0);
                if(hash%3==0&&VisibleWorld(x,y,40))g.DrawImageUnscaled(actorSprites[9001],(int)p.X,(int)p.Y);
            }
        }
        void AddFrontierScene(List<DrawItem> scene) {
            AddOutlawScene(scene);
            foreach(PointF airport in new[]{MainlandAirfield,IslandAirfield})if(VisibleWorld(airport.X,airport.Y,400)) { PointF p=airport;scene.Add(new DrawItem(p.Y,delegate { DrawFlyer(p.X+240,p.Y,false); })); }
            int left=(int)Math.Floor((CameraX-1150)/300)*300,top=(int)Math.Floor((CameraY-900)/300)*300;
            for(int y=top;y<CameraY+1100;y+=300)for(int x=left;x<CameraX+1200;x+=300) {
                int hash=(x/300*37+y/300*53)&15;
                if(MountainBlocked(x,y,0)&&VisibleWorld(x,y,250)) { PointF p=Project(x,y,0);Poly(new[]{new PointF(p.X-95,p.Y+50),new PointF(p.X+10,p.Y-100-hash*3),new PointF(p.X+95,p.Y+40)},"#706f5f");Poly(new[]{new PointF(p.X+10,p.Y-100-hash*3),new PointF(p.X+95,p.Y+40),new PointF(p.X+28,p.Y+10)},"#5c6056"); }
                if(hash>3||NearRail(x,y)||MountainBlocked(x,y,0)||RoadDistance(x,y)<220||NearRiver(x,y,180)||SafeTown(x,y)||x<100||x>11900||y<100||y>5900)continue;
                float tx=x+hash*20,ty=y;if(!VisibleWorld(tx,ty,170))continue;
                scene.Add(new DrawItem(ty,delegate { PointF p=Project(tx,ty,0);g.DrawImageUnscaled(actorSprites[9000],(int)p.X-55,(int)p.Y-150); }));
            }
            foreach(Body npc in Residents) {
                Body n=npc;if(n.HP<=0||!VisibleWorld(n.X,n.Y,100))continue;
                scene.Add(new DrawItem(n.Y,delegate { DrawResident(n); }));
            }
            for(int i=0;i<2;i++) {
                int index=i;PointF plot=Plots[i];
                if(VisibleWorld(plot.X,plot.Y,250))scene.Add(new DrawItem(plot.Y,delegate { DrawHouse(index); }));
            }
            for(int car=0;car<3;car++) {
                PointF rp=RailPoint(car*130);float x=rp.X,y=rp.Y;int index=car;
                if(VisibleWorld(x,y,220))scene.Add(new DrawItem(y+35,delegate {
                    Box(x-55,y-40,115,80,45,index==0?"#4c5955":"#9b7950","#34413c","#6c5338");
                    Box(x-30,y-30,55,60,index==0?85:70,"#626c59","#293933","#816541");
                    if(index==0)Box(x+25,y-20,20,20,105,"#313f3b","#293531","#465046");
                }));
            }
            foreach(WorldService service in Services) {
                WorldService s=service;if(!VisibleWorld(s.X,s.Y,100))continue;
                scene.Add(new DrawItem(s.Y+2,delegate { PointF p=Project(s.X,s.Y,0);Ellipse(p.X,p.Y,17,9,"#d4ca80",180);Text(s.Name,p.X,p.Y-42,14,"#f7e7b7",true,true);Text("Q",p.X,p.Y-21,13,"#ffffff",true,true); }));
            }
        }
        void DrawResident(Body n) {
            if(n.Rider) {
                DrawHorse(n.X,n.Y,n.Angle,n.Step,true);PointF rider=Project(n.X,n.Y,42);Rect(rider.X-9,rider.Y-32,18,25,"#899776");Ellipse(rider.X,rider.Y-42,8,9,"#c8a178");Ellipse(rider.X,rider.Y-52,18,4,"#a98e61");Ellipse(rider.X,rider.Y-70,4,4,"#bfc2be");return;
            }
            PointF p=Project(n.X,n.Y,0);float step=(float)Math.Sin(n.Step)*4;
            Ellipse(p.X,p.Y,17,6,"#47533b",100);
            Line(p.X-6,p.Y-18,p.X-7+step,p.Y,"#42493e",5);Line(p.X+6,p.Y-18,p.X+7-step,p.Y,"#42493e",5);
            Rect(p.X-10,p.Y-42,20,26,"#8d9973");Ellipse(p.X,p.Y-52,9,11,"#c8a178");
            Ellipse(p.X,p.Y-60,20,5,"#b89e6a");Rect(p.X-11,p.Y-71,22,11,"#998353");
            Ellipse(p.X,p.Y-85,4,4,"#bfc2be");
        }
        void DrawHouse(int index) {
            PointF p=Plots[index];int stage=HouseStage[index];
            WorldRect(p.X-120,p.Y-160,240,180,"#bcab7c");
            if(stage==0) { PointF sign=Project(p.X,p.Y-60,0);Text("可建造宅地",sign.X,sign.Y-30,18,"#ffe0a1",true,true);return; }
            Box(p.X-100,p.Y-140,200,140,10,"#a69b87","#736956","#8c816b");
            if(stage>=2) {
                Box(p.X-100,p.Y-140,200,15,85,"#c5ac79","#7d6848","#9c8358");
                Box(p.X-100,p.Y-140,15,140,85,"#c5ac79","#7d6848","#9c8358");
                Box(p.X+85,p.Y-140,15,140,85,"#c5ac79","#7d6848","#9c8358");
            }
            if(stage==3)DrawBuilding(new Building(p.X-100,p.Y-140,200,140,"saloon","ARTHUR'S HOME"));
            if(stage==3)DrawOilLamp(p.X+34,p.Y+3,255);
            PointF label=Project(p.X,p.Y,125);Text("亚瑟的家 · "+stage+" / 3",label.X,label.Y,17,"#fbe1aa",true,true);
        }
        void FrontierHUD() {
            RectA(25,100,260,180,"#182620",215);
            Text("亚瑟  "+(int)Player.HP+" / 100",40,112,20,"#f4e3bf",true);
            Rect(40,145,220,7,"#483d30");Rect(40,145,220*Player.HP/100,7,"#d77852");
            Text("马匹 "+(int)HorseHP+" / 200 · "+(Mounted?"骑乘":"徒步"),40,166,14,"#ddd2a4");
            Text("赏金 $"+Money+"   枪械 +"+(GunUpgrade*25)+"%",40,193,17,"#f2c477",true);
            Text("营地 "+((CampCleared[0]?1:0)+(CampCleared[1]?1:0))+" / 2 · 房屋 "+HouseStage[0]+"、"+HouseStage[1]+" / 3",40,225,13,"#d3dfb4");
            string region=Flying?"远海航线":OnIsland?"白鹭岛":Player.X>1650&&Player.X<4350&&Player.Y>4300?"石桥镇":Player.X>9500&&Player.Y<1600?"风蚀镇":SafeTown(Player.X,Player.Y)?(Player.X<6000?"日落镇":"冷杉镇"):NearRiver(Player.X,Player.Y,300)?"碧水河 · 骑马渡河":"山地草原 · 自由探索";
            Text(Aboard?"列车旅程 · 前往"+StationName(railDestination):region,Width/2,100,22,"#f4e3bf",true,true);
            Text("铁路："+(RailStop>=0?StationName(RailStop)+"停靠":"驶向"+StationName(RailNextStop)),Width/2,137,15,"#e1cca6",false,true);
            Text(Wanted>0?"通缉 "+new string('★',Wanted)+" · 警察追捕中":"灰点居民 · 红点帮派 · 蓝点警察",Width/2,172,17,Wanted>0?"#ff8b6d":"#ccd1b3",true,true);
            DrawMiniMap();
            RectA(245,653,790,75,"#16231f",230);
            WorldService near=NearbyService();Text(Flying?"飞行中 · 自动抵达机场 · 马匹托运中":MealTime>0?"正在吃套餐 · "+MealTime.ToString("0.0")+" 秒后回血":Aboard?"乘车中 · X 抢劫保险箱 · 自动抵达目的地":ServiceHint(near),Width/2,668,16,"#f5d693",true,true);
            Text("WASD 移动 · 左键 射击 · R 换弹 · E 死眼 · F 上下马 · 空格 冲刺",Width/2,709,13,"#dbc6a3",false,true);
            Text("Q 互动/劫狱 · G 钓鱼 · X 抢列车/马车 · 右键 死眼标记 · M 地图 · F5/F9 存读档",Width/2,746,14,"#e1d3b6",false,true);
            Text((Weapon==WeaponType.Shotgun?"短管霰弹枪":Weapon==WeaponType.Rifle?"长枪":"左轮")+" "+Ammo+" / "+Capacity,1045,682,16,"#f4e3bf",true);
            Text(ReloadTime>0?"换弹中":"1 / 2 / 3 切枪",1050,714,12,"#d8caa4");
            DrawAdventureOverlay();
            RectA(25,352,280,42,"#182620",215);Text(PoliceRespawn[LocalDistrict]>0?"本区警队覆灭 · "+(int)Math.Ceiling(PoliceRespawn[LocalDistrict])+"秒后刷新":DistrictNames[LocalDistrict]+"巡警 · 剩余 "+(4-PoliceDeaths[LocalDistrict])+" / 4",40,363,14,"#e8d6ad",true);
            DrawPrisonDramaOverlay();DrawWorldClock();
        }
        void DrawMiniMap() {
            RectangleF r=new RectangleF(990,110,250,125);RectA(r.X-8,r.Y-8,r.Width+16,r.Height+36,"#16231f",230);
            MapFeatures(r,false);Text("M 查看完整地图",1115,242,12,"#e0c99b",false,true);
        }
        PointF MapPoint(RectangleF r,float x,float y) { return new PointF(r.X+x/26000*r.Width,r.Y+y/6000*r.Height); }
        void MapFeatures(RectangleF r,bool labels) {
            Rect(r.X,r.Y,r.Width,r.Height,"#64724c");
            Rect(r.X+r.Width*12000/26000,r.Y,r.Width*14000/26000,r.Height,"#396e83");
            PointF island=MapPoint(r,22000,3000);Ellipse(island.X,island.Y,r.Width*.1f,r.Height*.383f,"#9daa69");
            for(int i=1;i<=60;i++)PLine(MapPoint(r,RiverCenter((i-1)*100),(i-1)*100),MapPoint(r,RiverCenter(i*100),i*100),"#61a2b3",labels?11:3);
            OutlawMap(r,labels);
            PointF stoneStation=MapPoint(r,2800,5650);Rect(stoneStation.X-4,stoneStation.Y-4,8,8,"#ffffff");if(labels)Text("石桥车站",stoneStation.X,stoneStation.Y+10,13,"#ffffff",true,true);
            PointF airport=MapPoint(r,10900,1300);PLine(airport,island,"#c9dfec",1);Ellipse(airport.X,airport.Y,5,5,"#ffffff");
            if(labels) { Text("风蚀镇 · 机场",airport.X,airport.Y-35,16,"#fff0c2",true,true);Text("白鹭岛 · 飞机往返",island.X,island.Y-50,20,"#fff0c2",true,true); }
            foreach(PointF[] path in new[]{MountainRoad,WestSpur,EastSpur,Railway})for(int i=1;i<path.Length;i++)PLine(MapPoint(r,path[i-1].X,path[i-1].Y),MapPoint(r,path[i].X,path[i].Y),path==Railway?"#e2dfce":"#bcaa7b",labels?4:2);
            if(labels) { PointF bridge=MapPoint(r,6000,4300);Rect(bridge.X-22,bridge.Y-6,44,12,"#e7c689");Text("公路桥",bridge.X,bridge.Y+12,14,"#f4e3bf",false,true); }
            for(int i=0;i<2;i++) {
                float x=i==0?1500:10500;PointF p=MapPoint(r,x,i==0?2800:4200);Ellipse(p.X,p.Y,labels?13:5,labels?13:5,"#f2d197");
                if(labels)Text(i==0?"日落镇":"冷杉镇",p.X,p.Y-48,20,"#fff1cd",true,true);
                PointF c=MapPoint(r,Camps[i].X,Camps[i].Y);Ellipse(c.X,c.Y,labels?9:4,labels?9:4,CampCleared[i]?"#afc88e":"#d7734e");
                PointF h=MapPoint(r,Plots[i].X,Plots[i].Y);Rect(h.X-5,h.Y-5,10,10,"#e5ce76");
                if(labels) { Text((i==0?"赤蛇帮":"铁狼帮")+(CampCleared[i]?" · 已清剿":""),c.X,c.Y+15,16,"#f3dfbf",true,true);Text((i==0?"河畔宅地":"松林宅地")+" "+HouseStage[i]+"/3",h.X,h.Y+15,15,"#ecd98f",false,true); }
            }
            PointF rail=MapPoint(r,RailPosition.X,RailPosition.Y);Rect(rail.X-5,rail.Y-3,10,6,"#232e2a");
            PointF player=MapPoint(r,Player.X,Player.Y);Ellipse(player.X,player.Y,labels?7:4,labels?7:4,"#ffffff");
            if(labels) { Text("亚瑟",player.X,player.Y-27,14,"#ffffff",true,true);Text("碧水河",r.X+r.Width*6000/26000,r.Y+35,18,"#d4f0f3",true,true); }
        }
        void DrawFrontierMap() {
            RectA(0,0,Width,Height,"#17221c",248);
            Text("荒野与远海 · 世界地图",640,35,32,"#f2dbb0",true,true);
            Text("北部风蚀镇机场 → 白鹭岛 · 往返机票 $60 · 岛屿没有陆路",640,87,16,"#cabf9f",false,true);
            MapFeatures(new RectangleF(100,140,1080,480),true);
            Text("道路仅供导航 · 大陆自由穿行 · 河中和山地减速 · 海洋只能乘飞机跨越",640,642,17,"#e0cca5",false,true);
            Text("牛肉套餐 $20 · 短管霰弹枪 $120 · 列车 $20 · 告示板悬赏每名帮派 $10",640,679,15,"#d6c59e",false,true);
            Text("宅地：$100 地基 → $200 墙体 → $300 封顶 · 建成后免费休息存档",640,715,15,"#d6c59e",false,true);
            Text("M / ESC / 点击地图 返回游戏",640,758,16,"#f6ddb1",true,true);
        }
    }
}

