using System;
using System.Runtime.InteropServices;
using System.Threading;
namespace ArthurFrontier {
    /// <summary>High-resolution waitable timer avoids thread-pool timer quantization.</summary>
    sealed class FrameClock : IDisposable {
        readonly IntPtr timer;
        readonly Thread worker;
        readonly Action tick;
        volatile bool running=true;
        public bool HighResolution {
            get;
            private set;
        }
        [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr CreateWaitableTimerExW(IntPtr attributes,string name,uint flags,uint access);
        [DllImport("kernel32.dll")] static extern bool SetWaitableTimer(IntPtr timer,ref long due,int period,IntPtr callback,IntPtr arg,bool resume);
        [DllImport("kernel32.dll")] static extern bool CancelWaitableTimer(IntPtr timer);
        [DllImport("kernel32.dll")] static extern uint WaitForSingleObject(IntPtr handle,uint milliseconds);
        [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
        public FrameClock(Action callback) {
            tick=callback;
            timer=CreateWaitableTimerExW(IntPtr.Zero,null,2,0x1F0003);
            HighResolution=timer!=IntPtr.Zero;
            if(timer==IntPtr.Zero)timer=CreateWaitableTimerExW(IntPtr.Zero,null,0,0x1F0003);
            if(timer==IntPtr.Zero)throw new InvalidOperationException("Cannot create frame timer");
            long due=-20000;
            if(!SetWaitableTimer(timer,ref due,2,IntPtr.Zero,IntPtr.Zero,false)) {
                CloseHandle(timer);
                throw new InvalidOperationException("Cannot start frame timer");
            }
            worker=new Thread(Run);
            worker.Name="Arthur frame clock";
            worker.IsBackground=true;
            worker.Start();
        }
        void Run() {
            while(running) {
                if(WaitForSingleObject(timer,100)==0&&running)tick();
            }
        }
        public void Dispose() {
            running=false;
            CancelWaitableTimer(timer);
            long due=-1;
            SetWaitableTimer(timer,ref due,0,IntPtr.Zero,IntPtr.Zero,false);
            worker.Join(500);
            CloseHandle(timer);
        }
    }
}
